﻿/// <binding />
/*
This file in the main entry point for defining Gulp tasks and using Gulp plugins.
Click here to learn more. http://go.microsoft.com/fwlink/?LinkId=518007
*/

var gulp = require('gulp');
var runSequence = require('run-sequence');

gulp.task('copycore', function () {

    return gulp.src(['./node_modules/core-js/**/*.js'])
    .pipe(gulp.dest('./scripts/npm_libs/core-js'));

});

gulp.task('copyzone', function () {

    return gulp.src(['./node_modules/zone.js/**/*.js'])
    .pipe(gulp.dest('./scripts/npm_libs/zone.js'));

});

gulp.task('copysystem', function () {
    return gulp.src(['./node_modules/systemjs/**/*.js'])
    .pipe(gulp.dest('./scripts/npm_libs/systemjs'));
});

var rollup = require('rollup');
var nodeResolve = require('rollup-plugin-node-resolve');
var commonjs = require('rollup-plugin-commonjs');
var uglify = require('rollup-plugin-uglify');

gulp.task('bundleProd', function () {
    return rollup.rollup({
        entry: "appScripts/main.js",
        plugins: [
             nodeResolve({ jsnext: true, module: true }),
            commonjs({
                include: ['node_modules/rxjs/**', 'node_modules/angular2-uuid/**', 'node_modules/primeng/**', 'node_modules/moment/**'],
                namedExports: { 'node_modules/primeng/primeng.js': ['TreeModule', 'TreeNode', 'CalendarModule', 'ButtonModule', 'TooltipModule', 'TreeDragDropService', 'TreeTableModule', 'DataTableModule', 'DataTable', 'ConfirmDialogModule', 'ConfirmationService', 'ProgressBarModule', 'OverlayPanelModule', 'DialogModule', 'SharedModule', 'AccordionModule', 'RadioButtonModule']}
            }),
            uglify.uglify()
        ],
        onwarn: function (warning) {
            // Skip certain warnings

            // should intercept ... but doesn't in some rollup versions
            if (warning.code === 'THIS_IS_UNDEFINED') { return; }
            // intercepts in some rollup versions
            //if (warning.indexOf("The 'this' keyword is equivalent to 'undefined'") > -1) { return; }

            // console.warn everything else
            console.warn(warning.message);
        }
    })
      .then(function (bundle) {
          bundle.write({
              format: "iife",
              moduleName: "library",
              file: "Scripts/appbundle.js",
              sourceMap: true,

          });
      })
});

gulp.task('bundleDev', function () {
    return rollup.rollup({
        input: "appScripts/main.js",
        plugins: [
             nodeResolve({ jsnext: true, module: true }),
            commonjs({
                include: ['node_modules/rxjs/**', 'node_modules/angular2-uuid/**', 'node_modules/primeng/**', 'node_modules/moment/**'],
                namedExports: { 'node_modules/primeng/primeng.js': ['TreeModule', 'TreeNode', 'CalendarModule', 'ButtonModule', 'TooltipModule', 'TreeDragDropService', 'TreeTableModule', 'DataTableModule', 'DataTable', 'ConfirmDialogModule', 'ConfirmationService', 'ProgressBarModule', 'OverlayPanelModule', 'DialogModule', 'SharedModule', 'AccordionModule', 'RadioButtonModule'] }
            })
        ],
        onwarn: function (warning) {
            // Skip certain warnings

            // should intercept ... but doesn't in some rollup versions
            if (warning.code === 'THIS_IS_UNDEFINED') { return; }
            // intercepts in some rollup versions
            //if (warning.indexOf("The 'this' keyword is equivalent to 'undefined'") > -1) { return; }

            // console.warn everything else
            console.warn(warning.message);
        }
    })
      .then(function (bundle) {
          bundle.write({
              format: "iife",
              moduleName: "library",
              dest: "Scripts/appbundle.js",
              sourceMap: true,

          });
      })
});


gulp.task('copyBundle', function () {
    return gulp.src(['./Scripts/appbundle.js'])
        .pipe(gulp.dest('C:/Program Files/Common Files/microsoft shared/Web Server Extensions/16/TEMPLATE/LAYOUTS/'));
    //.pipe(gulp.dest('C:/Program Files/Common Files/microsoft shared/Web Server Extensions/15/TEMPLATE/LAYOUTS/tempstore/'));
});

gulp.task('copyAndBundleDev', function (cb) {
    runSequence('bundleDev',
        'copyBundle');

});

gulp.task('copyAndBundleProd', function (cb) {
    runSequence('bundleProd',
        'copyBundle');

});