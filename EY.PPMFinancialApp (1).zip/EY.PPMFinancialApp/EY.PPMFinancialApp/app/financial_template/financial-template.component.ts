﻿/// <reference path="../../typings/microsoft-ajax/microsoft.ajax.d.ts" />
/// <reference path="../../typings/sharepoint/sharepoint.d.ts" />
import { Component, Input, ViewEncapsulation, OnInit } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import { Subscription } from 'rxjs/Subscription';
import 'rxjs/add/observable/of';
import 'rxjs/add/observable/forkJoin'
import { ConfirmDialogModule, ConfirmationService } from 'primeng/primeng';

import { Utils } from '../shared/utils';
import { AppSettings } from '../shared/app-settings';
import { SharePointService } from '../core/sharepoint.service';
import { FinancialValueService } from '../core/financial-value.service';
import { Location, LocationStrategy, PathLocationStrategy, APP_BASE_HREF, DatePipe } from '@angular/common';
import { MessageRow } from '../shared/model/message-row.model';
import { FinancialTemplate } from '../shared/model/financial-template.model';
import { FinancialValue } from '../shared/model/financial-value.model';
import { FinancialNode } from '../shared/model/financial-node.model';
import { SimpleFinancialNode } from '../shared/model/simple-financial-node.model';
import { GranularityTypeEnum } from '../shared/granularity-type.enum';
import { MapAggregationType } from "../shared/cf-map-aggregation-type";

@Component({
    selector: 'financial-template',
    styleUrls: ['../Content/Styles/ppm-financial-app.css', '../Content/Styles/financial-template.css'],
    encapsulation: ViewEncapsulation.None,
    template: `<div class="container">
                   <div class="financial-template-section-wrapper">
                    </div>
                </div>`
})

export class FinancialTemplateComponent implements OnInit {

    messageRow: MessageRow;
    waitDialog: SP.UI.ModalDialog;
    allTemplates: Array<FinancialTemplate>;
    allListItems: Array<any>;
    newFinancialTemplate: FinancialTemplate;
    currentSelectedListItem: any;
    totalFinanacialNode: FinancialNode;
    financialNodes: Array<FinancialNode>
    granulatiryTypes: Array<string>;
    allMontsh: Array<string>;
    templateFormTracker: any;
    isFormInitializing: boolean;
    isUpdateState: boolean;
    isFiscalYearSelected: boolean;
    shouldUpdateFinancialStructure: boolean;
    isFormDisabled: boolean;
    dateFormat: string;
    momentReference: any;
    showNodeEditDetails: boolean = false;
    availableCostFields: { name: string, id: string }[] = [];
    allCostFields: { name: string, id: string }[] = [];
    allCostFieldsDictionary: { [id: string]: string } = {};

    editDetailsModel: {
        currentNodeSelection: FinancialNode,
        currentCostFieldSelection: string,
        currentAggregationTypeSelection: string,
        selectedFields: { name: string, id: string, agrType: string, startYear?: number, startMonth?: number, endYear?: number, endMonth?: number }[],
        isFieldValid: boolean,
        timeSpanStart?: Date,
        timeSpanEnd?: Date,
        timeSpanStartInvalid: boolean,
        timeSpanEndInvalid: boolean
    } = {
            currentNodeSelection: null,
            currentCostFieldSelection: "",
            currentAggregationTypeSelection: "",
            selectedFields: [],
            isFieldValid: true,
            timeSpanStartInvalid: false,
            timeSpanEndInvalid: false
        }

    constructor(private sharePointService: SharePointService,
        private financialValueService: FinancialValueService,
        private location: Location,
        private confirmationService: ConfirmationService) {
        this.isUpdateState = Utils.getQueryStringParameter("component") == "updateFinancialTemplate";
        this.messageRow = new MessageRow();
        this.shouldUpdateFinancialStructure = false;
        this.isFormInitializing = false;
        this.isFiscalYearSelected = false;
        this.templateFormTracker = { isNameValid: true, isStartDateValid: true, isEndDateValid: true, areFinancialNodesValid: true };
        this.isFormDisabled = false;
        this.dateFormat = Utils.getDateFormat();
    }

    ngOnInit() {
        var vm = this;
    }
}