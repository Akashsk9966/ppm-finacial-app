﻿import { NgModule, forwardRef } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule } from '@angular/forms';
import { FinancialSharedModule } from '../shared/financial-shared.module';
import { CalendarModule } from 'primeng/primeng';
import { ConfirmDialogModule, ConfirmationService, DialogModule, SharedModule } from 'primeng/primeng';

import { FinancialTemplateComponent } from './financial-template.component'
import { ButtonModule, TreeDragDropService, TreeModule, RadioButtonModule } from 'primeng/primeng';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';

@NgModule({
    imports: [FormsModule, BrowserModule, FinancialSharedModule, CalendarModule, TreeModule, ButtonModule, RadioButtonModule, BrowserAnimationsModule, ConfirmDialogModule, DialogModule, SharedModule],
    declarations: [FinancialTemplateComponent],
    exports: [FinancialTemplateComponent],
    entryComponents: [FinancialTemplateComponent],
    providers: [TreeDragDropService]
})

export class FinancialTemplateModule {
}
