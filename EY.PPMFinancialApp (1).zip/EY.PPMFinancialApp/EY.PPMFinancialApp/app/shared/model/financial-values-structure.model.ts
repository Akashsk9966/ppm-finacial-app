﻿import { Utils } from '../utils';
import { GranularityValueModel } from './granularity-value.model'

//TODO: COulkd be removed?
export class FinancialValuesStructureModel {

    id: string;
    pid: string;
    vals: Array<GranularityValueModel>;

    constructor() {
        this.vals = new Array<GranularityValueModel>();
    }
}