﻿import { TreeNode } from 'primeng/primeng';

export class SimpleFinancialNode implements TreeNode {

    id: string;
    parentId: string;
    label: string;
    shortLabel: string;
    children: Array<SimpleFinancialNode>;
    customFieldMap?: {
        customFieldUid: string
        aggregationType: string
    }[]

    constructor(id: string, parentId: string, label: string, shortLabel: string, customFieldMap: {
        customFieldUid: string
        aggregationType: string
    }[])
    {
        this.id = id;
        this.parentId = parentId;
        this.label = label;
        this.shortLabel = shortLabel;
        this.children = new Array<SimpleFinancialNode>();
        this.customFieldMap = customFieldMap;
    }
}