﻿import { FinancialNode } from "./financial-node.model";

export class FinancialValue {

    public id: number;
    public entityName: string;
    public entityUid: SP.Guid;
    public listUID: SP.Guid;
    public listItemId: number;
    public listItemTitle: string;
    public financialStartDate: Date;
    public financialEndDate: Date;
    public financialValuesJson: string;
    public templateStructureJson: string;
    public granularity: string;
    public updateStatus: string;
    public updateStartDate: Date;
    public updateEndDate: Date;
    public originalStartDate: Date;
    public originalEndDate: Date;

    constructor() {
    }
}