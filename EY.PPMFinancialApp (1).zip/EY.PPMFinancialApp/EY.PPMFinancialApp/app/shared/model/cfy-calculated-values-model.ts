﻿export class CFYCalculatedValues {

    public cfyTotals: Array<number>;
    public cfyPlanTotal: number;
    public cfyForecastTotal: number;
    public cfyActualsTotal: number;
    public cfyEAC: number;
    public cfyBudget: number;
    public cfyVariance: number;

    public cfyPlanTotalDisplayValue: string;
    public cfyForecastTotalDisplayValue: string;
    public cfyActualsTotalDisplayValue: string;
    public cfyEACDisplayValue: string;
    public cfyBudgetDisplayValue: string;
    public cfyVarianceDisplayValue: string;

    public cfyNegativeNumberColor: string;

    constructor() {
        this.cfyTotals = new Array<number>();
        this.cfyNegativeNumberColor = "negative-numbers-color";
    }
}