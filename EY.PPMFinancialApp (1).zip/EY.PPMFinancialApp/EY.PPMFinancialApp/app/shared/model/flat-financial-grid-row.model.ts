﻿import { TreeNode } from 'primeng/primeng';
import { GranularityCellModel } from './granularity-cell.model';
import { FinancialGridRowModel } from "./financial-grid-row.model";

export class FlatFinancialGridRowModel {

    id: string;
    parentId: string;
    paddingValue: number;
    level: number;
    isExpanded: boolean;
    hasChildren: boolean;
    label: string;
    shortLabel: string;
    cellBackgroundClass: string;
    cellTextColorClass: string;
    cellInfo: {
        cellModel: GranularityCellModel;
        shadowNodeReferenceKeys: Array<{
            year: string;
            months: Array<string>;
        }>
    }[];
    granularityType: string;

    constructor(label: string) {
        this.label = label;
        this.cellInfo = [];
        this.level = 0;
        this.cellBackgroundClass = "background-grid-level-0";
        this.cellTextColorClass = "color-grid-level-0";
    }
}