﻿import { AppSettings } from '../app-settings';

export class MessageRow {

    messageClass: string;
    messageTexts: Array<string>;
    messageType: string;

    constructor() {
        this.messageType = AppSettings.getDefault();
        this.messageTexts = new Array<string>();
    }
}