﻿import { Utils } from '../utils';

//TODO: COulkd be removed?
export class GranularityValueModel {
    
    yr: string;
    mth: string;
    val: number;

    constructor() {
    }
}