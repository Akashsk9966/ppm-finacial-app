﻿import { Utils } from '../utils';

export class FinancialGridSizeDataModel {

    financialTableContainerWidth: number;
    financialTableWrapperWidth: number;
    financialTableWrapperHeight: number;
    valuesTableWrapperWidth: number;
    valuesTableWrapperHeight: number;
    labelsTableWrapperHeight: number;
    labelsTableWrapperWidth: number;
    valuesTableWidth: number;
    valuesTableHeadWidth: number;
    valuesTableEmptyRowWidth: number;
    unfrozenCellWidth: number;
    unfrozenCellStyle: {};

    constructor() {
    }
}