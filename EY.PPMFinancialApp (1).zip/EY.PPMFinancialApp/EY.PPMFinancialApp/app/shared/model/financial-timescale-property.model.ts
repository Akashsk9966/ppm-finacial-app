﻿
export class FinancialTimescalePropertyModel {

    areDatesMapped: boolean;
    areDatesValid: boolean;
    startDateCFGuid: SP.Guid;
    startDate: Date;
    selectedStartDate: Date;
    endDateCFGuid: SP.Guid;
    endDate: Date;
    selectedEndDate: Date;

    constructor() {
        this.areDatesValid = false;
        this.areDatesMapped = false;
    }
}