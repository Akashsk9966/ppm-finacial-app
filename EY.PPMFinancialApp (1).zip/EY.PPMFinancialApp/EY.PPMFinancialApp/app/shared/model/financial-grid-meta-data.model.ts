﻿import { Utils } from '../utils';

export class FinancialGridMetaDataModel {

    currentUser: SP.User;
    entityName: string;
    entityUID: SP.Guid;
    listItemId: number;
    financialTemplateName: string;
    editGranularity: string;
    selectedGranularity: string;
    isGridEditable: boolean;
    isGridCollapsed: boolean;
    isGranularityEditable: boolean;

    areFinancialValuesDirty: boolean;
    
    isSnapshotEnabled: boolean;
    constructor() {
        
        this.areFinancialValuesDirty = false;
    
        this.isGridEditable = false;
        this.isGridCollapsed = false;
        this.isSnapshotEnabled = false;
    }
}