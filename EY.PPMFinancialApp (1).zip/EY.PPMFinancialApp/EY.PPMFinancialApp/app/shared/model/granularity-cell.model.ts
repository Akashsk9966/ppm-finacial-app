﻿import { Utils } from '../utils';

export class GranularityCellModel {

    value: number;
    editable: boolean;
    displayValue: string;

    constructor() {
        this.value = 0;
        this.editable = false;
        this.displayValue = Utils.formatCurrency(this.value);
    }
}