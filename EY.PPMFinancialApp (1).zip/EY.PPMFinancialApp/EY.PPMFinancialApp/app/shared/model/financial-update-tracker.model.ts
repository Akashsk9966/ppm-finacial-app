﻿import { TreeNode } from 'primeng/primeng';

export class FinancialUpdateTrackerModel {

    entityUID: SP.Guid;
    entityName: string;
    financialValueListUID: SP.Guid;
    listItemId: number;
    updateStatus: string;
    financialTemplateName: string;

    constructor() {
    }
}