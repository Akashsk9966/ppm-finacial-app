﻿import { Utils } from '../utils';

export class FinancialTemplate {

    public financialTemplateListUID: SP.Guid;
    public name: string;
    public structure: string;
    public financialStartDate: Date;
    public financialEndDate: Date;
    public granularity: string;
    public granularityStartMonth: string;
    public granularityStartMonthAsNumber: number;

    constructor() {

        this.granularityStartMonth = Utils.getDefaultTimescaleStartMonth();
    }
}