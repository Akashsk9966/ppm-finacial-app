﻿import { TreeNode } from 'primeng/primeng';

export class FinancialNode implements TreeNode {

    id: string;
    parentId: string;
    label?: string;
    shortLabel ?: string;
    isValid?: boolean;
    children?: FinancialNode[];
    expanded?: boolean;
    parent?: FinancialNode;
    draggable?: boolean;
    droppable?: boolean;
    selectable?: boolean;
    customFieldMap?: {
        customFieldUid: string
        aggregationType: string,
        startYear?: number,
        startMonth?: number,
        endYear?: number,
        endMonth?: number
    }[]
     
    constructor() {
    }
}