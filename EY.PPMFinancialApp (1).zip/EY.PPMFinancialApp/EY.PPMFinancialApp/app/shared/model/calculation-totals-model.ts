﻿//export class CalculationTotals {

//    public level: number;
//    public nodeTotals: { [key: string]: number };

//    public childs: Array<CalculationTotals>;
    
//    constructor() {
//        this.nodeTotals = {};
//        this.childs = new Array<CalculationTotals>();
//    }
//}


export class CalculationTotals {

    public id: string;
    public parentId: string;
    public nodeName: string;
    public value: number; 

    public cfyEAC: number;
    public cfyBudget: number;
    public cfyVariance: number;

    //public cellcolor: string;

}