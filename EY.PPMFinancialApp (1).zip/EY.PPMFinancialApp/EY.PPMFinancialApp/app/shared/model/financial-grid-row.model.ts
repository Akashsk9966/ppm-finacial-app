﻿import { TreeNode } from 'primeng/primeng';
import { GranularityCellModel } from './granularity-cell.model';

export class FinancialGridRowModel {

    id: string;
    parentId: string;
    hasChildren: boolean;
    label: string;
    shortLabel: string;
    children: { [nodeID: string]: FinancialGridRowModel };
    extendedGranularityStructure: { [year: string]: { [month: string]: GranularityCellModel } };
    customFieldMap?: {
        customFieldUid: string,
        aggregationType: string,
        startYear?: number,
        startMonth?: number,
        endYear?: number,
        endMonth?: number
    }[]
    constructor() {
        this.children = {};
    }

    public getValue(rowIndex: number) {
    }
}