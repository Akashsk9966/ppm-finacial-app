﻿import { AppSettings } from './app-settings';
import { FinancialValue } from './model/financial-value.model';
import { GranularityCellModel } from './model/granularity-cell.model';
import { GranularityTypeEnum } from './granularity-type.enum'
//import { ProjectGranularityTypeEnum } from './granularity-type.enum'
import moment from 'moment';

export class Utils {

    // TODO: maybe tweek the offset to take into consideration the message row.
    static defaultGridSizeValues = {
        granularityColumnDefaultWidth: 150,
        granularityColumnDefaultHeight: 24,
        labelsCollumnWidth: 300,
        offset: 200
    }


    static defaultProjectGridSizeValues = {
        granularityColumnDefaultWidth: 75,
        granularityColumnDefaultHeight: 24,
        labelsCollumnWidth: 270,
        offset: 200
    }

    static getQueryStringParameter(paramToRetrieve: string) {
        var params = document.URL.split("?")[1].split("&");
        var strParams = "";
        for (var i = 0; i < params.length; i = i + 1) {
            var singleParam = params[i].split("=");
            if (singleParam[0] === paramToRetrieve)
                return singleParam[1];
        }
    }

    static getMomentReference() {
        var momentRef = (<any>window).moment;
        var navigator
        if (!momentRef) {
            momentRef = moment;
        }

        var language = "en";

        // If on IE get the locale from another property.
        if (window.navigator.userAgent.search("MSIE")) {
            language = (<any>window.navigator).userLanguage;
        } else {
            language = window.navigator.language;
        }

        momentRef.locale(language);

        return momentRef;
    }

    static getDateFormat() {
        var currentDateFormat = "mm/dd/yy";
        currentDateFormat = this.getMomentReference().localeData().longDateFormat("L");
        // we need this for primeNG compatibility
        currentDateFormat = currentDateFormat.toLowerCase().replace("yyyy", "yy")
        return currentDateFormat;
    }

    // PreimNG locale is different from moment locale. We need to make the transition manually.
    static getCurrentLocale() {

        var localeData = this.getMomentReference().localeData();

        var defaultLocale = {
            firstDayOfWeek: 0,
            dayNames: ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"],
            dayNamesShort: ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"],
            dayNamesMin: ["Su", "Mo", "Tu", "We", "Th", "Fr", "Sa"],
            monthNames: ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"],
            monthNamesShort: ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"],
            today: 'Today',
            clear: 'Clear'
        };

        if (!localeData) {
            return defaultLocale;
        }

        var currentLocale = {
            firstDayOfWeek: 0,
            dayNames: localeData._weekdays,
            dayNamesShort: localeData._weekdaysShort,
            dayNamesMin: localeData._weekdaysMin,
            monthNames: localeData._months,
            monthNamesShort: localeData._monthsShort,
            today: 'Today',
            clear: 'Clear'
        };

        return currentLocale;
    }
    // Default Month would be January. But this is only valid for US locale (English language locale) and not fo foreign locales.
    static getDefaultTimescaleStartMonth() {
        return this.getMomentReference().months()[0];
    }
    // Default number would be 0 because of moment.
    static getDefaultTimescaleStartMonthAsNumber() {
        return 0;
    }

    static isNumber(value: any) {
        var parsedValue;
        var isValidNumber = false;

        if (!isNaN(value)) {
            parsedValue = parseFloat(value);
            if (parsedValue != NaN) {
                if (parsedValue < Number.MAX_SAFE_INTEGER && parsedValue > Number.MIN_SAFE_INTEGER) {
                    isValidNumber = true;
                }
            }
        }

        return isValidNumber;
    }


    static formatCurrency(value: number) {

        if (!isNaN(value)) {
            //return value.toLocaleString('en-US', { style: "currency", currency: "USD", maximumFractionDigits: 0 });
            if (Intl) {
                var formatter = new Intl.NumberFormat('en-US', {
                    style: 'currency',
                    currency: 'USD',
                    minimumFractionDigits: 0,
                    maximumFractionDigits: 2
                });
                var dollarValue = formatter.format(value);
                if (dollarValue.indexOf("-") > -1) {

                    return "(" + dollarValue.replace("-", "") + ")";
                }
                else {
                    return dollarValue;
                }

            } else {
                var dollarValue = value.toLocaleString('en-US', { style: "currency", currency: "USD", maximumFractionDigits: 0 });
                if (dollarValue.indexOf("-") > -1) {

                    return "(" + dollarValue.replace("-", "") + ")";
                }
                else {
                    return dollarValue;
                }
            }
        }
        return "";
    }

    // Make sure any extra characters are removed and parse the value taking into account the ',' and '.' characters.
    static sanitizeNumberValue(value: string) {
        //**Regex to allow positive numbers only**
        var valueStr = value.replace(/[^0-9.,]+/g, "");

        //**Regex to allow both positive and negative numbers**
        //var valueStr = value.replace(/[^0-9.,-]+/g, "");

        var cleanValue = "";
        var commaSplitValues = valueStr.split(',');

        if (commaSplitValues.length > 1) {
            var poz = 0;
            for (var splitValue of commaSplitValues) {

                var dotIndex = splitValue.indexOf('.');

                if (dotIndex != -1) {
                    splitValue = splitValue.substring(0, dotIndex);
                }

                if (poz > 0 && splitValue.length != 3) {
                    return null;
                }

                if (!Utils.isNumber(splitValue)) {
                    return null;
                }
                cleanValue = cleanValue + splitValue;
                poz++;
            }
        } else {
            cleanValue = valueStr;
        }

        var dotSplitValues = valueStr.split('.');
        if (dotSplitValues.length > 1) {
            if (dotSplitValues.length != 2) {
                return null;
            }

            if (!Utils.isNumber(dotSplitValues[1])) {
                return null;
            }

            cleanValue = cleanValue + "." + dotSplitValues[1];
        }

        return cleanValue;
    }


    static sanitizeNumberValueProjects(value: string) {
        //**Regex to allow positive numbers only**
        //var valueStr = value.replace(/[^0-9.,]+/g, "");

        //**Regex to allow both positive and negative numbers**
        var valueStr = value.replace(/[^0-9.,-]+/g, "");

        var cleanValue = "";
        var commaSplitValues = valueStr.split(',');

        if (commaSplitValues.length > 1) {
            var poz = 0;
            for (var splitValue of commaSplitValues) {

                var dotIndex = splitValue.indexOf('.');

                if (dotIndex != -1) {
                    splitValue = splitValue.substring(0, dotIndex);
                }

                if (poz > 0 && splitValue.length != 3) {
                    return null;
                }

                if (!Utils.isNumber(splitValue)) {
                    return null;
                }
                cleanValue = cleanValue + splitValue;
                poz++;
            }
        } else {
            cleanValue = valueStr;
        }

        var dotSplitValues = valueStr.split('.');
        if (dotSplitValues.length > 1) {
            if (dotSplitValues.length != 2) {
                return null;
            }

            if (!Utils.isNumber(dotSplitValues[1])) {
                return null;
            }

            cleanValue = cleanValue + "." + dotSplitValues[1];
        }

        return cleanValue;
    }

    static computeExtendedGranularityStructure(financialStartDate: Date, financialEndDate: Date, newFinancialStartMonth: number, newFinancialEndMonth: number, selectedGranularity: string): { [year: string]: { [month: string]: GranularityCellModel } } {

        console.log("inside computeExtendedGranularityStructure   financialStartDate - ", financialStartDate);
        console.log("inside computeExtendedGranularityStructure   financialEndDate - ", financialEndDate);
        console.log("inside computeExtendedGranularityStructure   newFinancialStartMonth - ", newFinancialStartMonth);
        console.log("inside computeExtendedGranularityStructure   newFinancialEndMonth - ", newFinancialEndMonth);

        var momentRef = this.getMomentReference();
        var momentStartDate = momentRef(financialStartDate);
        var momentEndDate = momentRef(financialEndDate);
        var extendedGranularityStructure = {};

        //console.log("inside computeExtendedGranularityStructure   momentStartDate - ", momentStartDate);
        //console.log("inside computeExtendedGranularityStructure   momentEndDate - ", momentEndDate);
        //console.log("financialStartDate.getMonth() - ", financialStartDate.getMonth());

        var currentYear = 0;
        var currentMonth = 0;

        var counterStart = newFinancialStartMonth;
        var counterEnd = newFinancialEndMonth;
        
        var totalMonths = 0;

        if (newFinancialStartMonth != momentStartDate.month() || newFinancialEndMonth != momentEndDate.month()) {

            if (newFinancialStartMonth != momentStartDate.month()) {
                if ((financialStartDate.getMonth() == 11 && newFinancialStartMonth == 0) ) {
                    financialStartDate.setMonth(newFinancialStartMonth);
                    var year = momentStartDate.year();
                    financialStartDate.setFullYear(year + 1);
                    momentStartDate = momentRef(financialStartDate);
                    console.log("financialStartDate - on 31 dec", financialStartDate);
                }
                else if (financialStartDate.getMonth() == 0 && newFinancialStartMonth == 11) {
                    financialStartDate.setMonth(newFinancialStartMonth);
                    var year = momentStartDate.year();
                    financialStartDate.setFullYear(year - 1);
                    momentStartDate = momentRef(financialStartDate);
                    console.log("financialStartDate - on 31 dec", financialStartDate);
                }
                else {
                    financialStartDate.setMonth(newFinancialStartMonth);
                    momentStartDate = momentRef(financialStartDate);
                }
            }
            console.log("financialEndDate.toString() - ", financialEndDate.toString());
            
            if (newFinancialEndMonth != momentEndDate.month()) {
                if (financialEndDate.getMonth() == 11 && newFinancialEndMonth == 0 ) {
                    financialEndDate.setMonth(newFinancialEndMonth);
                    var year = momentEndDate.year();
                    financialEndDate.setFullYear(year + 1);
                    momentEndDate = momentRef(financialEndDate);
                    console.log("financialEndDate - on 31 dec", financialEndDate);
                }
                else if (financialEndDate.getMonth() == 0 && newFinancialEndMonth == 11) {
                    financialEndDate.setMonth(newFinancialEndMonth);
                    var year = momentEndDate.year();
                    financialEndDate.setFullYear(year - 1);
                    momentEndDate = momentRef(financialEndDate);
                    console.log("financialEndDate - on 31 dec", financialEndDate);
                }
                else {

                    financialEndDate.setMonth(newFinancialEndMonth);
                    momentEndDate = momentRef(financialEndDate);
                    console.log("momentEndDate - After Change", momentEndDate);
                }
               
            }
            
            
            totalMonths = this.getNumberOfMonths(momentStartDate.year(), momentStartDate.month(), momentEndDate.year(), momentEndDate.month());
            console.log("totalMonths:- ", totalMonths);
            //for testing
            //totalMonths = 17;

            while (totalMonths > 0) {
                
                currentYear = momentStartDate.year();
                if (counterStart == 12) {
                    counterStart = 0;
                }
                currentMonth = counterStart;//momentStartDate.month();
        
                    if (!extendedGranularityStructure[currentYear]) {
                        extendedGranularityStructure[currentYear] = {};
                    }

               
                    extendedGranularityStructure[currentYear][currentMonth] = new GranularityCellModel();

                    momentStartDate.add(1, "month");
                 
                counterStart = counterStart + 1;
                totalMonths = totalMonths - 1;
                }
        }
        else {
            while (momentStartDate.isSameOrBefore(momentEndDate, "month")) {
                currentYear = momentStartDate.year();
                currentMonth = momentStartDate.month();
            
                if (!extendedGranularityStructure[currentYear]) {
                    extendedGranularityStructure[currentYear] = {};
                }

       
                extendedGranularityStructure[currentYear][currentMonth] = new GranularityCellModel();

                momentStartDate.add(1, "month");
                
            }
        }

        console.log("extendedGranularityStructure:- ", extendedGranularityStructure);

        return extendedGranularityStructure;
    }


    static getNumberOfMonths(startYear: number, startMonth: number, endYear: number, endMonth: number) {
     
        var values = 12 * (endYear - startYear);
        if (startMonth > endMonth) {
            values = values - (startMonth - endMonth);
        } else {
            values = values + (endMonth - startMonth);
        }

        return values + 1;
    }

    static getMonthsBetween(startDate: Date, endDate: Date) {
        var momentRef = this.getMomentReference();
        var momentStartDate = momentRef(startDate);
        var momentEndDate = momentRef(endDate);

        var timeValues = 0;

        while (momentStartDate.isSameOrBefore(momentEndDate, 'month')) {
            timeValues++;
            momentStartDate.add(1, 'month');
        }

        return timeValues;
    }

    static getGranularityTypes(): Array<string> {
        var allgranularities = new Array<string>();

        for (var enumMember in GranularityTypeEnum) {
            allgranularities.push(GranularityTypeEnum[enumMember]);
        }

        return allgranularities;
    }

    //static getProjectGranularityTypes(): Array<string> {
    //    var allgranularities = new Array<string>();

    //    for (var enumMember in ProjectGranularityTypeEnum) {
    //        allgranularities.push(ProjectGranularityTypeEnum[enumMember]);
    //    }

    //    return allgranularities;
    //}

    static sortArryByProp<T>(array:Array<T>,propToSort:string): Array<T> {
        
        var srt = function (property:string) {
            var sortOrder = 1;
            if (property[0] === "-") {
                sortOrder = -1;
                property = property.substr(1);
            }
            return function (a:T, b:T) {
                var result = (a[property].toLowerCase() < b[property].toLowerCase()) ? -1 : (a[property].toLowerCase() > b[property].toLowerCase()) ? 1 : 0;
                return result * sortOrder;
            }
        }
        

        var sortedArray = array.sort(srt(propToSort));

        return sortedArray;

    }

    static getDefaultRootID(): string {
        return "ROOT";
    }

    static getNoneRootID(): string {
        return "NONE";  
    }


}