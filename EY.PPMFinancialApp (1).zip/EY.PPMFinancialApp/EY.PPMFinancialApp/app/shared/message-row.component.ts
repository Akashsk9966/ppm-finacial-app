﻿import { Component, Input } from '@angular/core';
import { MessageRow } from './model/message-row.model';

@Component({
    selector: 'message-row',
    template: `<div class="row" 
                    *ngIf="messageRow.messageType !== 'Default'">
                    <div class="col-xs-9 col-sm-9 col-md-9 col-lg-9">
                        <div [class]="messageRow.messageClass"> 
                            <p *ngFor="let message of messageRow.messageTexts" [innerHTML] = "message"></p>
                        </div>
                    </div>
                </div>`
})
export class MessageRowComponent {
    @Input('messageRow') messageRow: MessageRow;
}