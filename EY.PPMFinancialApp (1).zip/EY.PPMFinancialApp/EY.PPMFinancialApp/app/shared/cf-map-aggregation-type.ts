﻿export class MapAggregationType {
    static readonly LIFETIME = 'Lifetime';
    static readonly FIRST_FY = 'FirstFY';
    static readonly TIMESPAN = 'Timespan';
}