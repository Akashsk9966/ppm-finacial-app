﻿export enum GranularityTypeEnum {
    Lifetime = "Lifetime",
    Years = "Years",
    CFY = "Current Fiscal Year (CFY)",
    Quarters = "Quarters",
    Months = "Months"
}

//export enum ProjectGranularityTypeEnum {
//    Lifetime = "Lifetime",
//    Years = "Years",
//    CFY = "Current Fiscal Year (CFY)",
//    Quarters = "Quarters",
//    Months = "Months"
//}