﻿export class AppSettings {

    static getEmptyGuid(): SP.Guid { return new SP.Guid("00000000-0000-0000-0000-000000000000"); }
    static getDefault(): string { return "Default"; }
    static getInfoMessage(): string { return "Info"; }
    static getSuccessMessage(): string { return "Success"; }
    static getErrorMessage(): string { return "Error"; }

    static getCriticalErrorMessage(): string { return "CriticalError"; }
    static getNoneValue(): string { return "None"; }

    static getPPMFinancialUpdateTrackerListName(): string { return "PPMFinancialUpdateTracker"; }
    static getPPMFinancialUpdateTrackerFinancialValueListUIDColumn(): string { return "FinancialValueListUID"; }
    static getPPMFinancialUpdateTrackerTemplateNameColumn(): string { return "FinancialTemplateName"; }
    static getPPMFinancialUpdateTrackerEntityNameColumn(): string { return "EntityName"; }

    static getPPMFinancialSnapshotsListName(): string { return "PPMFinancialSnapshots"; }
    static getPPMFinancialTemplateListName(): string { return "PPMFinancialTemplate"; }
    static getPPMFinancialTemplateNameColumn(): string { return "Name"; }
    static getPPMFinancialTemplateListUIDColumn(): string { return "FinancialTemplateListUID"; }

    static getFinancialValueEntityNameColumn(): string { return "EntityName"; }
    static getFinancialStructureColumn(): string { return "Structure"; }
    static getFinancialNameColumn(): string { return "Name"; }
    static getFinancialValueStructureColumn(): string { return "FinancialValuesStructure"; }
    static getFinancialValueEntityUIDColumn(): string { return "EntityUID"; }
    static getFinancialValueListItemIdColumn(): string { return "ListItemId"; }
    static getFinancialValueStartMonthColumn(): string { return "StartMonth"; }
    static getFinancialValueUpdateStatusColumn(): string { return "UpdateStatus"; }
    static getFinancialValueUpdateStartDateColumn(): string { return "UpdateStartDate"; }
    static getFinancialValueUpdateEndDateColumn(): string { return "UpdateEndDate"; }

    static getUpdateFromImportFile(): string { return "Update through Import File"; }
    static getUpdateInProgress(): string { return "Pending"; }
    static getUpdateFailed(): string { return "Failed"; }
    static getUpdateFinishedSuccessfully(): string { return "Finished Successfully"; }
    static getUpdateSuspended(): string { return "Suspended"; }

    static getTitleColumn(): string { return "Title"; }
    static getFinancialStartDateColumn(): string { return "FinancialStartDate"; }
    static getFinancialEndDateColumn(): string { return "FinancialEndDate"; }
    static getFiscalMonthStartDateColumn(): string { return "FiscalMonthStartDate"; }
    static getFiscalMonthEndDateColumn(): string { return "FiscalMonthEndDate"; }
    static getGranularityColumn(): string { return "Granularity"; }
    static getGranularityStartMonthColumn(): string { return "StartMonth"; }
    static getFinancialValuesAdminGroup(): string { return "Financial Values Admin"; }

    static getProjectFinancialListName(): string { return "PlanForecastActuals"; }
    static getPlanForecastModifiedColumn(): string { return "PlanForecastLastModified"; }
    static getPlanTotalColumn(): string { return "PlanTotal"; }
    static getForecastTotalColumn(): string { return "ForecastTotal"; }
    static getPlanLastModifiedColumn(): string { return "PlanLastModified"; }
    static getForecastLastModifiedColumn(): string { return "ForecastLastModified"; }
    static getPlanModifiedbyColumn(): string { return "PlanModifiedby"; }
    static getForecastModifiedbyColumn(): string { return "ForecastModifiedby"; }
}