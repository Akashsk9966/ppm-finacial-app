import { Component, OnInit, Input, ComponentFactoryResolver, ViewChild, ViewContainerRef } from '@angular/core';
import { Utils } from './shared/utils';

import { FinancialValuesComponent } from './financial_values/financial-values.component';
import { ProjectFinancialValuesComponent } from './financial_values/projectfinancial-values.component';

@Component({
    selector: 'ppm-financial-app',
    template: `<div #componentContainer> </div>`
})
export class AppComponent implements OnInit {
    @ViewChild('componentContainer', { read: ViewContainerRef }) dynamicComponent: ViewContainerRef;

    constructor(private componentFactoryResolver: ComponentFactoryResolver) {
    }

    ngOnInit() {
        var component = Utils.getQueryStringParameter("component");
        var financialTemplateName = Utils.getQueryStringParameter("financialTemplateName");
        if (component === 'financialValues' && financialTemplateName !== 'PlanForecastActuals') {
            this.loadDynamicForm(FinancialValuesComponent);
        } else if (component === 'financialValues' && financialTemplateName === 'PlanForecastActuals') {
            this.loadDynamicForm(ProjectFinancialValuesComponent);
        }
    }

    private loadDynamicForm(formComponent: any): void {
        var vm = this;

        if (!vm.dynamicComponent) {
            return;
        }

        let componentFactory = vm.componentFactoryResolver.resolveComponentFactory(formComponent);

        vm.dynamicComponent.clear();

        let componentRef = vm.dynamicComponent.createComponent(componentFactory);
        componentRef.changeDetectorRef.detectChanges();
    }
}
