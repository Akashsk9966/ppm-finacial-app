﻿import { GranularityCellModel } from '../../shared/model/granularity-cell.model';
import { FlatFinancialGridRowModel } from '../../shared/model/flat-financial-grid-row.model';
import { FinancialGridRowModel } from '../../shared/model/financial-grid-row.model';
import { GranularityHandlerStrategy } from './granularity-handler-strategy'
import { Utils } from '../../shared/utils'

export class MonthsGranularityHandler extends GranularityHandlerStrategy {

    constructor() {
        super();
    }

    public getGridCellInfoDataProjects(flatFinancialGridRowId: string, financialGridRowNode: FinancialGridRowModel, oldValuesJSON: string) {

         var cellInfo: {
            cellModel: GranularityCellModel;
            shadowNodeReferenceKeys: Array<{
                year: string;
                months: Array<string>;
            }>
        }[] = [];

        var isEditable = Object.keys(financialGridRowNode.children).length <= 0 && this.isGranularityEditable && this.isCheckedOutToCurrentUser && this.isGridEditable;

        var currentMonthMet = false;
        var curDate = new Date();
        for (var year in financialGridRowNode.extendedGranularityStructure) {
            
            for (var month in financialGridRowNode.extendedGranularityStructure[year]) {
                var shadowNodeReference = {
                    year: year,
                    months: new Array<string>()
                }

                shadowNodeReference.months.push(month);
                var granularityCell = new GranularityCellModel();

                //***Added by Naresh for performance***
                granularityCell.editable = isEditable;
                //if (financialGridRowNode.label.indexOf("Total") > -1 || financialGridRowNode.label.indexOf("Actual") > -1) {
                //    granularityCell.editable = false;
                //}

                //if (financialGridRowNode.label.indexOf("Forecast") > -1) {

                //    if (year == curDate.getFullYear().toString() && month == curDate.getMonth().toString()) {

                //        granularityCell.editable = isEditable;
                //        currentMonthMet = true;

                //    }
                //    else if (currentMonthMet || +year > curDate.getFullYear()) {
                //        granularityCell.editable = isEditable;
                //    }
                //    else {
                //        //Note - Set to true if previous values for forecast needs to edited from grid
                //        granularityCell.editable = false;
                //    }

                //}

                //if (financialGridRowNode.label.indexOf("Plan") > -1) {

                //}

                //*** for performace 
                granularityCell.value = this.getFlatNodeValue([shadowNodeReference], flatFinancialGridRowId);
                granularityCell.displayValue = Utils.formatCurrency(granularityCell.value);

                cellInfo.push({ cellModel: granularityCell, shadowNodeReferenceKeys: [shadowNodeReference] });
            }
        }

        return cellInfo;
    }

    public getGridCellInfoData(flatFinancialGridRowId: string, financialGridRowNode: FinancialGridRowModel) {
        var cellInfo: {
            cellModel: GranularityCellModel;
            shadowNodeReferenceKeys: Array<{
                year: string;
                months: Array<string>;
            }>
        }[] = [];

        var isEditable = Object.keys(financialGridRowNode.children).length <= 0 && this.isGranularityEditable && this.isCheckedOutToCurrentUser && this.isGridEditable;

      
        for (var year in financialGridRowNode.extendedGranularityStructure) {
            for (var month in financialGridRowNode.extendedGranularityStructure[year]) {
                var shadowNodeReference = {
                    year: year,
                    months: new Array<string>()
                }

                shadowNodeReference.months.push(month);
                var granularityCell = new GranularityCellModel();

                granularityCell.editable = isEditable;
                granularityCell.value = this.getFlatNodeValue([shadowNodeReference], flatFinancialGridRowId);
                granularityCell.displayValue = Utils.formatCurrency(granularityCell.value);
            
                cellInfo.push({ cellModel: granularityCell, shadowNodeReferenceKeys: [shadowNodeReference] });
            }
        }

        return cellInfo;
    }

    public getGranularityHeaderLabels(financialStartDate: Date, financialEndDate: Date, granularity: string, newCurrentFiscalMonthNumber: number, newFinancialStartMonth: number, newFinancialEndMonth: number): Array<string> {

        console.log("getGranularityHeaderLabels - newCurrentFiscalMonthNumber - ", newCurrentFiscalMonthNumber);
        console.log("getGranularityHeaderLabels - newFinancialStartMonth - ", newFinancialStartMonth);
        console.log("getGranularityHeaderLabels - newFinancialEndMonth - ", newFinancialEndMonth);

        var vm = this;
        var totalNumberOfMonth = 0;
        var startMonth = 0;
        startMonth = newFinancialStartMonth;
        var startYear = financialStartDate.getFullYear();

        if ((financialStartDate.getMonth() == 12 && startMonth == 0)) {
            startMonth = newFinancialStartMonth;
            startYear = startYear + 1;
            console.log("financialStartDate - on 31 dec", financialStartDate);
        }
        else if (financialStartDate.getMonth() == 12 && startMonth == 11) {
            startMonth = newFinancialStartMonth;
            startYear = startYear - 1;
            console.log("financialStartDate - on 31 dec", financialStartDate);
        }
        else 
            startMonth = newFinancialStartMonth;

        var endMonth = 0;
        var endYear = financialEndDate.getFullYear();
        endMonth = newFinancialEndMonth;

        if ((financialEndDate.getMonth() == 12 && endMonth == 0)) { 
            endMonth = newFinancialEndMonth;
            endYear = endYear + 1;
            console.log("financialEndDate - on 31 dec", financialEndDate);
        }
        else if ((financialEndDate.getMonth() == 12 && endMonth == 11)) {
            endMonth = newFinancialEndMonth;
            endYear = endYear - 1;
            console.log("financialEndDate - on 31 dec", financialEndDate);
        }
        else
            endMonth = newFinancialEndMonth;
       
        
        console.log("getGranularityHeaderLabels - endYear - ", endYear);
        console.log("getGranularityHeaderLabels - endMonth - ", endMonth);

        totalNumberOfMonth = this.getNumberOfMonths(startYear, startMonth, endYear, endMonth);
        //for testing
        console.log("totalNumberOfMonth -", totalNumberOfMonth);
        //totalNumberOfMonth = 17;
        console.log("totalNumberOfMonth = 17 -", totalNumberOfMonth);
        var monthOffset = this.getMonthOffsetValue();
        return this.getColumnHeaderLabels(totalNumberOfMonth , startMonth, startYear, monthOffset);
    }

    private getColumnHeaderLabels(totalNumberOfMonth : number, startMonth: number, startYear: number, monthOffset: number): Array<string> {
        var granularityHeaderValues = new Array<string>();

        console.log("getColumnHeaderLabels - totalNumberOfMonth - ", totalNumberOfMonth);
        console.log("getColumnHeaderLabels - startMonth - ", startMonth);
        console.log("getColumnHeaderLabels - startYear - ", startYear);
        console.log("getColumnHeaderLabels - monthOffset - ", monthOffset);

        var allAvailableMonths = this.getAllAvailableMonths(totalNumberOfMonth , startMonth, true);

        for (var curentMonth of allAvailableMonths) {
            var monthAsNumber = this.momentRef().month(curentMonth).month();
            var fiscalTimescaleDetails = this.getFiscalTimescaleDetails(startYear, monthAsNumber, monthOffset)
            var monthValueText = `${curentMonth} FY${fiscalTimescaleDetails.currentFiscalYearValueShort}`;
            //console.log("monthValueText ", monthValueText);
            granularityHeaderValues.push(monthValueText);

            if (fiscalTimescaleDetails.shouldUpdateYear) {
                startYear++;
            }
        }

        //granularityHeaderValues.push("Total");
        return granularityHeaderValues;
    }
}