﻿
import { GranularityCellModel } from '../../shared/model/granularity-cell.model';
import { FlatFinancialGridRowModel } from '../../shared/model/flat-financial-grid-row.model';
import { FinancialGridRowModel } from '../../shared/model/financial-grid-row.model';
import { GranularityHandlerStrategy } from './granularity-handler-strategy'
import { Utils } from '../../shared/utils'

export class LifetimeGranularityHandler extends GranularityHandlerStrategy {

    constructor() {
        super();
    }

    public getGridCellInfoDataProjects(flatFinancialGridRowId: string, financialGridRowNode: FinancialGridRowModel, oldValuesJSON: string) {

        var cellInfo: {
            cellModel: GranularityCellModel;
            shadowNodeReferenceKeys: Array<{
                year: string;
                months: Array<string>;
            }>
        }[] = [];

        return cellInfo;
    }

    public getGridCellInfoData(flatFinancialGridRowId: string, financialGridRowNode: FinancialGridRowModel) {
        var cellInfo: {
            cellModel: GranularityCellModel;
            shadowNodeReferenceKeys: Array<{
                year: string;
                months: Array<string>;
            }>
        }[] = [];
        var isEditable = Object.keys(financialGridRowNode.children).length <= 0 && this.isGranularityEditable && this.isCheckedOutToCurrentUser && this.isGridEditable;

        var sReferenceKeys = [];

        for (var year in financialGridRowNode.extendedGranularityStructure) {

            var shadowNodeReference = {
                year: year,
                months: new Array<string>()
            }

            for (var month in financialGridRowNode.extendedGranularityStructure[year]) {
                shadowNodeReference.months.push(month);
            }

            sReferenceKeys.push(shadowNodeReference);
        }
        cellInfo.push(this.getCellInfoValue(flatFinancialGridRowId, sReferenceKeys, isEditable));
        return cellInfo;
    }

    public getGranularityHeaderLabels(financialStartDate: Date, financialEndDate: Date, granularity: string) {
        var values = 1;
        var granularityHeaderValues = new Array<string>();
        granularityHeaderValues.push("Lifetime");
        return granularityHeaderValues;
    }
}