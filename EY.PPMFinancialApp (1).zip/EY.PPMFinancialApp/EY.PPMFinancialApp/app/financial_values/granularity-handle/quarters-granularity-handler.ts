﻿import { GranularityCellModel } from '../../shared/model/granularity-cell.model';
import { FlatFinancialGridRowModel } from '../../shared/model/flat-financial-grid-row.model';
import { FinancialGridRowModel } from '../../shared/model/financial-grid-row.model';
import { GranularityHandlerStrategy } from './granularity-handler-strategy'
import { Utils } from '../../shared/utils'

export class QuartersGranularityHandler extends GranularityHandlerStrategy {

    constructor() {
        super();
    }

    public getGridCellInfoDataProjects(flatFinancialGridRowId: string, financialGridRowNode: FinancialGridRowModel, oldValuesJSON: string) {

        var cellInfo: {
            cellModel: GranularityCellModel;
            shadowNodeReferenceKeys: Array<{
                year: string;
                months: Array<string>;
            }>
        }[] = [];

        return cellInfo;
    }

    public getGridCellInfoData(flatFinancialGridRowId: string, financialGridRowNode: FinancialGridRowModel) {

        var isEditable = Object.keys(financialGridRowNode.children).length <= 0 && this.isGranularityEditable && this.isCheckedOutToCurrentUser && this.isGridEditable;
        var fiscalTimescaleData = this.getFiscalTimescaleData(financialGridRowNode, true);

        var cellInfo: {
            cellModel: GranularityCellModel;
            shadowNodeReferenceKeys: Array<{
                year: string;
                months: Array<string>;
            }>
        }[] = [];

        for (var quarterText in fiscalTimescaleData) {
            cellInfo.push(this.getCellInfoValue(flatFinancialGridRowId, fiscalTimescaleData[quarterText], isEditable));
        }

        return cellInfo;
    }

    public getGranularityHeaderLabels(financialStartDate: Date, financialEndDate: Date, granularity: string, newCurrentFiscalMonthNumber: number, newFinancialStartMonth: number, newFinancialEndMonth: number) {
      
        var vm = this;
        var totalNumberOfMonth = 0;
        var startMonth = 0;
        //var startMonth = financialStartDate.getMonth()
        startMonth = newFinancialStartMonth;
        var startYear = financialStartDate.getFullYear();

        var endMonth = 0;
        //var endMonth = financialEndDate.getMonth()
        endMonth = newFinancialEndMonth;
        var endYear = financialEndDate.getFullYear();

        totalNumberOfMonth = this.getNumberOfMonths(startYear, startMonth, endYear, endMonth);

        var monthOffset = this.getMonthOffsetValue();
        return this.getColumnHeaderLabels(totalNumberOfMonth, startMonth, startYear, monthOffset);
    }

    private getColumnHeaderLabels(totalNumberOfMonth: number, startMonth: number, startYear: number, monthOffset: number): Array<string> {
        var granularityHeaderValues = new Array<string>();
        var allAvailableMonths = this.getAllAvailableMonths(totalNumberOfMonth, startMonth, false);

        
        for (var i = 0; i < allAvailableMonths.length; i++) {
            var monthAsNumber = this.momentRef().month(allAvailableMonths[i]).month();
            var fiscalTimescaleDetails = this.getFiscalTimescaleDetails(startYear, monthAsNumber, monthOffset)
            var quarterValueText = `Q${fiscalTimescaleDetails.currentQuarterValue} FY${fiscalTimescaleDetails.currentFiscalYearValueShort}`;

            if (granularityHeaderValues.indexOf(quarterValueText) == -1) {
                granularityHeaderValues.push(quarterValueText);
            }

            if (fiscalTimescaleDetails.shouldUpdateYear) {
                startYear++;
            }

        }

        return granularityHeaderValues;
    }
}