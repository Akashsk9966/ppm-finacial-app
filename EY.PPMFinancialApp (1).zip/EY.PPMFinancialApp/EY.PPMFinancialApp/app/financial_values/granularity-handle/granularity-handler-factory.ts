﻿import { GranularityCellModel } from '../../shared/model/granularity-cell.model';
import { FlatFinancialGridRowModel } from '../../shared/model/flat-financial-grid-row.model';
import { FinancialGridRowModel } from '../../shared/model/financial-grid-row.model';
import { GranularityHandlerStrategy } from './granularity-handler-strategy'
import { LifetimeGranularityHandler } from './lifetime-granularity-handler'
import { YearsGranularityHandler } from './years-granularity-handler'
import { QuartersGranularityHandler } from './quarters-granularity-handler'
import { MonthsGranularityHandler } from './months-granularity-handler'
import { CFYGranularityHandler } from './cfy-granularity-handler'
import { GranularityTypeEnum } from '../../shared/granularity-type.enum'
//import { ProjectGranularityTypeEnum } from '../../shared/granularity-type.enum'
import { FinancialTemplate } from '../../shared/model/financial-template.model';

export class GranularityHandlerFactory {

    constructor() {
    }

    public getGranularityHandlerStrategy(granularityType: string,
        nodeReferenceDict: { [nodeId: string]: FinancialGridRowModel },
        financialTempalte: FinancialTemplate,
        isGranularityEditable: boolean,
        isCheckedOutToCurrentUser: boolean,
        isGridEditable: boolean,): GranularityHandlerStrategy {

        var granularityHandler: GranularityHandlerStrategy;

        if (granularityType == GranularityTypeEnum.Lifetime) {
            granularityHandler = new LifetimeGranularityHandler();
        } else if (granularityType == GranularityTypeEnum.Years) {
            granularityHandler = new YearsGranularityHandler();
        } else if (granularityType == GranularityTypeEnum.Quarters) {
            granularityHandler = new QuartersGranularityHandler();
        } else if (granularityType == GranularityTypeEnum.Months) {
            granularityHandler = new MonthsGranularityHandler();
        } else if (granularityType == GranularityTypeEnum.CFY) {
            granularityHandler = new CFYGranularityHandler();
        }
        //else if (granularityType == ProjectGranularityTypeEnum.CFY) {
        //    granularityHandler = new CFYGranularityHandler();
        //}

        granularityHandler.setNodeReference(nodeReferenceDict);
        granularityHandler.setFinancialTemplate(financialTempalte);
        granularityHandler.setIsGranularityEditable(isGranularityEditable);
        granularityHandler.setIsCheckedOutToCurrentUser(isCheckedOutToCurrentUser);
        granularityHandler.setIsGridEditable(isGridEditable);

        return granularityHandler;
    }
}
