﻿import { GranularityCellModel } from '../../shared/model/granularity-cell.model';
import { FlatFinancialGridRowModel } from '../../shared/model/flat-financial-grid-row.model';
import { FinancialGridRowModel } from '../../shared/model/financial-grid-row.model';
import { GranularityHandlerStrategy } from './granularity-handler-strategy'
import { Utils } from '../../shared/utils'

export class CFYGranularityHandler extends GranularityHandlerStrategy {

    constructor() {
        super();
    }

    public fiscalYearandMonths: Array<{
        year: string;
        months: Array<string>;
    }>;

    public startMonth:number;
    public startYear: number;
    public endMonth: number;
    public endYear: number;

    public fiscalyears: number[] = [];

    //Fiscal months of the start year
    public fiscalstartyearmonths: number[] = [6, 7, 8, 9, 10, 11];

    //Fiscal months of the end year
    public fiscalendyearmonths: number[] = [0, 1, 2, 3, 4, 5];
    public i: number;


    public getGridCellInfoDataProjects(flatFinancialGridRowId: string, financialGridRowNode: FinancialGridRowModel, oldValuesJSON: string) {

        //this.i = 0;
        var i = 0;
        var cellInfo: {
            cellModel: GranularityCellModel;
            shadowNodeReferenceKeys: Array<{
                year: string;
                months: Array<string>;
            }>
        }[] = [];


        for (var y of this.fiscalyears) {
            if (i == 0) {
                for (var m of this.fiscalstartyearmonths) {

                    if (financialGridRowNode.extendedGranularityStructure[y] != null) {
                        if (financialGridRowNode.extendedGranularityStructure[y][m] != null) {

                            var shadowNodeReference = {
                                year: y.toString(),
                                months: new Array<string>()
                            }

                            shadowNodeReference.months.push(m.toString());
                            var granularityCell = new GranularityCellModel();

                            granularityCell.editable = false;
                            granularityCell.value = this.getFlatNodeValue([shadowNodeReference], flatFinancialGridRowId);
                            granularityCell.displayValue = Utils.formatCurrency(granularityCell.value);
                            cellInfo.push({ cellModel: granularityCell, shadowNodeReferenceKeys: [shadowNodeReference] });

                        }

                        else {

                            var oldfinancialValuesStructure = JSON.parse(oldValuesJSON);

                            var find = oldfinancialValuesStructure.filter(function (element: any) {
                                return element.id == financialGridRowNode.id;
                            });
                            if (find.length >= 1) {
                                var value = find[0].vals.filter(function (element: any) {
                                    return element.yr == y && element.mth == m;
                                });
                                if (value.length >= 1) {

                                    var shadowNodeReference = {
                                        year: y.toString(),
                                        months: new Array<string>()
                                    }

                                    shadowNodeReference.months.push(m.toString());
                                    var granularityCell = new GranularityCellModel();

                                    granularityCell.editable = false;
                                    granularityCell.value = value[0].val;
                                    granularityCell.displayValue = Utils.formatCurrency(granularityCell.value);

                                    cellInfo.push({ cellModel: granularityCell, shadowNodeReferenceKeys: [shadowNodeReference] });
                                    //newExtendedStructure[newYear][newMonth] = new GranularityCellModel();
                                    //newExtendedStructure[newYear][newMonth].value = value[0].val;
                                    //newExtendedStructure[newYear][newMonth].displayValue = Utils.formatCurrency(newExtendedStructure[newYear][newMonth].value);
                                }
                                else {
                                    //newExtendedStructure[newYear][newMonth] = new GranularityCellModel();
                                    var shadowNodeReference = {
                                        year: y.toString(),
                                        months: new Array<string>()
                                    }

                                    shadowNodeReference.months.push(m.toString());
                                    var granularityCell = new GranularityCellModel();

                                    granularityCell.editable = false;
                                    granularityCell.value = 0;
                                    granularityCell.displayValue = Utils.formatCurrency(granularityCell.value);

                                    cellInfo.push({ cellModel: granularityCell, shadowNodeReferenceKeys: [shadowNodeReference] });
                                }
                            }
                            else {
                                //newExtendedStructure[newYear][newMonth] = new GranularityCellModel();

                                var shadowNodeReference = {
                                    year: y.toString(),
                                    months: new Array<string>()
                                }

                                shadowNodeReference.months.push(m.toString());
                                var granularityCell = new GranularityCellModel();

                                granularityCell.editable = false;
                                granularityCell.value = 0;
                                granularityCell.displayValue = Utils.formatCurrency(granularityCell.value);

                                cellInfo.push({ cellModel: granularityCell, shadowNodeReferenceKeys: [shadowNodeReference] });
                            }

                        }
                    }
                    else {

                        var oldfinancialValuesStructure = JSON.parse(oldValuesJSON);

                        var find = oldfinancialValuesStructure.filter(function (element: any) {
                            return element.id == financialGridRowNode.id;
                        });
                        if (find.length >= 1) {
                            var value = find[0].vals.filter(function (element: any) {
                                return element.yr == y && element.mth == m;
                            });
                            if (value.length >= 1) {

                                var shadowNodeReference = {
                                    year: y.toString(),
                                    months: new Array<string>()
                                }

                                shadowNodeReference.months.push(m.toString());
                                var granularityCell = new GranularityCellModel();

                                granularityCell.editable = false;
                                granularityCell.value = value[0].val;
                                granularityCell.displayValue = Utils.formatCurrency(granularityCell.value);

                                cellInfo.push({ cellModel: granularityCell, shadowNodeReferenceKeys: [shadowNodeReference] });
                                //newExtendedStructure[newYear][newMonth] = new GranularityCellModel();
                                //newExtendedStructure[newYear][newMonth].value = value[0].val;
                                //newExtendedStructure[newYear][newMonth].displayValue = Utils.formatCurrency(newExtendedStructure[newYear][newMonth].value);
                            }
                            else {
                                //newExtendedStructure[newYear][newMonth] = new GranularityCellModel();
                                var shadowNodeReference = {
                                    year: y.toString(),
                                    months: new Array<string>()
                                }

                                shadowNodeReference.months.push(m.toString());
                                var granularityCell = new GranularityCellModel();

                                granularityCell.editable = false;
                                granularityCell.value = 0;
                                granularityCell.displayValue = Utils.formatCurrency(granularityCell.value);

                                cellInfo.push({ cellModel: granularityCell, shadowNodeReferenceKeys: [shadowNodeReference] });
                            }

                        }
                        else {
                            var shadowNodeReference = {
                                year: y.toString(),
                                months: new Array<string>()
                            }

                            shadowNodeReference.months.push(m.toString());
                            var granularityCell = new GranularityCellModel();

                            granularityCell.editable = false;
                            granularityCell.value = 0;
                            granularityCell.displayValue = Utils.formatCurrency(granularityCell.value);

                            cellInfo.push({ cellModel: granularityCell, shadowNodeReferenceKeys: [shadowNodeReference] });
                        }
                    }

                    
                }

                i += 1;
            }
            else {

                for (var m of this.fiscalendyearmonths) {

                    if (financialGridRowNode.extendedGranularityStructure[y] != null) {
                        if (financialGridRowNode.extendedGranularityStructure[y][m] != null) {

                            var shadowNodeReference = {
                                year: y.toString(),
                                months: new Array<string>()
                            }

                            shadowNodeReference.months.push(m.toString());
                            var granularityCell = new GranularityCellModel();

                            granularityCell.editable = false;
                            granularityCell.value = this.getFlatNodeValue([shadowNodeReference], flatFinancialGridRowId);
                            granularityCell.displayValue = Utils.formatCurrency(granularityCell.value);
                            cellInfo.push({ cellModel: granularityCell, shadowNodeReferenceKeys: [shadowNodeReference] });

                        }

                        else {
                            var oldfinancialValuesStructure = JSON.parse(oldValuesJSON);

                            var find = oldfinancialValuesStructure.filter(function (element: any) {
                                return element.id == financialGridRowNode.id;
                            });
                            if (find.length >= 1) {
                                var value = find[0].vals.filter(function (element: any) {
                                    return element.yr == y && element.mth == m;
                                });
                                if (value.length >= 1) {

                                    var shadowNodeReference = {
                                        year: y.toString(),
                                        months: new Array<string>()
                                    }

                                    shadowNodeReference.months.push(m.toString());
                                    var granularityCell = new GranularityCellModel();

                                    granularityCell.editable = false;
                                    granularityCell.value = value[0].val;
                                    granularityCell.displayValue = Utils.formatCurrency(granularityCell.value);

                                    cellInfo.push({ cellModel: granularityCell, shadowNodeReferenceKeys: [shadowNodeReference] });
                                    //newExtendedStructure[newYear][newMonth] = new GranularityCellModel();
                                    //newExtendedStructure[newYear][newMonth].value = value[0].val;
                                    //newExtendedStructure[newYear][newMonth].displayValue = Utils.formatCurrency(newExtendedStructure[newYear][newMonth].value);
                                }
                                else {
                                    //newExtendedStructure[newYear][newMonth] = new GranularityCellModel();
                                    var shadowNodeReference = {
                                        year: y.toString(),
                                        months: new Array<string>()
                                    }

                                    shadowNodeReference.months.push(m.toString());
                                    var granularityCell = new GranularityCellModel();

                                    granularityCell.editable = false;
                                    granularityCell.value = 0;
                                    granularityCell.displayValue = Utils.formatCurrency(granularityCell.value);

                                    cellInfo.push({ cellModel: granularityCell, shadowNodeReferenceKeys: [shadowNodeReference] });
                                }
                            }
                            else {
                                //newExtendedStructure[newYear][newMonth] = new GranularityCellModel();

                                var shadowNodeReference = {
                                    year: y.toString(),
                                    months: new Array<string>()
                                }

                                shadowNodeReference.months.push(m.toString());
                                var granularityCell = new GranularityCellModel();

                                granularityCell.editable = false;
                                granularityCell.value = 0;
                                granularityCell.displayValue = Utils.formatCurrency(granularityCell.value);

                                cellInfo.push({ cellModel: granularityCell, shadowNodeReferenceKeys: [shadowNodeReference] });
                            }



                        }
                    }
                    else {

                        var oldfinancialValuesStructure = JSON.parse(oldValuesJSON);

                        var find = oldfinancialValuesStructure.filter(function (element: any) {
                            return element.id == financialGridRowNode.id;
                        });
                        if (find.length >= 1) {
                            var value = find[0].vals.filter(function (element: any) {
                                return element.yr == y && element.mth == m;
                            });
                            if (value.length >= 1) {

                                var shadowNodeReference = {
                                    year: y.toString(),
                                    months: new Array<string>()
                                }

                                shadowNodeReference.months.push(m.toString());
                                var granularityCell = new GranularityCellModel();

                                granularityCell.editable = false;
                                granularityCell.value = value[0].val;
                                granularityCell.displayValue = Utils.formatCurrency(granularityCell.value);

                                cellInfo.push({ cellModel: granularityCell, shadowNodeReferenceKeys: [shadowNodeReference] });
                                //newExtendedStructure[newYear][newMonth] = new GranularityCellModel();
                                //newExtendedStructure[newYear][newMonth].value = value[0].val;
                                //newExtendedStructure[newYear][newMonth].displayValue = Utils.formatCurrency(newExtendedStructure[newYear][newMonth].value);
                            }
                            else {
                                //newExtendedStructure[newYear][newMonth] = new GranularityCellModel();
                                var shadowNodeReference = {
                                    year: y.toString(),
                                    months: new Array<string>()
                                }

                                shadowNodeReference.months.push(m.toString());
                                var granularityCell = new GranularityCellModel();

                                granularityCell.editable = false;
                                granularityCell.value = 0;
                                granularityCell.displayValue = Utils.formatCurrency(granularityCell.value);

                                cellInfo.push({ cellModel: granularityCell, shadowNodeReferenceKeys: [shadowNodeReference] });
                            }

                        }
                        else {
                            var shadowNodeReference = {
                                year: y.toString(),
                                months: new Array<string>()
                            }

                            shadowNodeReference.months.push(m.toString());
                            var granularityCell = new GranularityCellModel();

                            granularityCell.editable = false;
                            granularityCell.value = 0;
                            granularityCell.displayValue = Utils.formatCurrency(granularityCell.value);

                            cellInfo.push({ cellModel: granularityCell, shadowNodeReferenceKeys: [shadowNodeReference] });
                            
                        }
                    }


                }

                //To move the year to next in FY
                //this.i = this.i + 1;

            }
            

        }
        return cellInfo;
    }


    public getGridCellInfoData(flatFinancialGridRowId: string, financialGridRowNode: FinancialGridRowModel) {

        this.i = 0;

        var cellInfo: {
            cellModel: GranularityCellModel;
            shadowNodeReferenceKeys: Array<{
                year: string;
                months: Array<string>;
            }>
        }[] = [];

        
        for (var y of this.fiscalyears) {  
                if (this.i == 0) {
                    for (var m of this.fiscalstartyearmonths) {

                        if (financialGridRowNode.extendedGranularityStructure[y] != null) {
                            if (financialGridRowNode.extendedGranularityStructure[y][m] != null) {

                                var shadowNodeReference = {
                                    year: y.toString(),
                                    months: new Array<string>()
                                }

                                shadowNodeReference.months.push(m.toString());
                                var granularityCell = new GranularityCellModel();

                                granularityCell.editable = false;
                                granularityCell.value = this.getFlatNodeValue([shadowNodeReference], flatFinancialGridRowId);
                                granularityCell.displayValue = Utils.formatCurrency(granularityCell.value);
                                cellInfo.push({ cellModel: granularityCell, shadowNodeReferenceKeys: [shadowNodeReference] });

                            }

                            else {

                                var shadowNodeReference = {
                                    year: y.toString(),
                                    months: new Array<string>()
                                }

                                shadowNodeReference.months.push(m.toString());
                                var granularityCell = new GranularityCellModel();
                                
                                granularityCell.editable = false;
                                granularityCell.value = 0;
                                granularityCell.displayValue = Utils.formatCurrency(granularityCell.value);

                                cellInfo.push({ cellModel: granularityCell, shadowNodeReferenceKeys: [shadowNodeReference] });

                            }
                        }
                        else {

                            var shadowNodeReference = {
                                year: y.toString(),
                                months: new Array<string>()
                            }

                            shadowNodeReference.months.push(m.toString());
                            var granularityCell = new GranularityCellModel();

                            granularityCell.editable = false;
                            granularityCell.value = 0;
                            granularityCell.displayValue = Utils.formatCurrency(granularityCell.value);

                            cellInfo.push({ cellModel: granularityCell, shadowNodeReferenceKeys: [shadowNodeReference] });

                        }
                    }
                }
                else {

                    for (var m of this.fiscalendyearmonths) {

                        if (financialGridRowNode.extendedGranularityStructure[y] != null) {
                            if (financialGridRowNode.extendedGranularityStructure[y][m] != null) {

                                var shadowNodeReference = {
                                    year: y.toString(),
                                    months: new Array<string>()
                                }

                                shadowNodeReference.months.push(m.toString());
                                var granularityCell = new GranularityCellModel();

                                granularityCell.editable = false;
                                granularityCell.value = this.getFlatNodeValue([shadowNodeReference], flatFinancialGridRowId);
                                granularityCell.displayValue = Utils.formatCurrency(granularityCell.value);
                                cellInfo.push({ cellModel: granularityCell, shadowNodeReferenceKeys: [shadowNodeReference] });

                            }

                            else {

                                var shadowNodeReference = {
                                    year: y.toString(),
                                    months: new Array<string>()
                                }

                                shadowNodeReference.months.push(m.toString());
                                var granularityCell = new GranularityCellModel();

                                granularityCell.editable = false;
                                granularityCell.value = 0;
                                granularityCell.displayValue = Utils.formatCurrency(granularityCell.value);

                                cellInfo.push({ cellModel: granularityCell, shadowNodeReferenceKeys: [shadowNodeReference] });

                            }
                        }
                        else {

                            var shadowNodeReference = {
                                year: y.toString(),
                                months: new Array<string>()
                            }

                            shadowNodeReference.months.push(m.toString());
                            var granularityCell = new GranularityCellModel();

                            granularityCell.editable = false;
                            granularityCell.value = 0;
                            granularityCell.displayValue = Utils.formatCurrency(granularityCell.value);

                            cellInfo.push({ cellModel: granularityCell, shadowNodeReferenceKeys: [shadowNodeReference] });

                        }
                    }


                }

            //To move the year to next in FY
                this.i = this.i + 1;
            
        }
        return cellInfo;

    }

    //public getGridCellInfoData1(flatFinancialGridRowId: string, financialGridRowNode: FinancialGridRowModel) {
    //    var cellInfo: {
    //        cellModel: GranularityCellModel;
    //        shadowNodeReferenceKeys: Array<{
    //            year: string;
    //            months: Array<string>;
    //        }>
    //    }[] = [];

    //    var i = 0;

    //    var isEditable = Object.keys(financialGridRowNode.children).length <= 0 && this.isGranularityEditable && this.isCheckedOutToCurrentUser && this.isGridEditable;

    //    //Prepend logic
    //    for (var year in financialGridRowNode.extendedGranularityStructure) {

    //        for (var month in financialGridRowNode.extendedGranularityStructure[year]) {
                
    //            var mon = +month;
    //            var sm = this.startMonth;
    //            if (mon != this.startMonth) {


    //                while (this.fiscalmonths.indexOf(mon) > i) {

    //                    var shadowNodeReference = {
    //                        year: year,
    //                        months: new Array<string>()
    //                    }

    //                    shadowNodeReference.months.push(sm.toString());
    //                    var granularityCell = new GranularityCellModel();

    //                    granularityCell.editable = isEditable;
    //                    granularityCell.value = 0;
    //                    granularityCell.displayValue = Utils.formatCurrency(granularityCell.value);

    //                    cellInfo.push({ cellModel: granularityCell, shadowNodeReferenceKeys: [shadowNodeReference] });
    //                    i++
    //                }

                    




    //            }
    //            break;
    //        }
    //        break;
    //    }




        

        
    //    for (var year in financialGridRowNode.extendedGranularityStructure) {

            

    //            for (var month in financialGridRowNode.extendedGranularityStructure[year]) {

    //                //while(month == this.startMonth.toString()) {

    //                    var shadowNodeReference = {
    //                        year: year,
    //                        months: new Array<string>()
    //                    }

    //                    shadowNodeReference.months.push(month);
    //                    var granularityCell = new GranularityCellModel();

    //                    granularityCell.editable = isEditable;
    //                    granularityCell.value = this.getFlatNodeValue([shadowNodeReference], flatFinancialGridRowId);
    //                    granularityCell.displayValue = Utils.formatCurrency(granularityCell.value);
    //                    cellInfo.push({ cellModel: granularityCell, shadowNodeReferenceKeys: [shadowNodeReference] });
    //                    i++;
    //                //}

    //            }
    //        //}
    //    }


    //    //Append Logic
    //    while (this.fiscalmonths.length > i) {

    //        var shadowNodeReference = {
    //            year: year,
    //            months: new Array<string>()
    //        }

    //        shadowNodeReference.months.push(sm.toString());
    //        var granularityCell = new GranularityCellModel();

    //        granularityCell.editable = isEditable;
    //        granularityCell.value = 1;
    //        granularityCell.displayValue = Utils.formatCurrency(granularityCell.value);

    //        cellInfo.push({ cellModel: granularityCell, shadowNodeReferenceKeys: [shadowNodeReference] });
    //        i++
    //    }



        

    //    return cellInfo;

       
        
    //}

    public getGranularityHeaderLabels(financialStartDate: Date, financialEndDate: Date, granularity: string, newCurrentFiscalMonthNumber: number, newFinancialStartMonth: number, newFinancialEndMonth: number): Array<string> {
 
        var vm = this;
        var totalNumberOfMonth = 0;
        this.startMonth = financialStartDate.getMonth();
        this.startYear = financialStartDate.getFullYear();
        this.endMonth = financialEndDate.getMonth();
        this.endYear = financialEndDate.getFullYear();

        if (this.startYear == this.endYear && this.startMonth >= 0 && this.endMonth <= 5){
            this.startYear = this.startYear - 1;
        }
        if (this.startYear == this.endYear && this.startMonth >= 6 && this.endMonth <= 11){
            this.endYear = this.endYear + 1;
        }

        var currentTime = new Date();

        //Get fiscal Year Calendar date from PPM

        //02 - Jul (7) - 2021

        var calendarFiscalDate = newCurrentFiscalMonthNumber;

        //if (currentTime.getMonth() >= 6) {
        if (calendarFiscalDate >= 6) {
            this.startYear = currentTime.getFullYear();         
        }

        else {
            this.startYear = currentTime.getFullYear() - 1;
        }

        this.startMonth = 6;
        this.endMonth = 5;
        this.endYear = this.startYear + 1;

        this.fiscalyears.push(this.startYear);
        this.fiscalyears.push(this.endYear);

        totalNumberOfMonth = 12;
        //totalNumberOfMonth = this.getNumberOfMonths(this.startYear, this.startMonth, this.endYear, this.endMonth);
        var monthOffset = this.getMonthOffsetValue();
        return this.getColumnHeaderLabels(totalNumberOfMonth, this.startMonth, this.startYear, monthOffset);
    }

    //To get the column header labels of the grid
    private getColumnHeaderLabels(totalNumberOfMonth: number, startMonth: number, startYear: number, monthOffset: number): Array<string> {
        var granularityHeaderValues = new Array<string>();

        var allAvailableMonths = this.getAllAvailableMonths(totalNumberOfMonth, startMonth, true);

        for (var curentMonth of allAvailableMonths) {
            var monthAsNumber = this.momentRef().month(curentMonth).month();
            var fiscalTimescaleDetails = this.getFiscalTimescaleDetails(startYear, monthAsNumber, monthOffset)
            var monthValueText = `${curentMonth} FY${fiscalTimescaleDetails.currentFiscalYearValueShort}`;
        
            granularityHeaderValues.push(monthValueText);
            
            if (fiscalTimescaleDetails.shouldUpdateYear) {
                startYear++;
            }
        }

        //granularityHeaderValues.push("Total");
        //granularityHeaderValues.push("CFY Budget");
        //granularityHeaderValues.push("CFY EAC");
        //granularityHeaderValues.push("CFY Variance");

        return granularityHeaderValues;
    }


    //private checkDatesExtendedBeyondFY(startMonth: number, startYear: number, flatFinancialGridRowId: string, financialGridRowNode: FinancialGridRowModel): boolean {

    //    for (var year in financialGridRowNode.extendedGranularityStructure) {

    //        if (startYear.toString() == year.toString()) {

    //            for (var month in financialGridRowNode.extendedGranularityStructure[year]) {
    //                if (startMonth.toString() == month.toString()) {
    //                }
    //            }
    //        }
    //    }
    //}


    //private getvalues(flatFinancialGridRowId: string, financialGridRowNode: FinancialGridRowModel) {

    //    for (var year in financialGridRowNode.extendedGranularityStructure) {

    //        if (startYear.toString() == year.toString()) {

    //            for (var month in financialGridRowNode.extendedGranularityStructure[year]) {
    //                if (startMonth.toString() == month.toString()) {
    //                }
    //            }
    //        }
    //    }
    //}
}