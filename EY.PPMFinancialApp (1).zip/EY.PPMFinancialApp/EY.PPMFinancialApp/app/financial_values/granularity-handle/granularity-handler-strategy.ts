﻿import { GranularityCellModel } from '../../shared/model/granularity-cell.model';
import { FlatFinancialGridRowModel } from '../../shared/model/flat-financial-grid-row.model';
import { FinancialGridRowModel } from '../../shared/model/financial-grid-row.model';
import { Utils } from '../../shared/utils';
import { FinancialTemplate } from '../../shared/model/financial-template.model';

export abstract class GranularityHandlerStrategy {

    nodeReferenceDict: { [nodeId: string]: FinancialGridRowModel };
    financialTemplate: FinancialTemplate;
    isGranularityEditable: boolean;
    isCheckedOutToCurrentUser: boolean;
    isGridEditable: boolean;
    momentRef: any;

    constructor() {
        this.momentRef = Utils.getMomentReference();
    }

    public setNodeReference(nodeReferenceDict: { [nodeId: string]: FinancialGridRowModel }) {
        this.nodeReferenceDict = nodeReferenceDict;
    }

    public setFinancialTemplate(financialTemplate: FinancialTemplate) {
        this.financialTemplate = financialTemplate;
    }

    public setIsGranularityEditable(isGranularityEditable: boolean) {
        this.isGranularityEditable = isGranularityEditable;
    }

    public setIsCheckedOutToCurrentUser(isCheckedOutToCurrentUser: boolean) {
        this.isCheckedOutToCurrentUser = isCheckedOutToCurrentUser;
    }

    public setIsGridEditable(isGridEditable: boolean) {
        this.isGridEditable = isGridEditable;
    }

    //  compute the CellInfo Array for the granularity cells of the grid.
    abstract getGridCellInfoData(flatFinancialGridRowId: string, financialGridRowNode: FinancialGridRowModel): { cellModel: GranularityCellModel; shadowNodeReferenceKeys: Array<{ year: string; months: Array<string>; }> }[];


    abstract getGridCellInfoDataProjects(flatFinancialGridRowId: string, financialGridRowNode: FinancialGridRowModel,oldJSON:string): { cellModel: GranularityCellModel; shadowNodeReferenceKeys: Array<{ year: string; months: Array<string>; }> }[];

    //abstract getGranularityHeaderLabels(financialStartDate: Date, financialEndDate: Date, granularity: string): Array<string>;

    abstract getGranularityHeaderLabels(financialStartDate: Date, financialEndDate: Date, granularity: string, currentMonth: number, newFinancialStartMonth: number, newFinancialEndMonth: number): Array<string>;

    protected getNumberOfMonths(startYear: number, startMonth: number, endYear: number, endMonth: number) {
  
        var values = 12 * (endYear - startYear);
        if (startMonth > endMonth) {
            values = values - (startMonth - endMonth);
        } else {
            values = values + (endMonth - startMonth);
        }

        return values + 1;
    }

    protected getAllAvailableMonths(totalNumberOfMonth: number, startMonth: number, isShortFormat: boolean): Array<string> {
        var allAvailableMonths = new Array<string>();

        for (var i = 0; i < totalNumberOfMonth; i++) {
            var curentMonth = "";
            if (!isShortFormat) {
                curentMonth = this.momentRef().localeData().months()[startMonth];
                //console.log("curentMonth - if - ", curentMonth);
            } else {
                curentMonth = this.momentRef().localeData().monthsShort()[startMonth];
                //console.log("curentMonth - else - ", curentMonth);
            }

            allAvailableMonths.push(curentMonth);
            startMonth++;

            if (startMonth == 12) {
                startMonth = 0;
            }
        }

        return allAvailableMonths;
    }

    public updateReferencedValues(flatFinancialNode: FlatFinancialGridRowModel, partitionIndex: number) {

        var nodeRef = this.nodeReferenceDict[flatFinancialNode.id];
        var divideByValue = 0;

        for (var shadowRef of flatFinancialNode.cellInfo[partitionIndex].shadowNodeReferenceKeys) {
            divideByValue += shadowRef.months.length;
        }

        if (divideByValue == 0) {
            return;
        }

        for (var shadowRef of flatFinancialNode.cellInfo[partitionIndex].shadowNodeReferenceKeys) {
            var newGranularityValue = flatFinancialNode.cellInfo[partitionIndex].cellModel.value;
            for (var month of shadowRef.months) {
                nodeRef.extendedGranularityStructure[shadowRef.year][month].value = newGranularityValue / divideByValue;
            }
        }
    }

    // Used only for th quarters and yearly fiscal data calculations.
    protected getFiscalTimescaleData(financialGridRowNode: FinancialGridRowModel, isQuarterGranularity: boolean) {
        // Used to keep track of the quarters and the months that are part of them.
        // The text used for the quarter headers is used as the key because it has all the data needed to keep track of the quarter and months.
        var fiscalTimescaleData: {
            [quarterValue: string]: Array<{
                year: string,
                months: Array<string>
            }>
        } = {}
        var monthOffset = this.getMonthOffsetValue();


        for (var year in financialGridRowNode.extendedGranularityStructure) {
            for (var month in financialGridRowNode.extendedGranularityStructure[year]) {
                var monthAsNumber = this.momentRef().month(month).month();
                var fiscalTimescaleDetails = this.getFiscalTimescaleDetails(parseInt(year), monthAsNumber, monthOffset);
                var dataKey = "";
                if (!isQuarterGranularity) {
                    dataKey = fiscalTimescaleDetails.currentFiscalYearValue.toString();
                } else {
                    dataKey = `Q${fiscalTimescaleDetails.currentQuarterValue} Fy${fiscalTimescaleDetails.currentFiscalYearValueShort}`;

                }

                if (fiscalTimescaleData[dataKey]) {

                    if (fiscalTimescaleData[dataKey][0].year == year) {
                        // If the month of the quarter is in the same year, just add it to the dictionary.
                        fiscalTimescaleData[dataKey][0].months.push(month);
                    } else {
                        if (fiscalTimescaleData[dataKey].length == 1) {
                            // If the month of the quarter has gone to the next year, another reference needs to be added.
                            fiscalTimescaleData[dataKey].push({
                                year: year,
                                months: [month]
                            });
                        } else {
                            // If the month of the quarter is in the same year, just add it to the dictionary.
                            fiscalTimescaleData[dataKey][1].months.push(month);
                        }
                    }

                } else {
                    // When a new quarter needs to be added to the dictionary.
                    fiscalTimescaleData[dataKey] = [];
                    fiscalTimescaleData[dataKey].push({ year: year, months: [month] });
                }

            }
        }

        return fiscalTimescaleData;
    }

    protected getMonthOffsetValue() {

        if (this.financialTemplate.granularityStartMonthAsNumber == Utils.getDefaultTimescaleStartMonthAsNumber()) {
            return 1;
        }

        var userDefinedStartDate = this.momentRef().month(this.financialTemplate.granularityStartMonthAsNumber);
        var defaultStartDate = this.momentRef().month(Utils.getDefaultTimescaleStartMonthAsNumber())
        return Utils.getMonthsBetween(defaultStartDate, userDefinedStartDate);
    }

    protected getCellInfoValue(flatFinancialGridRowId: string, shadowNodeReference: any, isEditable: boolean) {
        var granularityCell = new GranularityCellModel();

        granularityCell.editable = isEditable;
        granularityCell.value = this.getFlatNodeValue(shadowNodeReference, flatFinancialGridRowId);
        granularityCell.displayValue = Utils.formatCurrency(granularityCell.value);
        return { cellModel: granularityCell, shadowNodeReferenceKeys: shadowNodeReference };
    }

    protected getFlatNodeValue(shadowNodeReferenceKeys: any, flatNodeId: string): number {
        var nodeRef: FinancialGridRowModel = this.nodeReferenceDict[flatNodeId];

        if (!nodeRef) {
            return 0;
        }

        var aggrValue: number = 0;
        for (var shadowRef of shadowNodeReferenceKeys) {
            for (let index = 0; index < shadowRef.months.length; index++) {
                aggrValue += nodeRef.extendedGranularityStructure[shadowRef.year][shadowRef.months[index]].value;
            }
        }

        return Number(aggrValue.toFixed(2));
    }

    protected getFiscalTimescaleDetails(startYear: number, month: number, monthOffset: number) {
        var curentDate = this.momentRef().month(month);
        curentDate.year(startYear)
        var shouldUpdateYear = false;

        var momentFiscalQuarter = this.momentRef().month(month).year(startYear).fquarter(monthOffset);
        var currentQuarterValue = momentFiscalQuarter.quarter;

        var currentMonthValue = curentDate.month();
        var currentYearValue = curentDate.year();

        var currentFiscalMonthValue = monthOffset == 0 ? currentMonthValue + 1 : this.getFiscalMonth(currentYearValue, currentMonthValue + 1, monthOffset) - 1;

        var currentFiscalYearValue = momentFiscalQuarter.year;

        if (momentFiscalQuarter.nextYear) {
            currentFiscalYearValue = momentFiscalQuarter.nextYear;
        }

        var currentFiscalYearValueString = currentFiscalYearValue.toString();
        var currentFiscalYearValueShort = currentFiscalYearValueString.substr(2, currentFiscalYearValueString.length);

        if (currentMonthValue + 1 == 12) {
            shouldUpdateYear = true;
        }

        return {
            currentQuarterValue: currentQuarterValue,
            currentFiscalMonthValue: currentFiscalMonthValue,
            currentFiscalYearValue: currentFiscalYearValue,
            currentFiscalYearValueShort: currentFiscalYearValueShort,
            shouldUpdateYear: shouldUpdateYear
        }
    }

    protected getFiscalYear(year: number, month: number, monthOffset: number) {
        var fiscalYearOffset = month - monthOffset;
        var fiscalYear = fiscalYearOffset >= 0 ? year : (year - 1);

        return fiscalYear;
    }

    protected getFiscalMonth(year: number, month: number, off: number) {
        var fiscalMonth = month - off + 1;
        return fiscalMonth > 0 ? fiscalMonth : fiscalMonth + 12;
    }

}