﻿/// <reference path="../../typings/microsoft-ajax/microsoft.ajax.d.ts" />
/// <reference path="../../typings/sharepoint/sharepoint.d.ts" />
import { Component, Input, Output, EventEmitter, ViewEncapsulation, OnInit, ElementRef } from '@angular/core';

import { ConfirmDialogModule, ConfirmationService } from 'primeng/primeng';

import { Utils } from '../shared/utils';
import { AppSettings } from '../shared/app-settings';
import { SharePointService } from '../core/sharepoint.service';
import { FinancialTimescalePropertyModel } from '../shared/model/financial-timescale-property.model';

@Component({
    selector: 'financial-timescale-update',
    styleUrls: ['../Content/Styles/ppm-financial-app.css', '../Content/Styles/financial-values.css'],
    encapsulation: ViewEncapsulation.None,
    template: ` 
        <p-accordion>                                     
            <p-accordionTab header="The Start Date or End Date has changed. You need to select how values are to be adjusted in the grid.">
                <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12" *ngIf="!isCheckedOutToCurrentUser">
                    You need to check out the project first.
                </div>
                <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12" *ngIf="isCheckedOutToCurrentUser">
                    <div *ngIf="isCutAvailable">
                        <input type="checkbox" id="cutCheckBox"
                                [disabled]="isExtendChecked || isShiftChecked"
                                (change)="isCutChecked = !isCutChecked"
                                [checked]="isCutChecked"/>
                        <label for="cutCheckBox">Cut </label>
                        <i> - All financial values outside the current timeline will be ignored </i>
                    </div>
                    
                    <div *ngIf="isExtendAvailable">
                        <input type="checkbox" id="extendCheckBox"
                                [disabled]="isCutChecked || isShiftChecked"
                                (change)="isExtendChecked = !isExtendChecked"
                                [checked]="isExtendChecked"/>
                        <label for="extendCheckBox">Extend</label>
                        <i> - The current financial values will stay the same for each period, but new empty periods will be added</i>
                    </div>
                    <div *ngIf="isShiftAvailable">
                        <input type="checkbox" id="shiftCheckBox"
                                [disabled]="isCutChecked || isExtendChecked"
                                (change)="onShiftCheckChange($event)"
                                [checked]="isShiftChecked"/>
                        <label for="shiftCheckBox">Shift </label>
                        <i> - The current financial values will be moved to fit in the current timeline. The current values will be assigned to the shifted time periods</i>
                    </div>
                    <div *ngIf="isRecalculateAvailable">                                                
                        <input type="checkbox" id="recalculateCheckBox"
                                [disabled]="isShiftChecked"
                                (change)="isRecalculateChecked = !isRecalculateChecked"
                                [checked]="isRecalculateChecked"/> 
                        <label for="recalculateCheckBox">Recalculate</label>
                        <i> - The current financial values will be distributed evenly for each period in the new timeline</i>
                    </div>
                    <input  class="financial-input-button"
                            type="button" 
                            value = "Update"
                            (click)="updateFinancialGridClick(true)"
                            [disabled] ="!isCutChecked && !isShiftChecked && !isExtendChecked && !isRecalculateChecked" />
                    <input *ngIf="showCancel"
                            class="financial-input-button"
                            type="button" 
                            value = "Cancel"
                            (click)="updateFinancialGridClick(false)"/>
                </div>
            </p-accordionTab>
        </p-accordion>`
})

// This component is used to replicate the properties available for the StartDate/EndDate changes.
// Using this component the application can display the Cut/Extend/Shift/Recalculate options when the user changes the StartDate/EndDate.
// This component is used in both scenarios: When the user changes the CF StartDate and EndDate or when the user changes the dates from the grid input fields.

export class FinancialTimescaleUpdateComponent {
    @Input('isCheckedOutToCurrentUser') isCheckedOutToCurrentUser: boolean;
    @Input('showCancel') showCancel: boolean;
    @Input('saveOnUpdate') saveOnUpdate: boolean;
    @Output() onTimelineUpdate = new EventEmitter<{ operation: string, save: boolean}>();


    public isCutAvailable: boolean=false;
    public isCutChecked: boolean = false;
    public isShiftAvailable: boolean = false;
    public isShiftChecked: boolean = false;
    public isExtendAvailable: boolean = false;
    public isExtendChecked: boolean = false;
    public isRecalculateAvailable: boolean = false;
    public isRecalculateChecked: boolean = false;

    updateFinancialGridClick(emitOp: boolean) {

        if (emitOp) {

            if (this.isRecalculateChecked) {
                this.onTimelineUpdate.emit({ operation: "RECALCULATE", save: this.saveOnUpdate });
                return;
            } 

            if (this.isCutChecked) {
                this.onTimelineUpdate.emit({ operation: "CUT", save: this.saveOnUpdate });
                return;
            } 

            if (this.isShiftChecked) {
                this.onTimelineUpdate.emit({ operation: "SHIFT", save: this.saveOnUpdate });
                return;
            } 

            if (this.isExtendChecked) {
                this.onTimelineUpdate.emit({ operation: "EXTEND", save: this.saveOnUpdate });
                return;
            } 

            

        } else {
            this.onTimelineUpdate.emit({ operation: "CANCEL", save: this.saveOnUpdate });
        }
    }

    public onShiftCheckChange(event: any) {
        this.isShiftChecked = !this.isShiftChecked

        if (!this.isShiftChecked) {
            return;
        }

        if (this.isRecalculateChecked) {
            this.isRecalculateChecked = false;
        }
    }

    public initControls(newStart: Date, newEnd: Date, valuesStart: Date, valuesEnd: Date): void {

        var momentReference = Utils.getMomentReference();

        this.isRecalculateAvailable = true;

        this.isCutAvailable = false;
        this.isExtendAvailable = false;
        this.isShiftAvailable = false;

        var newMonthCount = Math.floor(momentReference(newEnd).diff(momentReference(newStart), "months", true));
        var valuesMonthCount = Math.floor(momentReference(valuesEnd).diff(momentReference(valuesStart), "months", true));

        if (newMonthCount >= valuesMonthCount) {
            this.isShiftAvailable = true;
        }

        if (momentReference(newStart).isAfter(valuesStart, "month")) {
            this.isCutAvailable = true;
        }

        if (momentReference(newEnd).isBefore(valuesEnd, "month")) {
            this.isCutAvailable = true;
        }


        if (momentReference(newStart).isBefore(valuesStart, "month")) {
            this.isExtendAvailable = true;
        }

        if (momentReference(newEnd).isAfter(valuesEnd, "month")) {
            this.isExtendAvailable = true;
        }

        if (this.isCutAvailable) {
            this.isExtendAvailable = false;
        }
         
        this.isCutChecked = false;
        this.isShiftChecked= false;
        this.isExtendChecked = false;
        this.isRecalculateChecked = false;

    }

}