﻿/// <reference path="../../typings/microsoft-ajax/microsoft.ajax.d.ts" />
/// <reference path="../../typings/sharepoint/sharepoint.d.ts" />
import { Component, Input, ViewEncapsulation, OnInit, AfterViewInit, AfterViewChecked, Renderer, ViewChild, ElementRef } from '@angular/core';
import { Http, RequestOptions } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import { Subscription } from 'rxjs/Subscription';
import 'rxjs/add/observable/of';
import 'rxjs/add/observable/forkJoin';

import { DialogModule, ConfirmDialogModule, ConfirmationService } from 'primeng/primeng';

import { Utils } from '../shared/utils';
import { AppSettings } from '../shared/app-settings';
import { SharePointService } from '../core/sharepoint.service';
import { Location, LocationStrategy, PathLocationStrategy, APP_BASE_HREF, DatePipe } from '@angular/common';

import { MessageRow } from '../shared/model/message-row.model';
import { FinancialTemplate } from '../shared/model/financial-template.model';
import { FinancialValue } from '../shared/model/financial-value.model';
import { FinancialNode } from '../shared/model/financial-node.model';
import { FlatFinancialGridRowModel } from '../shared/model/flat-financial-grid-row.model';
import { FinancialGridRowModel } from '../shared/model/financial-grid-row.model';
import { GranularityCellModel } from '../shared/model/granularity-cell.model';
import { FinancialValuesStructureModel } from '../shared/model/financial-values-structure.model';
import { FinancialGridSizeDataModel } from '../shared/model/financial-grid-size-data.model';
import { FinancialGridMetaDataModel } from '../shared/model/financial-grid-meta-data.model';
import { FinancialTimescalePropertyModel } from '../shared/model/financial-timescale-property.model';
import { GranularityValueModel } from '../shared/model/granularity-value.model';
import { GranularityHandlerFactory } from './granularity-handle/granularity-handler-factory';
import { GranularityHandlerStrategy } from './granularity-handle/granularity-handler-strategy';
import { GranularityTypeEnum } from '../shared/granularity-type.enum';
import { MapAggregationType } from '../shared/cf-map-aggregation-type';

import { FinancialTimescaleUpdateComponent } from "../financial_values/financial-timescale-update.component";

@Component({
    selector: 'financial-template',
    styleUrls: ['../Content/Styles/ppm-financial-app.css', '../Content/Styles/financial-values.css'],
    encapsulation: ViewEncapsulation.None,
    template: `<div class="fv-container" [style.visibility]="isFormInitializing ? 'hidden' : 'visible'"> 
                    <!--<span>sX:{{selectionModel.sX}}, sY:{{selectionModel.sY}}, fX:{{selectionModel.fX}}, fY:{{selectionModel.fY}}</span>-->

                    
                    <div class="financial-values-section-wrapper">
                        <message-row [messageRow] = "messageRow"></message-row>
                        <p-confirmDialog width="400"></p-confirmDialog>
                        
                        <br/>
                        <div class="row financial-grid-interaction-container" 
                             *ngIf="showGrid">
                            <div class="col-xs-2 col-sm-2 col-md-2 col-lg-2" >
                                <input 
                                       *ngIf="financialGridMetaDataModel.isSnapshotEnabled"
                                       class="financial-input-button"
                                       type="button" 
                                       value = "Save Snapshot"
                                       (click)="onSaveSnapshotButtonClick($event)"
                                       [disabled]="!isCheckedOutToCurrentUser || !financialGridMetaDataModel.isGridEditable"/>
                            </div>
                            <div class="col-xs-2 col-sm-2 col-md-2 col-lg-2" [ngClass]="{'col-xs-pull-2 col-sm-pull-2 col-md-pull-2 col-lg-pull-2': !financialGridMetaDataModel.isSnapshotEnabled}"
                                 *ngIf="showDateControls">
                                <div> 
                                    <label>Start Date:  
                                        <p-calendar   
                                                      [(ngModel)]="timescalePropertyModel.selectedStartDate" 
                                                      showIcon = "true"
                                                      [locale]="currentLocale"
                                                      dateFormat = {{currentDateFormat}}
                                                      (onSelect)= "onStartDateChange($event)"
                                                      [disabled]="!isCheckedOutToCurrentUser || !financialGridMetaDataModel.isGridEditable">
                                        </p-calendar>
                                    </label>
                                </div>
                            </div>
                            <div class="end-date-column col-xs-2 col-sm-2 col-md-2 col-lg-2" [ngClass]="{'col-xs-pull-2 col-sm-pull-2 col-md-pull-2 col-lg-pull-2': !financialGridMetaDataModel.isSnapshotEnabled}"
                                 *ngIf="showDateControls">
                                <div>
                                    <label>End Date:
                                        <p-calendar   
                                                        [(ngModel)]="timescalePropertyModel.selectedEndDate" 
                                                        showIcon = "true"
                                                        [locale]="currentLocale"
                                                        dateFormat = {{currentDateFormat}}
                                                        (onSelect) = "onEndDateChange($event)"
                                                        [disabled] = "!isCheckedOutToCurrentUser || !financialGridMetaDataModel.isGridEditable">
                                    
                                        </p-calendar>
                                </label> 
                            </div>
                            </div>
                            <div class="col-xs-2 col-sm-2 col-md-2 col-lg-2" [ngClass]="{'col-xs-pull-2 col-sm-pull-2 col-md-pull-2 col-lg-pull-2': !financialGridMetaDataModel.isSnapshotEnabled}">
                                <div style="width: 300px">
                                    <label>Timescale:
                                        <select   [ngModel]="financialGridMetaDataModel.selectedGranularity" (ngModelChange)="onGranularityTypeChanged($event)">
                                            <option *ngFor="let granularity of granularityTypes" [ngValue]="granularity"> 
                                                {{granularity}} 
                                            </option>
                                        </select>
                                    </label>
                                </div>
                            </div>
                        </div>
                        <div class="row" [style.display]="showTimelineUpdate ? 'block':'none'">
                            <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
                                <financial-timescale-update 
                                            [showCancel] = "showTimelineUpdateCancelBtn"
                                            [saveOnUpdate] = "saveValuesOnTimelineUpdate"
                                            [isCheckedOutToCurrentUser] = "isCheckedOutToCurrentUser"
                                            (onTimelineUpdate) = "updateTimeline($event,true)" 
                                            #timelineUpdateComponent >
                                </financial-timescale-update>
                            </div>
                        </div>
                        <br *ngIf="financialGridMetaDataModel.editGranularity != financialGridMetaDataModel.selectedGranularity"  />
                        <span class="grid-edit-info-message" *ngIf="financialGridMetaDataModel.editGranularity != financialGridMetaDataModel.selectedGranularity">The grid is editable only for {{financialGridMetaDataModel.editGranularity}} granularity</span>
                        <div class = "financial-table-container"
                              *ngIf = "showGrid"
                             [style.width] = financialGridSizeValues.financialTableContainerWidth>
                            <div class="financial-table-wrapper" 
                                 [style.width] = financialGridSizeValues.financialTableWrapperWidth
                                 [style.height] = financialGridSizeValues.financialTableWrapperHeight>
                                <div class="labels-table-wrapper"
                                     [style.height] = financialGridSizeValues.labelsTableWrapperHeight
                                     [style.width] = financialGridSizeValues.labelsTableWrapperWidth
                                     #financialLabelsTable>
                                    <table class="labels-table">
                                        <thead class="labels-table-head">
                                            <tr class="labels-table-head-row">
                                                <th class="labels-table-header">Name</th>
                                            </tr>
                                        </thead>
                                        <tbody class="labels-table-body"> 
                                             <tr *ngFor="let node of flatNodeStructure"
                                                  class="labels-table-row">
                                                <td class="labels-table-body-data {{node.cellBackgroundClass}}">
                                                    <span [style.padding-left.px]= node.paddingValue
                                                            class="financial-labels-column {{node.cellTextColorClass}}"
                                                            data-toggle="tooltip" 
                                                            title = "{{node.label}}" 
                                                            data-placement="top">  
                                                        <i class="fa fa-caret-down financial-grid-collapse-icon"
                                                            *ngIf="node.isExpanded == true && node.hasChildren == true"
                                                            (click)="oNodeCollapseClick(node)"> 
                                                        </i>
                                                        <i class="fa fa-caret-right financial-grid-expand-icon"
                                                            *ngIf="node.isExpanded == false && node.hasChildren == true"
                                                            (click)="oNodeExpandClick(node)">
                                                        </i>
                                                        <i class="fa fa-empty" 
                                                           *ngIf="node.hasChildren == false">
                                                        </i>
                                                        {{node.shortLabel}}
                                                    </span>
                                                </td>
                                             </tr>
                                        </tbody>  
                                    </table>
                                    </div>
                                    <div class="values-table-wrapper"
                                        [style.width] = financialGridSizeValues.valuesTableWrapperWidth
                                        [style.height] = financialGridSizeValues.valuesTableWrapperHeight
                                        (scroll)="onFinancialValuesTableScroll($event)">
                                    <table class="values-table" 
                                           [style.width] = financialGridSizeValues.valuesTableWidth>                                    
                                        <thead class="values-table-head" 
                                               [style.left]=granularityLabelsLeftScrollValue
                                               [style.width]=financialGridSizeValues.valuesTableHeadWidth>
                                            <tr class="values-table-head-row">
                                                <th class="values-table-header" 
                                                    *ngFor="let headerValue of currentGranularityHeaderLabels">
                                                    {{headerValue}}
                                                </th>
                                                <th class="values-table-header values-table-header-empty"
                                                    [style.width] = financialGridSizeValues.valuesTableEmptyRowWidth>
                                                </th>
                                            </tr>
                                        </thead>                                    
                                        <tbody class="values-table-body">
                                            <tr *ngFor="let node of flatNodeStructure;let rowIndex = index" class="values-table-row">
                                                <td *ngFor="let nodeCellInfo of node.cellInfo; let partitionIndex = index"
                                                    (mousedown)="onSelectionStart($event,node,rowIndex,partitionIndex)" 
                                                    (mouseenter)="onSelection($event,node,rowIndex,partitionIndex)"
                                                    (mouseup)="onSelectionEnd($event,node,rowIndex,partitionIndex)"
                                                     class="values-table-body-data {{node.cellBackgroundClass}}"
                                                     [ngClass]="{ 'values-table-selected-cell' : (rowIndex <= selectionModel.fY && rowIndex>=selectionModel.sY && partitionIndex <= selectionModel.fX && partitionIndex>=selectionModel.sX && (selectionModel.sX != selectionModel.fX || selectionModel.sY != selectionModel.fY)) }"
                                                     (click)="onFinancialValuesTableDataClick($event)">
                                                    <div (mousedown)="onGranularityNodeClick($event, node, partitionIndex, nodeCellInfo.cellModel)" class="values-table-granularity-column">
                                                        <input type="text"
                                                               class="values-table-cell-input {{node.cellTextColorClass}}"
                                                               value="{{nodeCellInfo.cellModel.displayValue}}"
                                                               [disabled]="!nodeCellInfo.cellModel.editable"
                                                               (blur) = "onGranularityCellInputBlur($event, nodeCellInfo.cellModel)"
                                                               (mouseleave)="onGranularityCellInputLeaveBlur($event, nodeCellInfo.cellModel)"
                                                               (change) = "onGranularityCellValueChange($event, node, partitionIndex)"
                                                               (paste)="onValuePaste($event)"
                                                               (dblclick) = "onGranularityCellDoubleClick($event,node, partitionIndex, nodeCellInfo.cellModel)"
                                                               (keyup.enter)="onGranularityCellValueChange($event, node, partitionIndex)"
                                                               (keyup.Tab)="onGranularityNodeClick($event, node, partitionIndex, nodeCellInfo.cellModel)"
                                                               (keyup.shift.Tab)="onGranularityNodeClick($event, node, partitionIndex, nodeCellInfo.cellModel)"/>
                                                    </div>                    
                                                </td>
                                                <td class="values-table-body-data values-table-body-data-empty {{node.cellBackgroundClass}}"
                                                     [style.width] = financialGridSizeValues.valuesTableEmptyRowWidth>
                                                    <div class="values-table-granularity-column"
                                                         [style.width] = financialGridSizeValues.valuesTableEmptyRowWidth>
                                                        <input type="text" class="values-table-cell-input" disabled>
                                                    </div>
                                                </td>
                                            </tr>
                                        </tbody>  
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
               </div>`,
    host: {
        '(document:keydown)': 'handleKeyboardEvents($event)',
        '(document:copy)': 'handleCopyEvent($event)'
    }
})

// This is the component that contains the financial grid with the selected template The tempalte name and other such metadata come from the web aprt proeprties. 
// This component contains the code for the financial values grid.

export class FinancialValuesComponent implements OnInit {

    @ViewChild("financialLabelsTable")
    financialLabelsTable: ElementRef;


    @ViewChild(FinancialTimescaleUpdateComponent)
    timelineUpdateComponent: FinancialTimescaleUpdateComponent;


    // Public members
    public isCellDoubleClicked: boolean = false;

    //grid CF dates
    public originalStartDate: string;
    public originalEndDate: string;

    public granularityTypes: Array<string>;
    public currentDateFormat: string;
    public currentLocale: any;
    public curentFinancialData: FinancialValue;

    public granularityLabelsLeftScrollValue: string;
    public messageRow: MessageRow;

    public flatNodeStructure: Array<FlatFinancialGridRowModel>;
    public currentGranularityHeaderLabels: Array<string>;

    public timescalePropertyModel: FinancialTimescalePropertyModel;

    public isCheckedOutToCurrentUser: boolean;

    public isFormInitializing: boolean;
    public isTemplateFound: boolean;

    public showGrid: boolean = false;
    public showTimelineUpdate: boolean = false;
    public showTimelineUpdateCancelBtn: boolean = false;
    public showDateControls: boolean = false;
    public saveValuesOnTimelineUpdate: boolean = false;
    public financialGridSizeValues: FinancialGridSizeDataModel;

    // Private members
    private waitDialog: SP.UI.ModalDialog;
    private oldJSONobject: string;

    private financialGridMetaDataModel: FinancialGridMetaDataModel;
    private overallNodeVisibility: { [nodeId: string]: boolean };

    private shadowNodeStructure: FinancialGridRowModel;
    private nodeReferenceDict: { [nodeId: string]: FinancialGridRowModel };

    private granularityHandlerStrategy: GranularityHandlerStrategy;
    private granularityHandlerFactory: GranularityHandlerFactory;

    private previousGranularityCellModels: { [id: number]: number };;
    private currentFinancialTemplate: FinancialTemplate;
    private momentReference: any;

    private refreshOnPostSave: boolean = false;
    private checkDatesOnPostSave: boolean = false;

    private saveGridPromise: Promise<any> = null;

    private currentFiscalMonthNumber: number = 0;

    public newCurrentFiscalMonthNumber: number = 0;
    public newFinancialStartMonth: number = 0;
    public newFinancialEndMonth: number = 0;

    public selectionModel: {
        dragSelectionStarted: boolean,
        arrowSelectionStarted: boolean,
        startX: number,
        startY: number,
        currentX: number,
        currentY: number,
        sX: number,
        sY: number,
        fX: number,
        fY: number
    } = {
            dragSelectionStarted: false,
            arrowSelectionStarted: false,
            startX: -1,
            startY: -1,
            currentX: -1,
            currentY: -1,
            sX: -1,
            sY: -1,
            fX: -1,
            fY: -1
        }



    constructor(private sharePointService: SharePointService,
        private location: Location,
        private renderer: Renderer,
        private confirmationService: ConfirmationService,
        private http: Http) {
        //called first time before the ngOnInit()
        this.oldJSONobject = "";
        this.curentFinancialData = new FinancialValue();
        this.granularityHandlerFactory = new GranularityHandlerFactory();
        this.financialGridSizeValues = new FinancialGridSizeDataModel();
        this.financialGridMetaDataModel = new FinancialGridMetaDataModel();
        this.timescalePropertyModel = new FinancialTimescalePropertyModel();

        this.nodeReferenceDict = {};
        this.granularityLabelsLeftScrollValue = "";
        this.overallNodeVisibility = {};
        this.previousGranularityCellModels = {};
        this.messageRow = new MessageRow();
        this.isFormInitializing = true;
        this.isCheckedOutToCurrentUser = false;

        this.granularityTypes = Utils.getGranularityTypes();
        this.currentDateFormat = Utils.getDateFormat();
        this.currentLocale = Utils.getCurrentLocale();
        this.momentReference = Utils.getMomentReference();

        this.resetMessage();
    }

    // In the initialization phase we tried to first gather the meta data and make sure the grid  will be rendered in a correct state.
    // When the meta data (web part properties, entityUID, entityName, etc.) is gathered and validated the next step is to initialize the grid and its values.
    ngOnInit() {
        var vm = this;
        var hostwebURL = decodeURIComponent(Utils.getQueryStringParameter("SPHostUrl"));
        vm.registerProjectSaveEvent(hostwebURL);
        vm.initGrid(hostwebURL);
    }

    private initGrid(hostwebURL: string): void {
        var vm = this;
        vm.showGrid = false;
        vm.isFormInitializing = true;
        var financialGridInitializationQueue = []
        financialGridInitializationQueue.push(this.initializeProperties(hostwebURL));
        financialGridInitializationQueue.push(this.sharePointService.gerCurrentUser());

        Observable.forkJoin(financialGridInitializationQueue).subscribe(
            (results: Array<any>) => {
                var currentUser = results[1];

                //Get the current fiscal month from PPMFiscalMonth list for calculations
                vm.sharePointService.getCurrentFiscalMonth().subscribe((val: any) => {

                    vm.currentFiscalMonthNumber = val;
                    if (vm.currentFiscalMonthNumber <= 6) {
                        vm.currentFiscalMonthNumber = vm.currentFiscalMonthNumber + 6;
                        vm.currentFiscalMonthNumber = vm.currentFiscalMonthNumber - 1;
                    }
                    else {
                        vm.currentFiscalMonthNumber = vm.currentFiscalMonthNumber - 6;
                        vm.currentFiscalMonthNumber = vm.currentFiscalMonthNumber - 1;
                    }
                    vm.newCurrentFiscalMonthNumber = vm.currentFiscalMonthNumber;
                });

                if (!currentUser) {
                    vm.showMessage(["No user was found."], AppSettings.getCriticalErrorMessage());
                    vm.isFormInitializing = false;
                    return;
                }

                vm.financialGridMetaDataModel.currentUser = currentUser;

                //handle project entity
                if (vm.financialGridMetaDataModel.listItemId == -1) {
                    vm.initializeProjectData().subscribe((data: any) => {
                        vm.buildGrid(data, hostwebURL)
                    }, errorHandle);

                } else {
                    //handle list item entity
                    vm.sharePointService.getListNameById(vm.financialGridMetaDataModel.entityUID).subscribe((data: any) => {
                        vm.buildGrid(data, hostwebURL)
                    }, errorHandle)
                }
            },
            errorHandle);

        // After all the meta data fields have been updated we have to initialize the financial values and the actual grid properties.
        // Here is where we get the template and the financial values.


        var errorHandle = function (errorMessage: any) {
            vm.showMessage(["Something went wrong. ", errorMessage], AppSettings.getCriticalErrorMessage());
            vm.isFormInitializing = false;
        }
    }

    private buildGrid(entityData: any, hostwebURL: string): void {
        var vm = this;

        vm.financialGridMetaDataModel.entityName = entityData.entityName;
        vm.isCheckedOutToCurrentUser = entityData.isCheckedOutToCurrentUser ? entityData.isCheckedOutToCurrentUser : false;

        vm.initializeProperties(hostwebURL)
            .then(() => {
                return vm.buildTimescalePropertyModel()
            })
            .then(tsModel => {
                vm.timescalePropertyModel = tsModel;

                return vm.loadFinanacialTemplate(hostwebURL)
            })
            .then(template => {
                vm.currentFinancialTemplate = template;

                return vm.loadFinancialValues(hostwebURL, template);
            })
            .then(finData => {


                vm.financialGridMetaDataModel.selectedGranularity = vm.financialGridMetaDataModel.editGranularity;

                if (vm.timescalePropertyModel != null) {

                    vm.curentFinancialData = finData;

                    if (vm.timescalePropertyModel.areDatesMapped) {
                        //dates are coming from the custom field mappings, so we need to check if somethign changed
                        vm.checkDatesOnPostSave = true;

                    } else {
                        //dates are coming from saved values
                        vm.timescalePropertyModel.startDate = new Date(vm.curentFinancialData.financialStartDate);
                        vm.timescalePropertyModel.endDate = new Date(vm.curentFinancialData.financialEndDate);
                        vm.timescalePropertyModel.selectedStartDate = new Date(vm.curentFinancialData.financialStartDate);
                        vm.timescalePropertyModel.selectedEndDate = new Date(vm.curentFinancialData.financialEndDate);
                        vm.checkDatesOnPostSave = false;
                        vm.showDateControls = true;
                    }




                    if (vm.timescalePropertyModel.endDate == null || vm.timescalePropertyModel.startDate == null
                        || isNaN(vm.timescalePropertyModel.endDate.getTime()) || isNaN(vm.timescalePropertyModel.startDate.getTime())) {


                        this.showMessage(["The<b> Start Date </b> or <b> End Date </b> has not been defined."], AppSettings.getErrorMessage());
                        this.showGrid = false;
                        this.refreshOnPostSave = true;

                    } else {
                        vm.financialGridMetaDataModel.isGranularityEditable = (vm.financialGridMetaDataModel.editGranularity == vm.financialGridMetaDataModel.selectedGranularity);

                        vm.buildBackingStructures(vm.currentFinancialTemplate);
                        // Grid gets resized based on the new values.
                        vm.resizeFinancialValuesGrid();

                        if (vm.financialGridMetaDataModel.isGridEditable) {                     
                            if (!vm.momentReference(vm.timescalePropertyModel.endDate).isSame(finData.financialEndDate, "month")
                                || !vm.momentReference(vm.timescalePropertyModel.startDate).isSame(finData.financialStartDate, "month")
                            ) {
                                var grdEmpty = vm.isGridEmpty();
                                if (grdEmpty) {
                                    vm.updateTimeline({ operation: "EXTEND", save: false });
                                } else {
                                    vm.timescalePropertyModel.startDate = new Date(finData.financialStartDate);
                                    vm.timescalePropertyModel.endDate = new Date(finData.financialEndDate);
                                    vm.showTimelineUpdateComponent(false);
                                }
                            } else {
                                //if only the day changed then save it on the list 
                                if (!vm.momentReference(vm.timescalePropertyModel.endDate).isSame(finData.financialEndDate, "day")
                                    || !vm.momentReference(vm.timescalePropertyModel.startDate).isSame(finData.financialStartDate, "day")
                                ) {
                                    vm.curentFinancialData.financialStartDate = vm.timescalePropertyModel.startDate;
                                    vm.curentFinancialData.financialEndDate = vm.timescalePropertyModel.endDate;
                                    vm.financialGridMetaDataModel.areFinancialValuesDirty = true;
                                    vm.postValuesChanged();
                                }

                                vm.showGrid = true;

                            }
                        } else {
                            vm.showGrid = true;
                        }


                    }
                } else {
                    this.refreshOnPostSave = true;
                }

                vm.isFormInitializing = false;
                $(".loading-container").hide();


            }).catch(() => {
                vm.isFormInitializing = false;
                $(".loading-container").hide();
                vm.showGrid = false;
                this.refreshOnPostSave = true;
            })
    }

    private refreshGrid(): void {
        var vm = this;

        this.granularityHandlerStrategy = this.granularityHandlerFactory.getGranularityHandlerStrategy(this.curentFinancialData.granularity, this.nodeReferenceDict, this.currentFinancialTemplate, this.financialGridMetaDataModel.isGranularityEditable, this.isCheckedOutToCurrentUser, this.financialGridMetaDataModel.isGridEditable);
        this.currentGranularityHeaderLabels = this.granularityHandlerStrategy.getGranularityHeaderLabels(this.curentFinancialData.financialStartDate, this.curentFinancialData.financialEndDate, this.curentFinancialData.granularity, this.newCurrentFiscalMonthNumber, this.newFinancialStartMonth, this.newFinancialEndMonth);
        this.refreshValueCellWidth();

        this.flatNodeStructure = new Array<FlatFinancialGridRowModel>();
        var tempFlatNodeStr: FlatFinancialGridRowModel[] = [];
        this.flattenNodeStructure(this.shadowNodeStructure, tempFlatNodeStr)
        this.flatNodeStructure = tempFlatNodeStr;

        for (var flatNode of this.flatNodeStructure) {
            this.overallNodeVisibility[flatNode.id] = flatNode.isExpanded;
        }
        vm.resizeFinancialValuesGrid();

    }

    //  insert all the meta data that the grid needs. Information like the user or the web part properties will be inserted here.
    private initializeProperties(hostwebURL: string): Promise<any> {
        var vm = this;

        var promise = new Promise<any>(function (resolve, reject) {
            vm.financialGridMetaDataModel.financialTemplateName = decodeURIComponent(Utils.getQueryStringParameter("financialTemplateName"));
            vm.financialGridMetaDataModel.editGranularity = decodeURIComponent(Utils.getQueryStringParameter("editGranularity"));

            vm.financialGridMetaDataModel.isGridEditable = decodeURIComponent(Utils.getQueryStringParameter("isGridEditable")).toLowerCase() === "true";
            vm.financialGridMetaDataModel.isGridCollapsed = decodeURIComponent(Utils.getQueryStringParameter("isGridCollapsed")).toLowerCase() === "true";
            vm.financialGridMetaDataModel.isSnapshotEnabled = decodeURIComponent(Utils.getQueryStringParameter("isSnapshotEnabled")).toLowerCase() === "true";

            if (!vm.financialGridMetaDataModel.editGranularity) {
                vm.showMessage(["Edit Granularity was set to the default value of Months."], AppSettings.getInfoMessage());
                vm.financialGridMetaDataModel.editGranularity = GranularityTypeEnum.Months;
            }

            if (vm.financialGridMetaDataModel.financialTemplateName == AppSettings.getNoneValue() ||
                vm.financialGridMetaDataModel.financialTemplateName == '') {
                reject("Financial Template Name was not set correctly. Make sure the web part property is set to an existing financial template and refresh the page.");
            } else {
                vm.loadEntityUid(hostwebURL).then(() => {
                    resolve();
                }).catch((args) => {
                    reject(args);
                })
            }
        });
        return promise;
    }

    // used to retrieve the information about the Mapped Custom Field Dates.
    private buildTimescalePropertyModel(startDate: Date = null, endDate: Date = null): Promise<FinancialTimescalePropertyModel> {
        var vm = this;

        var promise = new Promise<FinancialTimescalePropertyModel>(function (resolve, reject) {
            var financialTimescalePropertyModel = new FinancialTimescalePropertyModel();

            financialTimescalePropertyModel.areDatesMapped = decodeURIComponent(Utils.getQueryStringParameter("areDatesMapped")).toLowerCase() === "true";
            financialTimescalePropertyModel.startDate = startDate;
            financialTimescalePropertyModel.endDate = endDate;

            if (!financialTimescalePropertyModel.areDatesMapped) {
                resolve(financialTimescalePropertyModel);
            } else {

                var startDateCFGuid = decodeURIComponent(Utils.getQueryStringParameter("startDateCFGuid"));
                var endDateCFGuid = decodeURIComponent(Utils.getQueryStringParameter("endDateCFGuid"));

                if (!startDateCFGuid || !endDateCFGuid) {
                    financialTimescalePropertyModel.areDatesValid = false;
                    vm.showMessage(["The <b>Start Date Name</b> or the <b>End Date Name</b> are not set correctly."], AppSettings.getErrorMessage());
                    resolve(null);
                }
                else if (!SP.Guid.isValid(startDateCFGuid) || !SP.Guid.isValid(endDateCFGuid)) {
                    financialTimescalePropertyModel.areDatesValid = false;
                    vm.showMessage(["The <b>Start Date Name</b> or the <b>End Date Name</b> are not in a correct GUid format."], AppSettings.getErrorMessage());
                    resolve(null);
                }
                else {

                    financialTimescalePropertyModel.startDateCFGuid = new SP.Guid(startDateCFGuid);
                    financialTimescalePropertyModel.endDateCFGuid = new SP.Guid(endDateCFGuid);

                    var financialValueDatesQueue = [];

                    //financialValueDatesQueue.push(vm.sharePointService.getCustomFieldDataByGuid(vm.financialGridMetaDataModel.entityUID, financialTimescalePropertyModel.startDateCFGuid));
                    //financialValueDatesQueue.push(vm.sharePointService.getCustomFieldDataByGuid(vm.financialGridMetaDataModel.entityUID, financialTimescalePropertyModel.endDateCFGuid));

                    financialValueDatesQueue.push(vm.sharePointService.getGridStartEndDataByGuid(vm.financialGridMetaDataModel.entityUID, financialTimescalePropertyModel.startDateCFGuid, financialTimescalePropertyModel.endDateCFGuid));

                    Observable.forkJoin(financialValueDatesQueue).subscribe(
                        (results: Array<any>) => {
                            var areDatesValid = true;
                            var errorMessages = [];

                            for (var result of results) {
                                var startParsedDate = new Date(result.startDateValue);
                                var endParsedDate = new Date(result.endDateValue);

                                if (!startParsedDate || !endParsedDate) {
                                    //result = { "startDateCustomFieldGuid": startDateGuid, "startDateValue": startDateVal, "endDateCustomFieldGuid": endDateGuid, "endDateValue": endDateVal };
                                    if (result.startDateCustomFieldGuid == financialTimescalePropertyModel.startDateCFGuid) {
                                        if (!result.startDateValue) {
                                            errorMessages.push("The custom field from <b>Start Date Name</b> property has an incorrect value.")
                                        }
                                    }

                                    if (result.endDateCustomFieldGuid == financialTimescalePropertyModel.endDateCFGuid) {
                                        if (!result.endDateValue) {
                                            errorMessages.push("The custom field from <b>End Date Name</b> property has an incorrect value.")
                                        }
                                    }

                                    vm.showMessage(errorMessages, AppSettings.getErrorMessage());
                                    areDatesValid = false;
                                    resolve(null);

                                } else {
                                    if (result.startDateCustomFieldGuid == financialTimescalePropertyModel.startDateCFGuid) {
                                        financialTimescalePropertyModel.startDate = startParsedDate;
                                        financialTimescalePropertyModel.selectedStartDate = startParsedDate;
                                        vm.originalStartDate = startParsedDate.toUTCString();
                                    }

                                    if (result.endDateCustomFieldGuid == financialTimescalePropertyModel.endDateCFGuid) {
                                        financialTimescalePropertyModel.endDate = endParsedDate;
                                        financialTimescalePropertyModel.selectedEndDate = endParsedDate;
                                        vm.originalEndDate = endParsedDate.toUTCString();
                                    }
                                }
                            }

                            if (areDatesValid) {
                                if (vm.momentReference(financialTimescalePropertyModel.endDate).isBefore(financialTimescalePropertyModel.startDate, "month")) {
                                    vm.showMessage([`<b>End Date</b> value must be greater than <b>Start Date</b> value.`], AppSettings.getErrorMessage());
                                    resolve(null);
                                } else {
                                    financialTimescalePropertyModel.areDatesValid = true;
                                    resolve(financialTimescalePropertyModel);
                                }
                            } else {

                            }

                            var fiscalStartMonth = 0;

                            vm.sharePointService.getFinGridFiscalMonth(financialTimescalePropertyModel.startDate).subscribe(
                                (fiscalStartMonth: number) => {
                                    if (!fiscalStartMonth) {
                                        vm.showMessage(["No fiscal start month number was found"], AppSettings.getInfoMessage());
                                        reject();
                                    }
                                    console.log("getFinGridFiscalMonth - FinGridStartDate --", fiscalStartMonth);
                                    console.log(fiscalStartMonth);
                                    vm.newFinancialStartMonth = fiscalStartMonth;

                                    if (vm.newFinancialStartMonth <= 6) {
                                        vm.newFinancialStartMonth = vm.newFinancialStartMonth + 6;
                                        vm.newFinancialStartMonth = vm.newFinancialStartMonth - 1;
                                    }
                                    else {
                                        vm.newFinancialStartMonth = vm.newFinancialStartMonth - 6;
                                        vm.newFinancialStartMonth = vm.newFinancialStartMonth - 1;
                                    }

                                },
                                (err: any) => {
                                    vm.showMessage(["Something went wrong.", err], AppSettings.getCriticalErrorMessage());
                                    reject();
                                });

                            vm.sharePointService.getFinGridFiscalMonth(financialTimescalePropertyModel.endDate).subscribe(
                                (fiscalEndMonth: number) => {
                                    if (!fiscalEndMonth) {
                                        vm.showMessage(["No fiscal end month number was found"], AppSettings.getInfoMessage());
                                        reject();
                                    }

                                    vm.newFinancialEndMonth = fiscalEndMonth;

                                    if (vm.newFinancialEndMonth <= 6) {
                                        vm.newFinancialEndMonth = vm.newFinancialEndMonth + 6;
                                        vm.newFinancialEndMonth = vm.newFinancialEndMonth - 1;
                                    }
                                    else {
                                        vm.newFinancialEndMonth = vm.newFinancialEndMonth - 6;
                                        vm.newFinancialEndMonth = vm.newFinancialEndMonth - 1;
                                    }
                                    //if (vm.newFinancialEndMonth == 0)
                                    //       vm.newFinancialEndMonth = 1;
                                },
                                (err: any) => {
                                    vm.showMessage(["Something went wrong.", err], AppSettings.getCriticalErrorMessage());
                                    reject();
                                });
                            console.log("vm.newFinancialStartMonth - ", vm.newFinancialStartMonth);
                            console.log("vm.newFinancialEndMonth - ", vm.newFinancialEndMonth);
                       

                        },
                        (err) => {
                            reject(err);
                        });
                }
            }
        });

        return promise;
    }

    //  initialize the project information.
    private initializeProjectData(): Observable<any> {
        var vm = this;
        var promise = new Promise<any>(function (resolve, reject) {

            var initializaeProjectStateQueue = [];
            initializaeProjectStateQueue.push(vm.sharePointService.getCheckedOutBy(vm.financialGridMetaDataModel.entityUID));
            initializaeProjectStateQueue.push(vm.sharePointService.getProjectName(vm.financialGridMetaDataModel.entityUID));



            Observable.forkJoin(initializaeProjectStateQueue).subscribe(
                (results: Array<any>) => {
                    var checkedOutBy = results[0]
                    var isCheckedOutToCurrentUser = false;
                  

                    if (!checkedOutBy) {
                        isCheckedOutToCurrentUser = false;
                    } else {
                        if (!checkedOutBy.LoginName) {
                            isCheckedOutToCurrentUser = false;
                        } else if (vm.financialGridMetaDataModel.currentUser.get_loginName() == checkedOutBy.LoginName) {
                            isCheckedOutToCurrentUser = true;
                        }
                    }

                    var entityNameData = results[1];

                    if (!entityNameData) {
                        reject("Entity name was not found.")
                    } else {
                        resolve({ "entityName": entityNameData.name, "isCheckedOutToCurrentUser": isCheckedOutToCurrentUser });
                    }

                },
                (err) => {
                    reject(err);
                });

        });
        return Observable.fromPromise(promise);
    }

    //  initialize the actual grid properties. Will initialize the template and the grid values.
    private loadFinanacialTemplate(hostwebURL: string): Promise<FinancialTemplate> {
        var vm = this;

        var promise = new Promise<FinancialTemplate>(function (resolve, reject) {
            vm.sharePointService.getFinancialTemplateByName(vm.financialGridMetaDataModel.financialTemplateName).subscribe(
                (finTemplate: FinancialTemplate) => {

                    if (!finTemplate) {
                        vm.showMessage(["No financial template was found for the specified <b>Template Name</b>."], AppSettings.getInfoMessage());
                        reject();
                    }

                    resolve(finTemplate);
                },
                (err) => {
                    vm.showMessage(["Something went wrong.", err], AppSettings.getCriticalErrorMessage());
                    reject();
                });
        });

        return promise;
    }

    //  initialize the financial values which will fill the template.
    private loadFinancialValues(hostwebURL: string, finTemplate: FinancialTemplate): Promise<FinancialValue> {
        var vm = this;

        var promise = new Promise<any>(function (resolve, reject) {
            // We need to retrieve the exact financial values available for this entity from the user inputed template (which is also the name of the list).
            vm.sharePointService.getFinancialValueByEntityUid(
                finTemplate.financialTemplateListUID,
                //TODO: figure out where the logic for lists went ....
                vm.financialGridMetaDataModel.entityUID
            ).subscribe(data => {

                var financialData = new FinancialValue();
                // If no Financial Values was found this means that the current grid has no existing values so we need to build an empty financialValue object.
                if (!data) {
                    financialData.financialValuesJson = "";
                    financialData.financialStartDate = finTemplate.financialStartDate;
                    financialData.financialEndDate = finTemplate.financialEndDate;
                    financialData.granularity = finTemplate.granularity;
                    financialData.updateStatus = "";
                    financialData.entityUid = vm.financialGridMetaDataModel.entityUID;
                    financialData.listItemId = vm.financialGridMetaDataModel.listItemId;
                    financialData.listUID = finTemplate.financialTemplateListUID;

                    // The update process of the grid can still be in progress. If an update is still in progress we have to wait so we ask the user to try again later.
                    if (financialData.updateStatus == AppSettings.getUpdateInProgress()) {
                        vm.showMessage(["An update is currently running on the financial values. Please try again later."], AppSettings.getInfoMessage());
                        reject();
                    }

                    // The update process of the grid can fail . If an update has failed we have a "Force Update" functionality and we inform the user that the grid is not in a valid state.
                    if (financialData.updateStatus == AppSettings.getUpdateFailed()) {
                        vm.showMessage(["Something went wrong. The financial values update failed."], AppSettings.getErrorMessage());
                        reject();
                    }

                } else {
                    financialData = data;
                }

                financialData.templateStructureJson = finTemplate.structure;

                resolve(financialData);
            },
                (err) => {

                    vm.showMessage(["Something went wrong.", err], AppSettings.getCriticalErrorMessage());
                    reject();
                });
        });

        return promise;
    }

    //  use all the provided data to create the data structures needed for the grid to work.
    // Here is where we initialize the shadowNodeStructure and further on the flatNodeStructure.
    private buildBackingStructures(finTemplate: FinancialTemplate) {
        //create empty scaffold for entire temaplte
        //this.curentFinancialData.financialStartDate = new Date(this.timescalePropertyModel.selectedStartDate);
        //this.curentFinancialData.financialEndDate = new Date(this.timescalePropertyModel.selectedEndDate);

        //var extendedGranularityStructure = Utils.computeExtendedGranularityStructure(this.curentFinancialData.financialStartDate, this.curentFinancialData.financialEndDate, this.newFinancialStartMonth, this.newFinancialEndMonth, this.financialGridMetaDataModel.selectedGranularity);

        var extendedGranularityStructure = Utils.computeExtendedGranularityStructure(this.timescalePropertyModel.selectedStartDate, this.timescalePropertyModel.selectedEndDate, this.newFinancialStartMonth, this.newFinancialEndMonth, this.financialGridMetaDataModel.selectedGranularity);

        var templateStructure = JSON.parse(this.curentFinancialData.templateStructureJson);

        this.initializeShadowNodeStructure(this.shadowNodeStructure, [templateStructure], extendedGranularityStructure);

        if (this.curentFinancialData.financialValuesJson != null && this.curentFinancialData.financialValuesJson != "") {
            var financialValuesStructure: Array<FinancialValuesStructureModel> = JSON.parse(this.curentFinancialData.financialValuesJson);
            this.oldJSONobject = this.curentFinancialData.financialValuesJson;
            this.assignValuesToShadowStructure(financialValuesStructure);
        }

        this.granularityHandlerStrategy = this.granularityHandlerFactory.getGranularityHandlerStrategy(this.financialGridMetaDataModel.selectedGranularity, this.nodeReferenceDict, finTemplate, this.financialGridMetaDataModel.isGranularityEditable, this.isCheckedOutToCurrentUser, this.financialGridMetaDataModel.isGridEditable);
        this.currentGranularityHeaderLabels = this.granularityHandlerStrategy.getGranularityHeaderLabels(this.curentFinancialData.financialStartDate, this.curentFinancialData.financialEndDate, this.curentFinancialData.granularity, this.newCurrentFiscalMonthNumber, this.newFinancialStartMonth, this.newFinancialEndMonth);
        this.refreshValueCellWidth();

        this.flatNodeStructure = new Array<FlatFinancialGridRowModel>();
        var tempFlatNodeStr: FlatFinancialGridRowModel[] = [];
        this.flattenNodeStructure(this.shadowNodeStructure, tempFlatNodeStr)
        this.flatNodeStructure = tempFlatNodeStr;

        for (var flatNode of this.flatNodeStructure) {
            this.overallNodeVisibility[flatNode.id] = flatNode.isExpanded;
        }
    }

    //  initialize the shadow node structure. The shadowNodeStructure is used to keep track of the template in a tree like manner.
    // While building the shadowNodeStructure we also update the nodeReferenceDict which will help with node localization and update further down the road.
    private initializeShadowNodeStructure(parentStructure: FinancialGridRowModel, financialTemplateStructure: Array<FinancialNode>, extendedGranularityStructure: { [year: string]: { [month: string]: GranularityCellModel } }) {
        var vm = this;

        for (var financialTemplate of financialTemplateStructure) {
            var newParent = new FinancialGridRowModel();
            var copyGranularityStructure = JSON.parse(JSON.stringify(extendedGranularityStructure))
            //TODO: Revise this
            var shortLabel = "";
            if (financialTemplate.label.length >= 43) {
                shortLabel = financialTemplate.label.substring(0, 40) + "...";
            } else {
                shortLabel = financialTemplate.label;
            }

            if (financialTemplate.id == Utils.getDefaultRootID()) {

                this.shadowNodeStructure = new FinancialGridRowModel();
                this.shadowNodeStructure.id = financialTemplate.id;
                this.shadowNodeStructure.parentId = financialTemplate.parentId;
                this.shadowNodeStructure.hasChildren = financialTemplate.children.length > 0;
                this.shadowNodeStructure.label = financialTemplate.label;
                this.shadowNodeStructure.shortLabel = shortLabel;
                this.shadowNodeStructure.extendedGranularityStructure = copyGranularityStructure;
                this.shadowNodeStructure.customFieldMap = financialTemplate.customFieldMap;
                this.nodeReferenceDict[this.shadowNodeStructure.id] = this.shadowNodeStructure;

                newParent = this.shadowNodeStructure;
            } else {
                var childStructure = new FinancialGridRowModel();
                childStructure.id = financialTemplate.id;
                childStructure.parentId = financialTemplate.parentId;
                childStructure.hasChildren = financialTemplate.children.length > 0;
                childStructure.label = financialTemplate.label;
                childStructure.shortLabel = shortLabel;
                childStructure.extendedGranularityStructure = copyGranularityStructure;
                childStructure.customFieldMap = financialTemplate.customFieldMap;
                parentStructure.children[childStructure.id] = childStructure;

                this.nodeReferenceDict[childStructure.id] = childStructure;
                newParent = childStructure;
            }

            if (financialTemplate.children.length > 0) {
                this.initializeShadowNodeStructure(newParent, financialTemplate.children, extendedGranularityStructure);
            }
        }
    }

    //  update the granularity cells from the shadowNodeStructure.
    private assignValuesToShadowStructure(financialValuesStructure: Array<FinancialValuesStructureModel>) {

        for (var financialValue of financialValuesStructure) {
            var shadowNode = this.nodeReferenceDict[financialValue.id]

            if (!shadowNode) {
                continue;
            }

            for (var granularityValue of financialValue.vals) {

                if (!shadowNode.extendedGranularityStructure[granularityValue.yr]) {
                    continue;
                }

                var granularityCell = shadowNode.extendedGranularityStructure[granularityValue.yr][granularityValue.mth];

                if (granularityCell) {
                    var value = granularityValue.val;
                    granularityCell.value = value;
                    granularityCell.displayValue = Utils.formatCurrency(value);
                }

            }
        }
    }

    // This function sets width for the unfrozen section of the grid.
    private refreshValueCellWidth() {
        var granularityLength = this.currentGranularityHeaderLabels.length;

        if (granularityLength <= 8) {
            this.financialGridSizeValues.unfrozenCellWidth = 1205 / granularityLength;
        } else {
            this.financialGridSizeValues.unfrozenCellWidth = 150;
        }

        this.financialGridSizeValues.unfrozenCellStyle = { 'width': `${this.financialGridSizeValues.unfrozenCellWidth}px` };
    }

    // This is used to resize the grid. Its useful for when the values have changed and the grid has smaller or bigger dimensions.
    // This can be tweeked as pleased to make sure all the dimensions are as deiresd.
    private resizeFinancialValuesGrid() {
        var scrollBarWidth = this.getScrollbarWidth();
        var granularityLabelsLength = this.currentGranularityHeaderLabels.length;
        var newHeight = this.flatNodeStructure.length * Utils.defaultGridSizeValues.granularityColumnDefaultHeight + Utils.defaultGridSizeValues.granularityColumnDefaultHeight + 6;
        var containerWidth = document.getElementsByClassName("fv-container")[0].clientWidth;
        var containerHeight = document.getElementsByClassName("fv-container")[0].clientHeight;

        this.financialGridSizeValues.financialTableContainerWidth = containerWidth;

        if (newHeight > containerHeight) {
            newHeight = containerHeight;
        }

        var maxLevel = 0;
        for (var flatNode of this.flatNodeStructure) {
            if (maxLevel < flatNode.level) {
                maxLevel = flatNode.level;
            }
        }

        // Wrapper over both tables
        this.financialGridSizeValues.financialTableWrapperWidth = containerWidth;
        this.financialGridSizeValues.financialTableWrapperHeight = newHeight;
        // Wrapper for the values table
        this.financialGridSizeValues.valuesTableWrapperWidth = this.financialGridSizeValues.financialTableWrapperWidth - Utils.defaultGridSizeValues.labelsCollumnWidth;

        this.financialGridSizeValues.valuesTableEmptyRowWidth = containerWidth - (granularityLabelsLength * Utils.defaultGridSizeValues.granularityColumnDefaultWidth) - scrollBarWidth - Utils.defaultGridSizeValues.labelsCollumnWidth;

        if (this.financialGridSizeValues.valuesTableEmptyRowWidth <= 0) {
            this.financialGridSizeValues.valuesTableEmptyRowWidth = 0;
        }

        this.financialGridSizeValues.valuesTableWidth = granularityLabelsLength * Utils.defaultGridSizeValues.granularityColumnDefaultWidth + this.financialGridSizeValues.valuesTableEmptyRowWidth

        this.financialGridSizeValues.valuesTableHeadWidth = this.financialGridSizeValues.valuesTableEmptyRowWidth + (granularityLabelsLength * Utils.defaultGridSizeValues.granularityColumnDefaultWidth) + Utils.defaultGridSizeValues.labelsCollumnWidth;
        var maximumHeight = containerHeight - Utils.defaultGridSizeValues.offset;

        this.financialGridSizeValues.labelsTableWrapperWidth = Utils.defaultGridSizeValues.labelsCollumnWidth;
        this.calculateTabelHeights(newHeight, scrollBarWidth, maximumHeight);
    }

    // TODO: The heights might be recreated to take into account the message rows.
    private calculateTabelHeights(newHeight: number, scrollBarWidth: number, maximumHeight: number) {
        var valuesHeight = 0;
        var labelsHeight = 0;

        if (newHeight >= maximumHeight) {
            valuesHeight = newHeight - Utils.defaultGridSizeValues.offset;
            // Wrapper for the labels table
            labelsHeight = valuesHeight - scrollBarWidth;
        } else {
            valuesHeight = newHeight;
            // Wrapper for the labels table
            labelsHeight = newHeight - scrollBarWidth;
        }

        this.financialGridSizeValues.valuesTableWrapperHeight = valuesHeight;
        // Wrapper for the labels table
        this.financialGridSizeValues.labelsTableWrapperHeight = labelsHeight;
    }

    private handleNodeVisibility(currentNode: FlatFinancialGridRowModel, isExpanded: boolean) {
        var vm = this;
        var nodeId = currentNode.id;
        this.overallNodeVisibility[currentNode.id] = isExpanded;

        vm.flatNodeStructure = [];
        vm.flattenNodeStructure(vm.shadowNodeStructure, vm.flatNodeStructure);
        vm.flatNodeStructure = vm.flatNodeStructure.concat([]);
        vm.resizeFinancialValuesGrid();
    }

    private flattenNodeStructure(financialGridRowNode: FinancialGridRowModel, flatNodeStructure: Array<FlatFinancialGridRowModel>) {
        var level = 0;
        var flatFinancialGridRow = this.initializeGridRowModel(financialGridRowNode, 1, level)
        flatNodeStructure.push(flatFinancialGridRow);

        if (flatFinancialGridRow.isExpanded) {
            level++;

            var childrenData = { paddingValue: 15, level: level };
            this.flattenNodeChildren(financialGridRowNode.children, flatNodeStructure, childrenData);
        }
    }

    private flattenNodeChildren(shadowNodeStructure: { [nodeID: string]: FinancialGridRowModel }, flatNodeStructure: Array<FlatFinancialGridRowModel>, childrenData: any) {

        for (var nodeKey in shadowNodeStructure) {
            var shadowNode: FinancialGridRowModel = shadowNodeStructure[nodeKey];
            var flatFinancialGridRow = this.initializeGridRowModel(shadowNode, childrenData.paddingValue, childrenData.level)
            flatNodeStructure.push(flatFinancialGridRow);

            if (Object.keys(shadowNode.children).length <= 0 || !flatFinancialGridRow.isExpanded) {
                continue;
            }

            var newPaddingValue = childrenData.paddingValue + 15;
            var newLevel = childrenData.level + 1;

            var newChildrenData = { paddingValue: newPaddingValue, level: newLevel };
            this.flattenNodeChildren(shadowNode.children, flatNodeStructure, newChildrenData);
        }
    }

    private initializeGridRowModel(financialGridRowNode: FinancialGridRowModel, paddingValue: number, level: number): FlatFinancialGridRowModel {
        var flatFinancialGridRow = new FlatFinancialGridRowModel(financialGridRowNode.label);
        flatFinancialGridRow.id = financialGridRowNode.id;
        flatFinancialGridRow.parentId = financialGridRowNode.parentId;
        flatFinancialGridRow.label = financialGridRowNode.label;
        flatFinancialGridRow.level = level;
        flatFinancialGridRow.paddingValue = paddingValue;
        if (level > 0) {
            flatFinancialGridRow.isExpanded = (financialGridRowNode.id in this.overallNodeVisibility) ? this.overallNodeVisibility[financialGridRowNode.id] : !this.financialGridMetaDataModel.isGridCollapsed;
        } else {
            flatFinancialGridRow.isExpanded = (financialGridRowNode.id in this.overallNodeVisibility) ? this.overallNodeVisibility[financialGridRowNode.id] : true;
        }

        //TODO: Revise this
        var shortLabel = "";
        if (financialGridRowNode.label.length >= 43) {
            shortLabel = financialGridRowNode.label.substring(0, 40) + "...";
        } else {
            shortLabel = financialGridRowNode.label;
        }

        flatFinancialGridRow.shortLabel = shortLabel;
        flatFinancialGridRow.hasChildren = financialGridRowNode.hasChildren;
        flatFinancialGridRow.cellInfo = this.granularityHandlerStrategy.getGridCellInfoData(flatFinancialGridRow.id, financialGridRowNode);

        if (!financialGridRowNode.hasChildren) {
            flatFinancialGridRow.cellBackgroundClass = "background-grid-level-7";
            flatFinancialGridRow.cellTextColorClass = "color-grid-level-7";
        } else {
            if (level > 7) {
                flatFinancialGridRow.cellBackgroundClass = "background-grid-level-6";
                flatFinancialGridRow.cellTextColorClass = "color-grid-level-6";
            }

            flatFinancialGridRow.cellBackgroundClass = `background-grid-level-${level}`;
            flatFinancialGridRow.cellTextColorClass = `color-grid-level-${level}`;
        }

        return flatFinancialGridRow;
    }

    private saveFinancialValues(): Observable<any> {
        var vm = this;
        var promise = new Promise(
            function (resolve, reject) {

                vm.waitDialog = SP.UI.ModalDialog.showWaitScreenWithNoClose("Loading", "Working on it.", 200, 300);

                vm.isFormInitializing = true;
                var newFinancialValuesStructures = new Array<FinancialValuesStructureModel>();
                vm.extractFinancialValues(vm.shadowNodeStructure, newFinancialValuesStructures);

                vm.saveMappedValues(vm.shadowNodeStructure).subscribe(res => {
                    vm.curentFinancialData.financialValuesJson = JSON.stringify(newFinancialValuesStructures);
                    vm.curentFinancialData.entityName = vm.financialGridMetaDataModel.entityName;

                    vm.curentFinancialData.originalStartDate = new Date(vm.originalStartDate);
                    vm.curentFinancialData.originalEndDate = new Date(vm.originalEndDate);

                    vm.sharePointService.saveFinancialValues(vm.curentFinancialData)
                        .subscribe(
                            () => {
                                vm.isFormInitializing = false;
                                vm.waitDialog.close(SP.UI.DialogResult.OK);
                                resolve();
                            },
                            (err) => {
                                vm.isFormInitializing = false;
                                vm.waitDialog.close(SP.UI.DialogResult.cancel);
                                reject(err);
                            });
                },
                    err => {
                        vm.isFormInitializing = false;
                        vm.waitDialog.close(SP.UI.DialogResult.cancel);
                        reject(err);
                    });
            });
        return Observable.fromPromise(promise);
    }

    private saveMappedValues(gridShadowTree: FinancialGridRowModel): Observable<any> {
        var vm = this;

        var promise = new Promise(function (resolve, reject) {
            var hostwebURL = decodeURIComponent(Utils.getQueryStringParameter("SPHostUrl"));
            var values = vm.extractMappedValues(gridShadowTree);
            var timeoutID: any = null;
            var postMesId = "" + Math.floor((Math.random() * 10000) + 1);

            var saveMappedEventListener = function (event: any) {
                if (event.data.indexOf("CFMappingsSaved") != -1) {

                    var dataArr = event.data.split('#');
                    if (dataArr[1] == postMesId) {
                        //once we're done remove this
                        window.removeEventListener("message", saveMappedEventListener);
                        if (timeoutID != null) {
                            clearTimeout(timeoutID);
                        }
                        resolve();
                    }
                }
            }

            var stringValues: string[] = []

            for (var cfVal of values) {
                stringValues.push(`${cfVal.customFieldID}:${Math.round(cfVal.value)}`);
            }

            window.addEventListener("message", saveMappedEventListener);
            window.parent.postMessage(`onSaveMappedFieldValues#${postMesId}#${stringValues.join("|")}`, hostwebURL);
            timeoutID = setTimeout(() => {
                reject("Save mapped fields timed out.");
            }, 30 * 1000)
        });

        return Observable.fromPromise(promise);
    }

    private extractMappedValues(gridNode: FinancialGridRowModel): Array<{ customFieldID: string, value: number }> {
        var result: Array<{ customFieldID: string, value: number }> = [];

        if (gridNode.customFieldMap) {

            for (var i = 0; i < gridNode.customFieldMap.length; i++) {
                var mapGranularity = null;

                if (gridNode.customFieldMap[i].aggregationType == MapAggregationType.LIFETIME) {
                    mapGranularity = "Lifetime";
                } else if (gridNode.customFieldMap[i].aggregationType == MapAggregationType.FIRST_FY) {
                    mapGranularity = "Years";
                } else {
                    mapGranularity = "Months";
                }

                var granStrategy = this.granularityHandlerFactory.getGranularityHandlerStrategy(
                    mapGranularity,
                    this.nodeReferenceDict,
                    this.currentFinancialTemplate,
                    this.financialGridMetaDataModel.isGranularityEditable,
                    this.isCheckedOutToCurrentUser,
                    this.financialGridMetaDataModel.isGridEditable);

                if (gridNode.customFieldMap[i].aggregationType == MapAggregationType.LIFETIME || gridNode.customFieldMap[i].aggregationType == MapAggregationType.FIRST_FY) {
                    //if we're using lifetime or first fiscal year it's always the first value, this might change for other scenarios tho
                    var nodeinfo = granStrategy.getGridCellInfoData(gridNode.id, gridNode)[0];

                    result.push({
                        customFieldID: gridNode.customFieldMap[i].customFieldUid,
                        value: nodeinfo.cellModel.value
                    });
                } else {
                    var cellValues = granStrategy.getGridCellInfoData(gridNode.id, gridNode);

                    var mapStartDate = this.momentReference(gridNode.customFieldMap[i].startYear + "-" + ((gridNode.customFieldMap[i].startMonth + 1) > 9 ? (gridNode.customFieldMap[i].startMonth + 1) : ("0" + (gridNode.customFieldMap[i].startMonth + 1))) + "-15");
                    var mapEndDate = this.momentReference(gridNode.customFieldMap[i].endYear + "-" + ((gridNode.customFieldMap[i].endMonth + 1) > 9 ? (gridNode.customFieldMap[i].endMonth + 1) : ("0" + (gridNode.customFieldMap[i].endMonth + 1))) + "-15");
                    var rowValue = 0;
                    for (var j = 0; j < cellValues.length; j++) {
                        let cYear = cellValues[j].shadowNodeReferenceKeys[0].year;
                        let cMonth = parseInt(cellValues[j].shadowNodeReferenceKeys[0].months[0]);
                        let cValue = cellValues[j].cellModel.value;

                        var cellDate = this.momentReference(cYear + "-" + ((cMonth + 1) > 9 ? (cMonth + 1) : ("0" + (cMonth + 1))) + "-15");

                        if (!cellDate.isAfter(mapEndDate, "month") && !cellDate.isBefore(mapStartDate, "month")) {
                            rowValue = rowValue + (cValue ? cValue : 0);
                        }
                    }

                    result.push({
                        customFieldID: gridNode.customFieldMap[i].customFieldUid,
                        value: rowValue
                    });
                }


            }
        }


        for (var childNodeID in gridNode.children) {
            var childNode = gridNode.children[childNodeID];
            var cldValues = this.extractMappedValues(childNode);
            result = result.concat(cldValues);
        }

        return result;
    }

    private extractFinancialValues(financialGridNode: FinancialGridRowModel, newFinancialValuesStructures: Array<FinancialValuesStructureModel>) {

        var newFinancialValuesStructure = new FinancialValuesStructureModel();
        newFinancialValuesStructure.id = financialGridNode.id;
        newFinancialValuesStructure.pid = financialGridNode.parentId;

        for (var yr in financialGridNode.extendedGranularityStructure) {
            for (var mnth in financialGridNode.extendedGranularityStructure[yr]) {
                var granularityValue = new GranularityValueModel();
                var newValue = financialGridNode.extendedGranularityStructure[yr][mnth].value;
                if (newValue > 0) {
                    granularityValue.yr = yr;
                    granularityValue.mth = mnth;
                    granularityValue.val = newValue;
                    newFinancialValuesStructure.vals.push(granularityValue);
                }
                else {
                    granularityValue.yr = yr;
                    granularityValue.mth = mnth;
                    granularityValue.val = newValue;
                    newFinancialValuesStructure.vals.push(granularityValue);
                }
            }
        }

        newFinancialValuesStructures.push(newFinancialValuesStructure)

        for (var childNodeID in financialGridNode.children) {
            var childNode = financialGridNode.children[childNodeID];
            this.extractFinancialValues(childNode, newFinancialValuesStructures);
        }
    }

    private pushTimescaleSelectedDates() {
        this.timescalePropertyModel.startDate = new Date(this.timescalePropertyModel.selectedStartDate);
        this.timescalePropertyModel.endDate = new Date(this.timescalePropertyModel.selectedEndDate);
        this.curentFinancialData.financialStartDate = new Date(this.timescalePropertyModel.selectedStartDate);
        this.curentFinancialData.financialEndDate = new Date(this.timescalePropertyModel.selectedEndDate);
        this.financialGridMetaDataModel.areFinancialValuesDirty = true;
        this.postValuesChanged();

    }

    // This function is used to reinitialize the grid after some updates have occured.
    private reinitializeFlatStructure() {
        this.resetMessage();
        this.flatNodeStructure = [];
        var tmpHeaders = this.granularityHandlerStrategy.getGranularityHeaderLabels(this.curentFinancialData.financialStartDate, this.curentFinancialData.financialEndDate, this.curentFinancialData.granularity, this.newCurrentFiscalMonthNumber, this.newFinancialStartMonth, this.newFinancialEndMonth);
        this.currentGranularityHeaderLabels = tmpHeaders;

        this.refreshValueCellWidth();

        this.flattenNodeStructure(this.shadowNodeStructure, this.flatNodeStructure)
        this.flatNodeStructure = [].concat(this.flatNodeStructure)
        this.resizeFinancialValuesGrid();
    }

    // This function initializes the p-confirm dialog from prime ng and also waits for the users' response.
    private getUserConfirmation(dialogHeader: string, dialogMessage: string): Observable<boolean> {
        var vm = this;

        var promise = new Promise<boolean>(function (resolve, reject) {

            vm.confirmationService.confirm({
                header: dialogHeader,
                message: dialogMessage,
                accept: () => {
                    resolve(true);
                },
                reject: () => {
                    resolve(false);
                }
            });

        });
        return Observable.fromPromise(promise);
    }

    private updateGranularityCellValues(childNode: FlatFinancialGridRowModel, partitionIndex: number) {
        var vm = this;
        var parentId = childNode.parentId;

        if (this.flatNodeStructure.length == 1) {
            var node = this.flatNodeStructure[0];
            this.granularityHandlerStrategy.updateReferencedValues(node, partitionIndex);
        } else {

            var updateInProgress = true;
            while (updateInProgress) {

                if (parentId == Utils.getNoneRootID()) {
                    break;
                }

                var parentNode: FlatFinancialGridRowModel;

                //TODO: revisit this on next refactor
                for (var flatNode of this.flatNodeStructure) {
                    if (flatNode.id == parentId) {
                        parentNode = flatNode;
                        break;
                    }
                }

                var parentGranularityCellNode: GranularityCellModel = parentNode.cellInfo[partitionIndex].cellModel;
                parentGranularityCellNode.value = 0;
                parentGranularityCellNode.displayValue = Utils.formatCurrency(parentGranularityCellNode.value)


                //TODO: revisit on refactor, instead of doing a full reaggr subtract old valu and add new...
                for (var flatNode of this.flatNodeStructure) {
                    if (flatNode.parentId == parentNode.id) {
                        parentGranularityCellNode.value += flatNode.cellInfo[partitionIndex].cellModel.value;
                    }
                }

                parentGranularityCellNode.displayValue = Utils.formatCurrency(parentGranularityCellNode.value)

                this.granularityHandlerStrategy.updateReferencedValues(childNode, partitionIndex);
                this.granularityHandlerStrategy.updateReferencedValues(parentNode, partitionIndex);

                if (parentNode.id == Utils.getDefaultRootID()) {
                    updateInProgress = false;
                } else {
                    parentId = parentNode.parentId;
                }
            }
        }

        this.financialGridMetaDataModel.areFinancialValuesDirty = true;
        this.postValuesChanged();
    }

    //TIMELINE CHNAGE OPERATIONS
    private applyTimelineChanges(operationType: string, financialTimescalePropertyModel: FinancialTimescalePropertyModel, shouldSaveValues: boolean): void {
        var vm = this;

        switch (operationType) {
            case "CUT":
            case "EXTEND":
            case "RECALCULATE":
                vm.pushTimescaleSelectedDates();
                vm.applyTimelineChangesToValues(operationType, financialTimescalePropertyModel, shouldSaveValues).then(function () {
                    vm.refreshGrid();
                    vm.showGrid = true;
                    vm.showTimelineUpdate = false;
                });
                break;
            case "SHIFT":
                var oldStart = new Date(this.curentFinancialData.financialStartDate);
                var oldEnd = new Date(this.curentFinancialData.financialEndDate);
                var newStart = new Date(financialTimescalePropertyModel.selectedStartDate);
                var newEnd = new Date(financialTimescalePropertyModel.selectedEndDate);

                vm.pushTimescaleSelectedDates();
                vm.shiftFinancialStructure(oldStart, oldEnd, newStart, newEnd, shouldSaveValues).then(function () {
                    vm.refreshGrid();
                    vm.showGrid = true;
                    vm.showTimelineUpdate = false;
                });
                break;

            case "CANCEL":
                this.timescalePropertyModel.selectedStartDate = new Date(this.timescalePropertyModel.startDate);
                this.timescalePropertyModel.selectedEndDate = new Date(this.timescalePropertyModel.endDate);
                vm.showGrid = true;
                vm.showTimelineUpdate = false;
                break;
            default:
                this.showMessage(["Invalid timeline operation type"], AppSettings.getErrorMessage());
                break;
        }
    }

    private applyTimelineChangesToValues(operationType: string, financialTimescalePropertyModel: FinancialTimescalePropertyModel, shouldSaveValues: boolean) {
        var vm = this;

        var promise = new Promise<any>(function (resolve, reject) {

            vm.applyTimelineChangesToValuesRecursive(operationType, financialTimescalePropertyModel, vm.shadowNodeStructure);
            vm.curentFinancialData.financialStartDate = financialTimescalePropertyModel.startDate;
            vm.curentFinancialData.financialEndDate = financialTimescalePropertyModel.endDate;

            if (!shouldSaveValues) {
                resolve();
                return;
            }

            vm.saveFinancialValues().subscribe(
                () => {
                    vm.showMessage(["<b>Financial Values</b> updated successfully."], AppSettings.getSuccessMessage())
                    vm.financialGridMetaDataModel.areFinancialValuesDirty = false;
                    resolve();
                }, (err: any) => {
                    reject();
                    vm.showMessage(["Something went wrong.", err], AppSettings.getErrorMessage());
                });

        });

        return promise;
    }

    private applyTimelineChangesToValuesRecursive(operationType: string, financialTimescalePropertyModel: FinancialTimescalePropertyModel, financialGridRowNode: FinancialGridRowModel) {
        var newExtendedStructure: { [year: string]: { [month: string]: GranularityCellModel } } = {};

        var timescaleStartDate = financialTimescalePropertyModel.startDate;
        var momentTimescaleStartDate = this.momentReference(timescaleStartDate);
        var timescaleEndDate = financialTimescalePropertyModel.endDate;
        var momentTimescaleEndDate = this.momentReference(timescaleEndDate);

        var perMonthValue = 0;

        if (operationType == "RECALCULATE") {
            var timeScaleMonths = Utils.getMonthsBetween(financialTimescalePropertyModel.startDate, financialTimescalePropertyModel.endDate)
            var totalGranularityValue = this.getNodeTotal(financialGridRowNode);
            perMonthValue = totalGranularityValue / timeScaleMonths;
        }

        while (!momentTimescaleStartDate.isAfter(momentTimescaleEndDate, "month")) {
            var month = momentTimescaleStartDate.month();
            var year = momentTimescaleStartDate.year();

            if (!newExtendedStructure[year]) {
                newExtendedStructure[year] = {};
            }

            if (financialGridRowNode.extendedGranularityStructure[year] && financialGridRowNode.extendedGranularityStructure[year][month]) {
                newExtendedStructure[year][month] = financialGridRowNode.extendedGranularityStructure[year][month];
            } else {
                newExtendedStructure[year][month] = new GranularityCellModel();
            }

            if (operationType == "RECALCULATE") {
                newExtendedStructure[year][month].value = perMonthValue;
                newExtendedStructure[year][month].displayValue = Utils.formatCurrency(newExtendedStructure[year][month].value);
            }

            momentTimescaleStartDate.add(1, "month");
        }

        financialGridRowNode.extendedGranularityStructure = newExtendedStructure;

        for (var childId in financialGridRowNode.children) {
            this.applyTimelineChangesToValuesRecursive(operationType, financialTimescalePropertyModel, financialGridRowNode.children[childId]);
        }
    }

    private getNodeTotal(financialGridRowNode: FinancialGridRowModel) {
        var totalGranularityValue = 0;

        for (var year in financialGridRowNode.extendedGranularityStructure) {
            for (var month in financialGridRowNode.extendedGranularityStructure[year]) {
                totalGranularityValue += financialGridRowNode.extendedGranularityStructure[year][month].value;
            }
        }

        return totalGranularityValue;
    }

    private shiftFinancialStructure(oldStart: Date, oldEnd: Date, newStart: Date, newEnd: Date, shouldSaveValues: boolean) {
        var vm = this;

        var promise = new Promise<any>(function (resolve, reject) {
            vm.shiftFinancialStructureRecursive(oldStart, oldEnd, newStart, newEnd, vm.shadowNodeStructure);

            if (!shouldSaveValues) {
                resolve();
                return;
            }

            vm.saveFinancialValues().subscribe(
                () => {
                    vm.showMessage(["<b>Financial Values</b> updated successfully."], AppSettings.getSuccessMessage())
                    vm.financialGridMetaDataModel.areFinancialValuesDirty = false;
                    resolve();
                }, (err: any) => {
                    vm.showMessage(["Something went wrong.", err], AppSettings.getErrorMessage());
                    reject();
                });
        })

        return promise;


    }

    private shiftFinancialStructureRecursive(oldStart: Date, oldEnd: Date, newStart: Date, newEnd: Date, financialGridRowNode: FinancialGridRowModel) {
        var newExtendedStructure: { [year: string]: { [month: string]: GranularityCellModel } } = {};

        //console.log("oldDates: " + oldStart + " || " + oldEnd);
        //console.log("newDates: " + newStart + " || " + newEnd);
        //console.log("financialGridRowNode:");
        //console.log(financialGridRowNode);

        var currentDate = this.momentReference(newStart);
        var timeScaleEndDate = this.momentReference(newEnd);

        var previousDate = this.momentReference(oldStart);

        while (!currentDate.isAfter(timeScaleEndDate, "month")) {
            var newMonth = currentDate.month();
            var newYear = currentDate.year();

            var oldMonth = previousDate.month();
            var oldYear = previousDate.year();

            if (!newExtendedStructure[newYear]) {
                newExtendedStructure[newYear] = {};
            }
            //console.log(financialGridRowNode.label);


            if (this.oldJSONobject != "") {
                var oldfinancialValuesStructure: Array<FinancialValuesStructureModel> = JSON.parse(this.oldJSONobject);
                var findNode = oldfinancialValuesStructure.filter(function (element) {
                    return element.id == financialGridRowNode.id;
                });

                if (findNode.length >= 1) {

                    var value = findNode[0].vals.filter(function (element) {
                        return element.yr == oldYear && element.mth == oldMonth;
                    });
                    if (value.length >= 1) {
                        newExtendedStructure[newYear][newMonth] = new GranularityCellModel();
                        newExtendedStructure[newYear][newMonth].value = value[0].val;
                        newExtendedStructure[newYear][newMonth].displayValue = Utils.formatCurrency(newExtendedStructure[newYear][newMonth].value);
                    }
                    else {
                        newExtendedStructure[newYear][newMonth] = new GranularityCellModel();
                    }
                }
                else {
                    newExtendedStructure[newYear][newMonth] = new GranularityCellModel();
                }
            }
            else {
                //console.log("oldJSONobject is empty");
                newExtendedStructure[newYear][newMonth] = new GranularityCellModel();
            }

            currentDate.add(1, "month");
            previousDate.add(1, "month");
        }

        financialGridRowNode.extendedGranularityStructure = newExtendedStructure;

        for (var childId in financialGridRowNode.children) {
            this.shiftFinancialStructureRecursive(oldStart, oldEnd, newStart, newEnd, financialGridRowNode.children[childId]);
        }
    }

    //END TIMELINE CHNAGE OPERATIONS

    //GRID UI EVENTS

    public onFinancialValuesTableDataClick(event: any) {
        var className: string = event.srcElement.className;

        if (className.indexOf("values-table-granularity-column") != -1) {
            event.srcElement.getElementsByClassName("values-table-cell-input")[0].focus();
        } else if (className.indexOf("values-table-cell-input") != -1) {
            event.srcElement.focus();
        }
    }

    public onFinancialValuesTableScroll(event: any) {
        // vertical scroll
        this.financialLabelsTable.nativeElement.scrollTop = event.srcElement.scrollTop;

        // horizontal scroll
        var offsetValue = Utils.defaultGridSizeValues.labelsCollumnWidth;
        var newValue = offsetValue - event.srcElement.scrollLeft;
        this.granularityLabelsLeftScrollValue = `${newValue}px`;

    }

    public onGranularityNodeClick(event: any, node: FlatFinancialGridRowModel, partitionIndex: number, cellModel: GranularityCellModel) {
        if (!this.isCellDoubleClicked && event.srcElement.value.includes("$")) {
            this.previousGranularityCellModels[`${node.id}-${partitionIndex}`] = cellModel.value;

            if (!this.financialGridMetaDataModel.isGranularityEditable) {
                return;
            }

            if (!cellModel.editable) {
                return;
            }

            if (!this.isCheckedOutToCurrentUser) {
                return;
            }

            if (event.keyCode != 39 && event.keyCode != 37 && event.keyCode != 38 && event.keyCode != 40) {
                $(event.srcElement).select();
            }
        }
        else {
            if (event.offsetX > 118) {
                event.srcElement.setSelectionRange(event.srcElement.value.length, event.srcElement.value.length);
            }
            if (event.offsetX > 111 && event.offsetX < 118) {
                event.srcElement.setSelectionRange(event.srcElement.value.length - 1, event.srcElement.value.length - 1);
            }
            if (event.offsetX > 104 && event.offsetX < 111) {
                event.srcElement.setSelectionRange(event.srcElement.value.length - 2, event.srcElement.value.length - 2);
            }
            if (event.offsetX > 98 && event.offsetX < 104) {
                event.srcElement.setSelectionRange(event.srcElement.value.length - 3, event.srcElement.value.length - 3);
            }
            if (event.offsetX > 92 && event.offsetX < 98) {
                event.srcElement.setSelectionRange(event.srcElement.value.length - 4, event.srcElement.value.length - 4);
            }
            if (event.offsetX > 86 && event.offsetX < 92) {
                event.srcElement.setSelectionRange(event.srcElement.value.length - 5, event.srcElement.value.length - 5);
            }
            if (event.offsetX > 80 && event.offsetX < 86) {
                event.srcElement.setSelectionRange(event.srcElement.value.length - 6, event.srcElement.value.length - 6);
            }
            if (event.offsetX > 74 && event.offsetX < 80) {
                event.srcElement.setSelectionRange(event.srcElement.value.length - 7, event.srcElement.value.length - 7);
            }
            if (event.offsetX > 68 && event.offsetX < 74) {
                event.srcElement.setSelectionRange(event.srcElement.value.length - 8, event.srcElement.value.length - 8);
            }
            if (event.offsetX > 62 && event.offsetX < 68) {
                event.srcElement.setSelectionRange(event.srcElement.value.length - 9, event.srcElement.value.length - 9);
            }
            if (event.offsetX > 56 && event.offsetX < 62) {
                event.srcElement.setSelectionRange(event.srcElement.value.length - 10, event.srcElement.value.length - 10);
            }
            if (event.offsetX > 50 && event.offsetX < 56) {
                event.srcElement.setSelectionRange(event.srcElement.value.length - 11, event.srcElement.value.length - 11);
            }
            if (event.offsetX > 44 && event.offsetX < 50) {
                event.srcElement.setSelectionRange(event.srcElement.value.length - 12, event.srcElement.value.length - 12);
            }
            if (event.offsetX > 38 && event.offsetX < 44) {
                event.srcElement.setSelectionRange(event.srcElement.value.length - 13, event.srcElement.value.length - 13);
            }
            if (event.offsetX > 32 && event.offsetX < 38) {
                event.srcElement.setSelectionRange(event.srcElement.value.length - 14, event.srcElement.value.length - 14);
            }
            if (event.offsetX > 26 && event.offsetX < 32) {
                event.srcElement.setSelectionRange(event.srcElement.value.length - 15, event.srcElement.value.length - 15);
            }
            if (event.offsetX < 26) {
                event.srcElement.setSelectionRange(0, 0);
            }

        }

    }

    public onGranularityCellDoubleClick(event: MouseEvent, node: FlatFinancialGridRowModel, partitionIndex: number, cellModel: GranularityCellModel) {
        //$(event.srcElement).select();
        this.isCellDoubleClicked = true;

        if (cellModel.value != 0) {
            cellModel.displayValue = cellModel.value.toString();
        }
        else {
            cellModel.displayValue = "";
        }
        let d = <HTMLInputElement>event.srcElement;
        if (cellModel.value != 0) {
            d.value = cellModel.value.toString();
        }
        else {
            d.value = "";
        }
        d.focus();

        if (event.offsetX > 125) {
            d.setSelectionRange(d.value.length, d.value.length);
        }
        if (event.offsetX > 120 && event.offsetX < 125) {
            d.setSelectionRange(d.value.length - 1, d.value.length - 1);
        }
        if (event.offsetX > 115 && event.offsetX < 120) {
            d.setSelectionRange(d.value.length - 2, d.value.length - 2);
        }
        if (event.offsetX > 105 && event.offsetX < 115) {
            d.setSelectionRange(d.value.length - 3, d.value.length - 3);
        }
        if (event.offsetX > 100 && event.offsetX < 105) {
            d.setSelectionRange(d.value.length - 4, d.value.length - 4);
        }
        if (event.offsetX > 95 && event.offsetX < 100) {
            d.setSelectionRange(d.value.length - 5, d.value.length - 5);
        }
        if (event.offsetX > 85 && event.offsetX < 95) {
            d.setSelectionRange(d.value.length - 6, d.value.length - 6);
        }
        if (event.offsetX > 80 && event.offsetX < 85) {
            d.setSelectionRange(d.value.length - 7, d.value.length - 7);
        }
        if (event.offsetX > 75 && event.offsetX < 80) {
            d.setSelectionRange(d.value.length - 8, d.value.length - 8);
        }
        if (event.offsetX > 65 && event.offsetX < 75) {
            d.setSelectionRange(d.value.length - 9, d.value.length - 9);
        }
        if (event.offsetX > 60 && event.offsetX < 65) {
            d.setSelectionRange(d.value.length - 10, d.value.length - 10);
        }
        if (event.offsetX > 55 && event.offsetX < 60) {
            d.setSelectionRange(d.value.length - 11, d.value.length - 11);
        }
        if (event.offsetX > 45 && event.offsetX < 55) {
            d.setSelectionRange(d.value.length - 12, d.value.length - 12);
        }
        if (event.offsetX > 40 && event.offsetX < 45) {
            d.setSelectionRange(d.value.length - 13, d.value.length - 13);
        }
        if (event.offsetX > 35 && event.offsetX < 40) {
            d.setSelectionRange(d.value.length - 14, d.value.length - 14);
        }
        if (event.offsetX > 30 && event.offsetX < 35) {
            d.setSelectionRange(d.value.length - 15, d.value.length - 15);
        }
        if (event.offsetX < 30) {
            d.setSelectionRange(0, 0);
        }
    }

    public onGranularityCellInputBlur(event: any, granularityCell: GranularityCellModel) {
        if (!granularityCell) {
            return;
        }

        if (!granularityCell.displayValue) {
            granularityCell.displayValue = "0";
        }

        granularityCell.displayValue = Utils.formatCurrency(granularityCell.value);
    }

    public onGranularityCellInputLeaveBlur(event: any, granularityCell: GranularityCellModel) {
        if (this.selectionModel.dragSelectionStarted) {

            this.onGranularityCellInputBlur(event, granularityCell);
        }
        this.isCellDoubleClicked = false;
    }

    public onGranularityCellValueChange(event: any, node: FlatFinancialGridRowModel, partitionIndex: number) {
        var previousGranularityCellModelValue = this.previousGranularityCellModels[`${node.id}-${partitionIndex}`];
        var granularityCell = node.cellInfo[partitionIndex].cellModel;
        granularityCell.displayValue = event.target.value;

        if (!granularityCell.displayValue) {
            granularityCell.displayValue = "0";
        }

        if (!granularityCell.displayValue.replace(/\s/g, '').length) {
            granularityCell.displayValue = "0";
        }

        var cleanValue = Utils.sanitizeNumberValueProjects(granularityCell.displayValue);

        if (!cleanValue) {
            granularityCell.value = previousGranularityCellModelValue;
        } else {
            var parseValue = parseFloat(cleanValue);
            if (Utils.isNumber(parseValue)) {
                granularityCell.value = parseValue;
            } else {
                granularityCell.value = previousGranularityCellModelValue;
            }
        }

        granularityCell.displayValue = Utils.formatCurrency(granularityCell.value);

        if (event.target.value != granularityCell.displayValue) {
            event.target.value = granularityCell.displayValue
        }
        if (granularityCell.value != previousGranularityCellModelValue) {
            this.updateGranularityCellValues(node, partitionIndex);
            this.postValuesChanged();
        }
        //if (event.srcElement) {
        //    event.srcElement.blur();
        //}
    }

    public onGranularityTypeChanged(event: any) {
        var vm = this;
        vm.clearSelection();
        vm.curentFinancialData.granularity = event;
        vm.financialGridMetaDataModel.selectedGranularity = event;
        vm.financialGridMetaDataModel.isGranularityEditable = vm.financialGridMetaDataModel.editGranularity == vm.curentFinancialData.granularity;
        vm.granularityHandlerStrategy = vm.granularityHandlerFactory.getGranularityHandlerStrategy(vm.curentFinancialData.granularity, vm.nodeReferenceDict, this.currentFinancialTemplate, this.financialGridMetaDataModel.isGranularityEditable, this.isCheckedOutToCurrentUser, this.financialGridMetaDataModel.isGridEditable);

        vm.reinitializeFlatStructure();
        //vm.setCookie("finGridGranularity", vm.curentFinancialData.granularity, 60);

    }

    public onStartDateChange(event: any) {
        var vm = this;
        vm.resetMessage();
        vm.clearSelection();
        if (!this.timescalePropertyModel.selectedStartDate) {
            vm.showMessage(["Invalid start date. No changes made."], AppSettings.getErrorMessage());
            this.timescalePropertyModel.selectedStartDate = new Date(this.timescalePropertyModel.startDate);
            return;
        }

        if (this.momentReference(this.timescalePropertyModel.startDate).isSame(this.timescalePropertyModel.selectedStartDate, "day")) {
            return;
        }

        if (this.momentReference(this.timescalePropertyModel.selectedEndDate).isBefore(this.timescalePropertyModel.selectedStartDate, "day")) {
            this.showMessage(["End date value must be greater than start date value. No changes made."], AppSettings.getErrorMessage());
            this.timescalePropertyModel.selectedStartDate = new Date(this.timescalePropertyModel.startDate);
            return;
        }

        if (this.momentReference(this.timescalePropertyModel.startDate).isSame(this.timescalePropertyModel.selectedStartDate, "month")) {
            this.pushTimescaleSelectedDates();
        } else {
            var grdEmpty = this.isGridEmpty();
            if (grdEmpty) {
                this.updateTimeline({ operation: "EXTEND", save: false });
            } else {
                this.showTimelineUpdateComponent(true);
            }
        }
    }

    public onEndDateChange(event: any) {
        var vm = this;
        vm.resetMessage();
        vm.clearSelection();
        if (!this.timescalePropertyModel.selectedEndDate) {
            vm.showMessage(["Invalid start date. No changes made."], AppSettings.getErrorMessage());
            this.timescalePropertyModel.selectedStartDate = new Date(this.timescalePropertyModel.startDate);
            return;
        }

        if (this.momentReference(this.timescalePropertyModel.endDate).isSame(this.timescalePropertyModel.selectedEndDate, "day")) {
            return;
        }

        if (this.momentReference(this.timescalePropertyModel.selectedEndDate).isBefore(this.timescalePropertyModel.selectedStartDate, "day")) {
            this.showMessage(["End date value must be greater than start date value. No changes made."], AppSettings.getErrorMessage());
            this.timescalePropertyModel.selectedEndDate = new Date(this.timescalePropertyModel.endDate);
            return;
        }

        if (this.momentReference(this.timescalePropertyModel.endDate).isSame(this.timescalePropertyModel.selectedEndDate, "month")) {
            this.pushTimescaleSelectedDates();
        } else {
            var grdEmpty = this.isGridEmpty();
            if (grdEmpty) {
                this.updateTimeline({ operation: "EXTEND", save: false });
            } else {
                this.showTimelineUpdateComponent(true);
            }
        }
    }

    public onSaveSnapshotButtonClick(event: any) {
        var vm = this;

        this.getUserConfirmation('Saving Financial Values Snapshot', 'Are you sure you want to save this <b>Snapshot</b>?')
            .subscribe(
                (isSaveAccepted) => {
                    if (!isSaveAccepted) {
                        return
                    }

                    this.waitDialog = SP.UI.ModalDialog.showWaitScreenWithNoClose("Loading", "Working on it.", 200, 300);

                    this.isFormInitializing = true;
                    var financialValuesStructure = vm.shadowNodeStructure;
                    var structure = JSON.stringify(financialValuesStructure);

                    vm.sharePointService.saveFinancialSnapshot(vm.curentFinancialData, structure, vm.currentFinancialTemplate.granularityStartMonthAsNumber)
                        .subscribe(
                            () => {
                                vm.showMessage(["Financial Template Snapshot saved successfully."], AppSettings.getSuccessMessage())
                                vm.isFormInitializing = false;
                                vm.waitDialog.close(SP.UI.DialogResult.OK);
                            },
                            (err) => {
                                vm.showMessage(["Something went wrong.", err], AppSettings.getErrorMessage());
                                vm.isFormInitializing = false;
                                vm.waitDialog.close(SP.UI.DialogResult.cancel);
                            }
                        );

                }, (err) => {
                    vm.showMessage(["Something went wrong.", err], AppSettings.getErrorMessage());
                });
    }

    public oNodeExpandClick(currentNode: FlatFinancialGridRowModel) {
        this.clearSelection();
        this.handleNodeVisibility(currentNode, true);
    }

    public oNodeCollapseClick(currentNode: FlatFinancialGridRowModel) {
        this.clearSelection();
        this.handleNodeVisibility(currentNode, false);
    }

    public handleRibbonSaveClick(event: any): Observable<any> {
        var vm = this;
        var promise = new Promise(
            function (resolve, reject) {

                if (!vm.financialGridMetaDataModel.areFinancialValuesDirty) {
                    resolve();
                } else {
                    vm.saveFinancialValues().subscribe(
                        () => {
                            vm.showMessage(["<b>Financial Values</b> saved successfully."], AppSettings.getSuccessMessage())
                            vm.financialGridMetaDataModel.areFinancialValuesDirty = false;

                            if (vm.financialGridMetaDataModel.listItemId == -1) {
                                vm.postValuesChanged();
                            }
                            resolve();
                        },
                        (err) => {
                            vm.showMessage(["Something went wrong.", err], AppSettings.getErrorMessage());
                            resolve(err);
                        })
                }
            });


        vm.saveGridPromise = promise;

        return Observable.fromPromise(promise);
    }

    //END GRID UI EVENTS 

    //COPY PASTE AND NAV
    public onValuePaste(e: any): any {
        let content = "";

        let useIE = this.isIE();

        if (useIE) {
            content = (<any>window).clipboardData.getData("Text")
        } else {
            content = e.clipboardData.getData('text/plain');
        }


        let trimmCont = content.replace(/\$/g, '').replace(/ /g, '');

        let isNormalPaste = false;

        try {
            var testContent = content.replace(/\n/g, 'NL').replace(/\r/g, 'CR');
            if (testContent.endsWith("CRNL")) {
                testContent = testContent.substring(0, trimmCont.length - 5);
            } else if (testContent.endsWith("NL")) {
                testContent = testContent.substring(0, trimmCont.length - 3);
            }


            var numberReg = /(^-?\d+\.?\d*)$/

            isNormalPaste = numberReg.test(testContent)

        } catch {
            isNormalPaste = false;
        }



        if (isNormalPaste) {
            var fakeEvt = {
                target: {
                    value: trimmCont
                }
            }
            this.previousGranularityCellModels[`${this.flatNodeStructure[this.selectionModel.sY].id}-${(this.selectionModel.sX)}`] = -1;
            this.onGranularityCellValueChange(fakeEvt, this.flatNodeStructure[this.selectionModel.sY], this.selectionModel.sX);
            e.preventDefault();
            return false;
            //normal paste 
        } else {

            if ((trimmCont.indexOf("\n") > -1 || trimmCont.indexOf("\t") > -1) && this.financialGridMetaDataModel.isGridEditable && this.financialGridMetaDataModel.editGranularity == this.financialGridMetaDataModel.selectedGranularity) {


                try {

                    if (this.selectionModel.fX > -1) {
                        let copyMatrix = [];

                        let copiedRows: string[] = [];

                        if (useIE) {
                            copiedRows = trimmCont.split("\r\n");
                        } else {
                            copiedRows = trimmCont.split("\n");
                        }


                        if (copiedRows[copiedRows.length - 1] == "") {
                            copiedRows.splice(copiedRows.length - 1, 1);
                        }

                        let rowLength = (this.selectionModel.fY == -1 || (this.selectionModel.fY == this.selectionModel.sY && this.selectionModel.fX == this.selectionModel.sX)) ? copiedRows.length : (Math.min(copiedRows.length, this.selectionModel.fY - this.selectionModel.sY + 1));

                        for (var rowIndex = 0; rowIndex < rowLength; rowIndex++) {
                            if (copiedRows[rowIndex] != "") {
                                var cells = copiedRows[rowIndex].split("\t");
                                var cellValues: string[] = [];
                                var cellLength = (this.selectionModel.fY == -1 || (this.selectionModel.fY == this.selectionModel.sY && this.selectionModel.fX == this.selectionModel.sX)) ? cells.length : (Math.min(cells.length, this.selectionModel.fX - this.selectionModel.sX + 1));
                                for (var cellIndex = 0; cellIndex < cellLength; cellIndex++) {
                                    if (cells[cellIndex] != "") {
                                        cellValues.push(cells[cellIndex]);
                                    } else {
                                        cellValues.push("0");
                                    }

                                }

                                copyMatrix.push(cellValues);
                            }
                        }


                        this.applyCopyMatrix(copyMatrix, this.selectionModel.sX, this.selectionModel.sY);
                    }

                } catch {
                    console.log("paste failed...")
                }
            }
            e.preventDefault();

            return false;
        }

    }

    private applyCopyMatrix(copyMatrix: string[][], startX: number, startY: number) {
        var nextRowAvailable = true;

        for (let matY = 0; (startY + matY) < this.flatNodeStructure.length && !this.flatNodeStructure[startY + matY].hasChildren && matY < copyMatrix.length; matY++) {

            let cRow = this.flatNodeStructure[startY + matY];

            for (let matX = 0; matX < copyMatrix[matY].length && (matX + startX) < cRow.cellInfo.length; matX++) {
                //create faux event
                var fakeEvt = {
                    target: {
                        value: copyMatrix[matY][matX]
                    }
                }
                this.previousGranularityCellModels[`${this.flatNodeStructure[startY + matY].id}-${(matX + startX)}`] = -1;
                this.onGranularityCellValueChange(fakeEvt, this.flatNodeStructure[startY + matY], (matX + startX));
            }
        }


        var maxY = this.flatNodeStructure.length - 1;
        var maxX = this.flatNodeStructure[0].cellInfo.length;

        for (var ty = startY; ty <= maxY; ty++) {
            if (this.flatNodeStructure[ty].hasChildren) {
                maxY = ty - 1;
                break;
            }
        }


        this.selectionModel.sX = startX;
        this.selectionModel.sY = startY;
        this.selectionModel.fX = (startX + copyMatrix[0].length) > maxX ? maxX - 1 : (startX + copyMatrix[0].length - 1);
        this.selectionModel.fY = (startY + copyMatrix.length) > maxY ? maxY : (startY + copyMatrix.length - 1);

    }

    public handleKeyboardEvents(event: KeyboardEvent) {
        var vm = this;


        var updateArrSelectionLocal = function () {
            if (!vm.selectionModel.arrowSelectionStarted) {

                var startElm = $(".values-table-cell-input:focus");
                vm.selectionModel.arrowSelectionStarted = true;

                var inputs = startElm.parents('tr').find(".values-table-cell-input");
                var colIndex = -1;
                for (var i = 0; i < inputs.length; i++) {
                    if ($(inputs[i]).is(":focus")) {
                        colIndex = i;
                        break;
                    }
                }


                var rowIndex = startElm.parents('tr').first().index();
                //console.log("ROW: " + rowIndex + " COL:" + colIndex);
                vm.selectionModel.startX = colIndex;
                vm.selectionModel.startY = rowIndex;
                vm.selectionModel.currentX = colIndex;
                vm.selectionModel.currentY = rowIndex;
                if (vm.isIE()) {
                    $(".values-table-cell-input:focus").trigger("blur");
                }
            }
        }

        if ($(".values-table-cell-input:focus").length > 0 || vm.selectionModel.arrowSelectionStarted) {
            if (event.shiftKey) {
                switch (event.keyCode) {
                    case 38:
                        updateArrSelectionLocal();
                        if (vm.selectionModel.currentY > 0 && vm.flatNodeStructure[vm.selectionModel.currentY - 1].hasChildren == false) {
                            vm.selectionModel.currentY--;
                        }
                        event.preventDefault();
                        break;
                    case 40:
                        updateArrSelectionLocal();
                        if (vm.selectionModel.currentY < (vm.flatNodeStructure.length - 1) && vm.flatNodeStructure[vm.selectionModel.currentY + 1].hasChildren == false) {
                            vm.selectionModel.currentY++;
                        }
                        event.preventDefault();
                        break;
                    case 37:
                        updateArrSelectionLocal();
                        if (vm.selectionModel.currentX > 0) {
                            vm.selectionModel.currentX--;
                        }
                        event.preventDefault();
                        break;
                    case 39:
                        updateArrSelectionLocal();
                        if (vm.selectionModel.currentX < (vm.flatNodeStructure[vm.selectionModel.currentY].cellInfo.length - 1)) {
                            vm.selectionModel.currentX++;
                        }

                        event.preventDefault();
                        break;
                }
                vm.updateSelectionDisplayPoints();

            } else {

                var cInput = $(".values-table-cell-input:focus");
                var inputs = cInput.parents('tr').find(".values-table-cell-input");
                var colSelIndex = -1;
                for (var i = 0; i < inputs.length; i++) {
                    if ($(inputs[i]).is(":focus")) {
                        colSelIndex = i;
                        break;
                    }
                }

                var rowSelIndex = $(".values-table-cell-input:focus").parents('tr').first().index();
                var selectionDone: boolean = false;

                switch (event.keyCode) {
                    case 38:
                        this.clearSelection();
                        selectionDone = false;
                        var ctr = 0;
                        while (!selectionDone && (rowSelIndex - ctr) > 0) {

                            if (vm.flatNodeStructure[rowSelIndex - ctr - 1].hasChildren) {
                                //try previous row
                                ctr++;
                            } else {

                                var rowPrevSiblings = cInput.parents('tr').prevAll()

                                //$($(rowPrevSiblings[ctr]).find(".values-table-cell-input")[colSelIndex]).trigger("click");
                                $($(rowPrevSiblings[ctr]).find(".values-table-cell-input")[colSelIndex]).focus();
                                $($(rowPrevSiblings[ctr]).find(".values-table-cell-input")[colSelIndex]).select();
                                this.onGranularityNodeClick(event, vm.flatNodeStructure[rowSelIndex - ctr - 1], colSelIndex, vm.flatNodeStructure[rowSelIndex - ctr - 1].cellInfo[colSelIndex].cellModel);
                                selectionDone = true;
                            }
                        }


                        event.preventDefault();
                        break;
                    case 40:
                        this.clearSelection();
                        selectionDone = false;
                        var ctr = 0;
                        while (!selectionDone && (rowSelIndex + ctr) < vm.flatNodeStructure.length - 1) {
                            if (vm.flatNodeStructure[rowSelIndex + ctr + 1].hasChildren) {
                                //try next row
                                ctr++;
                            } else {

                                var rowNextSiblings = cInput.parents('tr').nextAll()

                                //$($(rowNextSiblings[ctr]).find(".values-table-cell-input")[colSelIndex]).trigger("click");
                                $($(rowNextSiblings[ctr]).find(".values-table-cell-input")[colSelIndex]).focus();
                                $($(rowNextSiblings[ctr]).find(".values-table-cell-input")[colSelIndex]).select();
                                this.onGranularityNodeClick(event, vm.flatNodeStructure[rowSelIndex + ctr + 1], colSelIndex, vm.flatNodeStructure[rowSelIndex + ctr + 1].cellInfo[colSelIndex].cellModel);
                                selectionDone = true;
                            }
                        }

                        event.preventDefault();
                        break;

                    case 37:
                        let d = <HTMLInputElement>event.srcElement;
                        if (this.isCellDoubleClicked || d.value.indexOf("$") == -1) {
                            d.setSelectionRange(d.selectionStart, d.selectionEnd);
                        }
                        else {
                            this.clearSelection();
                            if (colSelIndex > 0) {
                                //$(cInput.parents('tr').first().find(".values-table-cell-input")[colSelIndex - 1]).trigger("click");
                                $(cInput.parents('tr').first().find(".values-table-cell-input")[colSelIndex - 1]).focus();
                                $(cInput.parents('tr').first().find(".values-table-cell-input")[colSelIndex - 1]).select();
                                this.onGranularityNodeClick(event, vm.flatNodeStructure[rowSelIndex], colSelIndex, vm.flatNodeStructure[rowSelIndex].cellInfo[colSelIndex - 1].cellModel);
                            }
                            event.preventDefault();
                        }
                        break;

                    case 39:
                        let r = <HTMLInputElement>event.srcElement;
                        if (this.isCellDoubleClicked || r.value.indexOf("$") == -1) {
                            r.setSelectionRange(r.selectionStart, r.selectionEnd);
                        }
                        else {
                            this.clearSelection();
                            if (colSelIndex < vm.flatNodeStructure[0].cellInfo.length - 1) {
                                //$(cInput.parents('tr').first().find(".values-table-cell-input")[colSelIndex + 1]).trigger("click");
                                $(cInput.parents('tr').first().find(".values-table-cell-input")[colSelIndex + 1]).focus();
                                $(cInput.parents('tr').first().find(".values-table-cell-input")[colSelIndex + 1]).select();
                                this.onGranularityNodeClick(event, vm.flatNodeStructure[rowSelIndex], colSelIndex, vm.flatNodeStructure[rowSelIndex].cellInfo[colSelIndex + 1].cellModel);
                            }
                            event.preventDefault();
                        }
                        break;
                }

            }
        }


        if (event.code == "Delete" || event.key == "Del") {
            if (this.selectionModel.fX > -1 && (this.selectionModel.sX != this.selectionModel.fX || this.selectionModel.sY != this.selectionModel.fY)) {
                for (var r = this.selectionModel.sY; r <= this.selectionModel.fY; r++) {
                    for (var c = this.selectionModel.sX; c <= this.selectionModel.fX; c++) {

                        //create faux event
                        var fakeEvt = {
                            target: {
                                value: 0
                            }
                        }
                        this.previousGranularityCellModels[`${this.flatNodeStructure[r].id}-${c}`] = null;
                        this.onGranularityCellValueChange(fakeEvt, this.flatNodeStructure[r], c);

                    }

                }
                event.preventDefault();
                return false;
            }
            vm.clearSelection();
        }

        if (event.ctrlKey && event.key == "c") {
            if (this.isIE()) {
                this.handleCopyEvent(event);
            }
        }

        if (event.ctrlKey && event.key == "v") {
            if (this.isIE()) {
                this.onValuePaste(event);
            }
        }



    }

    public handleCopyEvent(event: any) {
        event.preventDefault()
        var copyData = "";

        var useIE = this.isIE();

        //build copy matrix
        if (this.selectionModel.fX != -1) {


            for (var r = this.selectionModel.sY; r <= this.selectionModel.fY; r++) {
                var rowStr = "";
                for (var c = this.selectionModel.sX; c <= this.selectionModel.fX; c++) {
                    rowStr = rowStr + (this.flatNodeStructure[r].cellInfo[c].cellModel.value ? this.flatNodeStructure[r].cellInfo[c].cellModel.value : 0);
                    if (c != this.selectionModel.fX) {
                        rowStr = rowStr + "\t"
                    }
                }
                if (r != this.selectionModel.fY) {

                    if (useIE) {
                        rowStr = rowStr + "\r\n";
                    } else {
                        rowStr = rowStr + "\n";
                    }


                }

                copyData = copyData + rowStr;
            }



        }

        if (this.isIE()) {
            (<any>window).clipboardData.setData("Text", copyData);
        } else {
            event.clipboardData.setData('text/plain', copyData);
        }


        this.clearSelection();
        return false;
    }

    private clearSelection(): void {
        this.selectionModel = {
            dragSelectionStarted: false,
            arrowSelectionStarted: false,
            startX: -1,
            startY: -1,
            currentX: -1,
            currentY: -1,
            sX: -1,
            sY: -1,
            fX: -1,
            fY: -1
        }
    }

    private updateSelectionDisplayPoints(): void {

        if (this.selectionModel.currentX < this.selectionModel.startX) {
            this.selectionModel.sX = this.selectionModel.currentX
            this.selectionModel.fX = this.selectionModel.startX;
        } else {
            this.selectionModel.sX = this.selectionModel.startX;
            this.selectionModel.fX = this.selectionModel.currentX;
        }


        if (this.selectionModel.currentY < this.selectionModel.startY) {
            this.selectionModel.sY = this.selectionModel.currentY
            this.selectionModel.fY = this.selectionModel.startY;
        } else {
            this.selectionModel.sY = this.selectionModel.startY;
            this.selectionModel.fY = this.selectionModel.currentY;
        }
    }

    public onSelectionStart(event: MouseEvent, node: FlatFinancialGridRowModel, rowIndex: number, colIndex: number) {
        if (!node.hasChildren) {
            this.selectionModel.dragSelectionStarted = true;
            this.selectionModel.startX = colIndex;
            this.selectionModel.startY = rowIndex;
            this.selectionModel.currentX = colIndex;
            this.selectionModel.currentY = rowIndex;
            this.selectionModel.sX = colIndex;
            this.selectionModel.sY = rowIndex;
            this.selectionModel.fX = colIndex;
            this.selectionModel.fY = rowIndex;

            if (this.isIE()) {
                $(event.srcElement).focus();
            }

            return false;
            //console.log("Selection start");
        }

        //event.preventDefault();

    }

    public onSelection(event: MouseEvent, node: FlatFinancialGridRowModel, rowIndex: number, colIndex: number) {
        if (this.selectionModel.dragSelectionStarted) {


            //prevent selecting over nodes with children, distance to next leaf node shouldn;t be greater than one
            if (!node.hasChildren && ((Math.abs(this.selectionModel.currentX - colIndex) + Math.abs(this.selectionModel.currentY - rowIndex)) == 1)) {
                this.selectionModel.currentX = colIndex;
                this.selectionModel.currentY = rowIndex;
                if (this.isIE()) {
                    $(".values-table-cell-input:focus").trigger("blur");
                }
                this.updateSelectionDisplayPoints();

            }


            // console.log(`"Selected:R:${rowIndex}, C:${colIndex}`);
        }
    }

    public onSelectionEnd(event: MouseEvent, node: FlatFinancialGridRowModel, rowIndex: number, colIndex: number) {
        this.selectionModel.dragSelectionStarted = false;
        //console.log("Selection end");
    }

    //END COPY PASTE AND NAV

    //TIMELINE CHANGE DIALOG EVENTS

    private showTimelineUpdateComponent(showCancel: boolean): void {
        this.showTimelineUpdateCancelBtn = showCancel;
        this.timelineUpdateComponent.initControls(this.timescalePropertyModel.selectedStartDate, this.timescalePropertyModel.selectedEndDate, this.timescalePropertyModel.startDate, this.timescalePropertyModel.endDate);
        this.showGrid = false;
        this.showTimelineUpdate = true;
        this.saveValuesOnTimelineUpdate = false;
    }

    public updateTimeline(evtData: { operation: string, save: boolean }) {

        this.resetMessage();
        this.applyTimelineChanges(evtData.operation, this.timescalePropertyModel, evtData.save);
    }

    //END TIMELINE CHANGE DIALOG EVENTS

    //UTILITY 
    private showMessage(texts: Array<string>, messageType: string): void {
        var vm = this;

        vm.messageRow.messageTexts = texts;
        vm.messageRow.messageType = messageType;

        if (messageType === AppSettings.getDefault()) {
            vm.messageRow.messageClass = "no-msg";
            return;
        }

        if (messageType === AppSettings.getSuccessMessage()) {
            vm.messageRow.messageClass = "alert alert-success";
            return;
        }

        if (messageType === AppSettings.getInfoMessage()) {
            vm.messageRow.messageClass = "alert alert-info";
            return;
        }

        if (messageType === AppSettings.getErrorMessage()) {
            vm.messageRow.messageClass = "alert alert-danger";
            return;
        }

        if (messageType === AppSettings.getCriticalErrorMessage()) {
            vm.messageRow.messageClass = "alert alert-danger";
            return;
        }
    }

    private resetMessage(): void {
        var vm = this;
        vm.messageRow.messageTexts = new Array<string>();
        vm.messageRow.messageClass = "no-msg";
        vm.messageRow.messageType = AppSettings.getDefault();
    }

    private isGridEmpty(): boolean {
        var result: boolean = true;
        if (this.flatNodeStructure && this.flatNodeStructure.length > 0) {
            for (var i = 0; i < this.flatNodeStructure.length; i++) {
                for (var j = 0; j < this.flatNodeStructure[i].cellInfo.length; j++) {
                    if (this.flatNodeStructure[i].cellInfo[j].cellModel.value != 0) {
                        return false;
                    }
                }
            }
        }

        return result;
    }

    // This function is used to parse the data that is received from the "editFormFinancialsHelper" helper.
    private getWordsBetweenCurlies(str: string) {
        var results = [], re = /{([^}]+)}/g, text;

        while (text = re.exec(str)) {
            results.push(text[1]);
        }
        return results;
    }

    // Create hidden div (outer) with width set to '100px' and get offset width (should be 100)
    // Force scroll bars to appear in div (outer) using CSS overflow property
    // Create new div (inner) and append to outer, set its width to '100%' and get offset width
    // Calculate scrollbar width based on gathered offsets
    private getScrollbarWidth() {
        var outer = document.createElement("div");
        outer.style.visibility = "hidden";
        outer.style.width = "100px";
        //outer.style.msOverflowStyle = "scrollbar"; // needed for WinJS apps

        document.body.appendChild(outer);

        var widthNoScroll = outer.offsetWidth;
        // force scrollbars
        outer.style.overflow = "scroll";

        // add innerdiv
        var inner = document.createElement("div");
        inner.style.width = "100%";
        outer.appendChild(inner);

        var widthWithScroll = inner.offsetWidth;

        // remove divs
        outer.parentNode.removeChild(outer);

        return widthNoScroll - widthWithScroll;
    }

    private setCookie(name: string, value: string, days: number) {
        var expires = "";
        if (days) {
            var date = new Date();
            date.setTime(date.getTime() + (days * 24 * 60 * 60 * 1000));
            expires = "; expires=" + date.toUTCString();
        }
        document.cookie = name + "=" + (value || "") + expires + "; path=/";
    }

    private getCookie(name: string): string {
        var nameEQ = name + "=";
        var ca = document.cookie.split(';');
        for (var i = 0; i < ca.length; i++) {
            var c = ca[i];
            while (c.charAt(0) == ' ') c = c.substring(1, c.length);
            if (c.indexOf(nameEQ) == 0) return c.substring(nameEQ.length, c.length);
        }
        return null;
    }


    //ENDD Utility

    //PARENT PAGE UTILS

    private postValuesChanged() {

        if (this.isCheckedOutToCurrentUser) {
            window.parent.postMessage("FinancialValuesChangeEvent", '*');
        }
    }

    // This function is used to register the save event and also to handle it.
    private registerProjectSaveEvent(hostwebURL: string) {
        var vm = this;
        window.addEventListener("message",
            (event) => {
                if (event.data.indexOf("onProjectSaveEvent") != -1) {
                    var dataArr = event.data.split('#');

                    if (dataArr.length != 2) {
                        return;
                    }

                    var saveId = dataArr[1];

                    vm.handleRibbonSaveClick(event).subscribe(
                        (data) => {
                            window.parent.postMessage('onProjectSaveFinishedEvent#' + saveId, hostwebURL);
                        }, (err) => {
                        });
                }

                if (event.data.indexOf("onProjectPostSaveEvent") != -1) {

                    var handlePostSave = function () {

                        if (vm.refreshOnPostSave) {
                            window.location.reload();
                        } else {
                            if (vm.checkDatesOnPostSave) {
                                vm.buildTimescalePropertyModel().then(tsMod => {



                                    if (tsMod == null || !vm.momentReference(vm.timescalePropertyModel.startDate).isSame(tsMod.startDate, "day")
                                        || !vm.momentReference(vm.timescalePropertyModel.endDate).isSame(tsMod.endDate, "day")
                                    ) {

                                        var hostwebURL = decodeURIComponent(Utils.getQueryStringParameter("SPHostUrl"));
                                        vm.initGrid(hostwebURL);
                                    }
                                });
                            }

                        }


                    }

                    if (vm.saveGridPromise == null) {
                        handlePostSave();
                    } else {
                        vm.saveGridPromise.then(() => {
                            handlePostSave();
                        });
                    }


                }

            }, false);
    }

    // this function is used to get the ID related properties (entityUID and list ID)
    private loadEntityUid(hostwebURL: string): Promise<any> {
        var vm = this;
        var promise = new Promise(function (resolve, reject) {
            window.addEventListener("message",
                (event) => {
                    var length = event.data.length;
                    // This means the grid is deployed on a project.
                    if (length == 67) {
                        vm.financialGridMetaDataModel.entityUID = event.data.replace("<PDPProjectUid>", "").replace("</PDPProjectUid>", "");
                        vm.financialGridMetaDataModel.listItemId = -1;
                        if (!vm.financialGridMetaDataModel.entityUID) {
                            reject("No entity id was found. Please refresh the page and try again later.");
                        }
                        else if (vm.financialGridMetaDataModel.entityUID == AppSettings.getEmptyGuid()) {
                            reject("No entity id was found. Please refresh the page and try again later.");
                        }
                        else {
                            resolve();
                        }

                    } else if (event.data.indexOf("ListInfo") != -1) {
                        var results = vm.getWordsBetweenCurlies(event.data);

                        if (!results) {
                            reject("Incorrect post message response. No list information was found.");
                        }

                        if (results.length != 2) {
                            reject("Incorrect post message response. No list information was found.");
                        } else {
                            vm.financialGridMetaDataModel.entityUID = new SP.Guid(results[0]);
                            var isCorrect = true;

                            if (!vm.financialGridMetaDataModel.entityUID) {
                                isCorrect = false;
                                reject("Incorrect post message response. No list id was found.");
                            }

                            vm.financialGridMetaDataModel.listItemId = parseInt(results[1]);

                            if (!vm.financialGridMetaDataModel.listItemId) {
                                isCorrect = false;
                                reject("Incorrect post message response. No list item id was found.");
                            }
                            if (isCorrect) {
                                resolve();
                            }
                        }
                    }
                    else {
                        reject("Incorrect post message response. No entity id was found.");
                    }
                }, false);
        });

        window.parent.postMessage('getprojectuid', hostwebURL);
        window.parent.postMessage('getListInfo', hostwebURL);

        return promise;
    }

    public isIE(): any {
        var ua = window.navigator.userAgent;

        // Test values; Uncomment to check result …

        // IE 10
        // ua = 'Mozilla/5.0 (compatible; MSIE 10.0; Windows NT 6.2; Trident/6.0)';

        // IE 11
        // ua = 'Mozilla/5.0 (Windows NT 6.3; Trident/7.0; rv:11.0) like Gecko';

        // IE 12 / Spartan
        // ua = 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/39.0.2171.71 Safari/537.36 Edge/12.0';

        // Edge (IE 12+)
        // ua = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/46.0.2486.0 Safari/537.36 Edge/13.10586';

        var msie = ua.indexOf('MSIE ');
        if (msie > 0) {
            // IE 10 or older => return version number
            return parseInt(ua.substring(msie + 5, ua.indexOf('.', msie)), 10);
        }

        var trident = ua.indexOf('Trident/');
        if (trident > 0) {
            // IE 11 => return version number
            var rv = ua.indexOf('rv:');
            return parseInt(ua.substring(rv + 3, ua.indexOf('.', rv)), 10);
        }

        var edge = ua.indexOf('Edge/');
        if (edge > 0) {
            // Edge (IE 12+) => return version number
            return parseInt(ua.substring(edge + 5, ua.indexOf('.', edge)), 10);
        }

        // other browser
        return false;
    }


    //END PARENT PAGE UTILS

}