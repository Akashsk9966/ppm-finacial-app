﻿import { NgModule, forwardRef } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule } from '@angular/forms';
import { FinancialSharedModule } from '../shared/financial-shared.module';
import { CalendarModule } from 'primeng/primeng';
import { ConfirmDialogModule, ConfirmationService } from 'primeng/primeng';

import { FinancialValuesComponent } from './financial-values.component';
import { ProjectFinancialValuesComponent } from './projectfinancial-values.component';
import { FinancialTimescaleUpdateComponent } from './financial-timescale-update.component';
import { ButtonModule, TreeModule, TreeTableModule, DataTableModule, ProgressBarModule, OverlayPanelModule, DialogModule, SharedModule, AccordionModule } from 'primeng/primeng';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';

@NgModule({
    imports: [FormsModule, BrowserModule, FinancialSharedModule, CalendarModule, ButtonModule, TreeModule, TreeTableModule, DataTableModule, ProgressBarModule, OverlayPanelModule, DialogModule, ConfirmDialogModule, DialogModule, SharedModule, AccordionModule, BrowserAnimationsModule],
    declarations: [FinancialValuesComponent, ProjectFinancialValuesComponent, FinancialTimescaleUpdateComponent],
    exports: [FinancialValuesComponent, ProjectFinancialValuesComponent, FinancialTimescaleUpdateComponent],
    entryComponents: [FinancialValuesComponent, ProjectFinancialValuesComponent, FinancialTimescaleUpdateComponent],
    providers: [ConfirmationService]
})

export class FinancialValuesModule {
}
