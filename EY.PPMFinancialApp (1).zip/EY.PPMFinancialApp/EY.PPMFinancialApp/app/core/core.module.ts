﻿import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HttpModule } from '@angular/http';
import { Location, LocationStrategy, PathLocationStrategy, APP_BASE_HREF } from '@angular/common';

import { SharePointService } from './sharepoint.service'
import { FinancialValueService } from './financial-value.service'

@NgModule({
    imports: [CommonModule, HttpModule],
    providers: [SharePointService, FinancialValueService, Location, { provide: LocationStrategy, useClass: PathLocationStrategy }, { provide: APP_BASE_HREF, useValue: '/' }]
})
export class CoreModule {
}