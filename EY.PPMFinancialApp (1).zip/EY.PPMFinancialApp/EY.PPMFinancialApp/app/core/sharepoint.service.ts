﻿/// <reference path="../../typings/microsoft-ajax/microsoft.ajax.d.ts" />
/// <reference path="../../typings/sharepoint/sharepoint.d.ts" />
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/observable/fromPromise';
import { Http, Headers } from '@angular/http';
import { AppSettings } from '../shared/app-settings';
import { Utils } from '../shared/utils';
import { FinancialTemplate } from '../shared/model/financial-template.model';
import { FinancialValue } from '../shared/model/financial-value.model';
import { FinancialUpdateTrackerModel } from '../shared/model/financial-update-tracker.model';
import { CalculationTotals } from '../shared/model/calculation-totals-model';

@Injectable()
export class SharePointService {

    projectContext: any;
    clientContext: SP.ClientContext;
    hostContext: SP.AppContextSite;
    hostWebUrl: string;
    appWebUrl: string;
    web: SP.Web;

    templateListFields = [
        {
            FieldTitle: "EntityName",
            FieldType: "Text",
            Required: false,
            ShouldAddField: true,
            isIndexed: false
        },
        {
            FieldTitle: "EntityUID",
            FieldType: "Text",
            Required: false,
            ShouldAddField: true,
            isIndexed: true
        },
        {
            FieldTitle: "ListItemId",
            FieldType: "Number",
            Required: false,
            ShouldAddField: true,
            isIndexed: true
        },
        {
            FieldTitle: "FinancialStartDate",
            FieldType: "DateTime",
            Required: false,
            ShouldAddField: true,
            isIndexed: false
        },
        {
            FieldTitle: "FinancialEndDate",
            FieldType: "DateTime",
            Required: false,
            ShouldAddField: true,
            isIndexed: false
        },
        {
            FieldTitle: "Granularity",
            FieldType: "Text",
            Required: false,
            ShouldAddField: true,
            isIndexed: false
        },
        {
            FieldTitle: "FinancialValuesStructure",
            FieldType: "Note",
            Required: false,
            ShouldAddField: true,
            isIndexed: false
        },
        {
            FieldTitle: "UpdateStatus",
            FieldType: "Text",
            Required: false,
            ShouldAddField: true,
            isIndexed: false
        },
        {
            FieldTitle: "UpdateStartDate",
            FieldType: "DateTime",
            Required: false,
            ShouldAddField: true,
            isIndexed: false
        },
        {
            FieldTitle: "UpdateEndDate",
            FieldType: "DateTime",
            Required: false,
            ShouldAddField: true,
            isIndexed: false
        }
    ]

    constructor(private http: Http) {
        var vm = this;
        vm.clientContext = SP.ClientContext.get_current();
        this.hostWebUrl = decodeURIComponent(Utils.getQueryStringParameter("SPHostUrl"));
        this.appWebUrl = decodeURIComponent(Utils.getQueryStringParameter("SPAppWebUrl"));
        vm.hostContext = new SP.AppContextSite(vm.clientContext, this.hostWebUrl);
        vm.web = vm.hostContext.get_web();
    }

    public gerCurrentUser(): Observable<any> {
        var vm = this;
        var promise = new Promise(
            function (resolve, reject) {
                var user = vm.clientContext.get_web().get_currentUser();
                vm.clientContext.load(user);
                vm.clientContext.executeQueryAsync(
                    function (sender, args) {
                        resolve(user);
                    }, function (sender, args) {
                        reject();
                    });
            });

        return Observable.fromPromise(promise);
    }

    public getCheckedOutBy(projectUID: SP.Guid): Observable<any> {
        var vm = this;
        var promise = new Promise(
            function (resolve, reject) {
                var executor = new SP.RequestExecutor(vm.appWebUrl);
                var odataUrl = `${vm.appWebUrl}/_api/ProjectServer/Projects(guid'${projectUID}')/CheckedOutBy?@target=${vm.hostWebUrl}`;
                executor.executeAsync({
                    url: odataUrl,
                    method: "GET",
                    headers: { "Accept": "application/json; odata=verbose" },
                    success: function (data: any) {
                        if (!data) {
                            resolve(null);
                        } else {
                            var queryResult = JSON.parse(data.body);
                            resolve(queryResult.d);
                        }
                    },
                    error: function (data, errorCode, errorMessage) {
                        reject(errorMessage)
                    }
                });
            });
        return Observable.fromPromise(promise);
    }

    public getCustomFieldDataByGuid(projectUID: SP.Guid, customFieldGuid: SP.Guid): Observable<any> {
        var vm = this;
        var promise = new Promise(
            function (resolve, reject) {
                var executor = new SP.RequestExecutor(vm.appWebUrl);
                var guidAsString = customFieldGuid.toString().split("-").join("");
                var customName = `Custom_${guidAsString}`;
                var odataUrl = `${vm.appWebUrl}/_api/ProjectServer/Projects(guid'${projectUID}')/IncludeCustomFields?$select=${customName}`;
                executor.executeAsync({
                    url: odataUrl,
                    headers: { "Accept": "application/json; odata=verbose" },
                    method: "GET",
                    success: function (data: any) {
                        if (!data) {
                            resolve(null);
                        } else {

                            var queryResult = JSON.parse(data.body);
                            if (!queryResult) {
                                resolve(null);
                            } else {

                                var result = { "customFieldGuid": customFieldGuid, "value": "" };;

                                for (var key in queryResult.d) {
                                    if (key.indexOf(guidAsString) != -1) {
                                        result = { "customFieldGuid": customFieldGuid, "value": queryResult.d[key] };
                                        break;
                                    }
                                }
                                resolve(result);
                            }
                        }
                    },
                    error: function (data, errorCode, errorMessage) {
                        reject(errorMessage)
                    }
                });
            });
        return Observable.fromPromise(promise);
    }

    public getCostCustomFieldList(): Observable<{ name: string, id: string }[]> {
        var vm = this;
        var promise = new Promise<{ name: string, id: string }[]>(
            function (resolve, reject) {
                var executor = new SP.RequestExecutor(vm.appWebUrl);
                var odataUrl = `${vm.appWebUrl}/_api/ProjectServer/CustomFields?@target=${vm.hostWebUrl}`;
                executor.executeAsync({
                    url: odataUrl,
                    headers: { "Accept": "application/json; odata=verbose" },
                    method: "GET",
                    success: function (data: any) {
                        if (!data) {
                            resolve(null);
                        } else {

                            var queryResult = JSON.parse(data.body);
                            if (!queryResult) {
                                resolve(null);
                            } else {

                                var rawCfdata = queryResult.d;
                                var cfList = [];
                                for (var i = 0; i < rawCfdata.results.length; i++) {
                                    if (rawCfdata.results[i].FieldType == 9) {
                                        cfList.push({
                                            name: rawCfdata.results[i].Name,
                                            id: rawCfdata.results[i].Id
                                        });
                                    }

                                }

                                resolve(cfList);
                            }
                        }
                    },
                    error: function (data, errorCode, errorMessage) {
                        reject(errorMessage)
                    }
                });
            });
        return Observable.fromPromise<{ name: string, id: string }[]>(promise);
    }

    public getProjectName(projectUID: SP.Guid): Observable<any> {
        var vm = this;
        var promise = new Promise(
            function (resolve, reject) {
                var executor = new SP.RequestExecutor(vm.appWebUrl);
                var odataUrl = `${vm.appWebUrl}/_api/ProjectServer/Projects(guid'${projectUID}')/Name?@target=${vm.hostWebUrl}`;
                executor.executeAsync({
                    url: odataUrl,
                    method: "GET",
                    headers: { "Accept": "application/json; odata=verbose" },
                    success: function (data: any) {
                        if (!data) {
                            resolve(null);
                        } else {
                            var queryResult = JSON.parse(data.body);
                            resolve(queryResult.d);
                        }
                    },
                    error: function (data, errorCode, errorMessage) {
                        reject(errorMessage)
                    }
                });
            });
        return Observable.fromPromise(promise);
    }
    public getProjectID(projectUID: SP.Guid): Observable<any> {
        var vm = this;
        var promise = new Promise(
            function (resolve, reject) {
                var executor = new SP.RequestExecutor(vm.appWebUrl);
                var odataUrl = `${vm.appWebUrl}/_api/projectdata/Projects(guid'${projectUID}')?$select=Identifier`;
                executor.executeAsync({
                    url: odataUrl,
                    method: "GET",
                    headers: { "Accept": "application/json; odata=verbose" },
                    success: function (data: any) {
                        if (!data) {
                            resolve(null);
                        } else {
                            var queryResult = JSON.parse(data.body);
                            resolve(queryResult.d);
                        }
                    },
                    error: function (data, errorCode, errorMessage) {
                        reject(errorMessage)
                    }
                });
            });
        return Observable.fromPromise(promise);
    }


    public getListNameById(entityUID: SP.Guid): Observable<any> {
        var vm = this;
        var promise = new Promise<any>(
            function (resolve, reject) {
                var list = vm.web.get_lists().getById(entityUID);
                vm.clientContext.load(list, 'Title');
                vm.clientContext.executeQueryAsync(
                    function (sender, args) {
                        var listName = list.get_title();
                        resolve({ "entityName": listName });
                    },
                    function (sender, args) {
                        reject('Failed: ' + args.get_message());
                    });

            });
        return Observable.fromPromise(promise);
    }

    public getAllTemplates(): Observable<any> {
        var vm = this;
        var promise = new Promise<any>(function (resolve, reject) {
            var financialTemplateList = vm.web.get_lists().getByTitle(AppSettings.getPPMFinancialTemplateListName());
            var query = new SP.CamlQuery();
            query.set_viewXml(`<View><Query></Query></View>`);

            var includeColumns = "Include(Id, Name, Structure, FinancialStartDate, FinancialEndDate, Granularity, StartMonth, FinancialTemplateListUID)";
            var queryResults = financialTemplateList.getItems(query);
            vm.clientContext.load(queryResults, includeColumns);
            vm.clientContext.executeQueryAsync(
                function (sender, args) {
                    var listItemEnumerator = queryResults.getEnumerator();
                    var allTemplates = new Array<FinancialTemplate>();
                    var allListItems = new Array<any>();
                    while (listItemEnumerator.moveNext()) {
                        var listItem = listItemEnumerator.get_current();
                        allListItems.push(listItem);
                        var financialTemplate = new FinancialTemplate();
                        var financialTemplateListUID = listItem.get_item(AppSettings.getPPMFinancialTemplateListUIDColumn());

                        if (!financialTemplateListUID) {
                            financialTemplate.financialTemplateListUID = SP.Guid.get_empty()
                        } else {
                            financialTemplate.financialTemplateListUID = new SP.Guid(listItem.get_item(AppSettings.getPPMFinancialTemplateListUIDColumn()));
                        }

                        financialTemplate.name = listItem.get_item(AppSettings.getPPMFinancialTemplateNameColumn());
                        financialTemplate.structure = listItem.get_item(AppSettings.getFinancialStructureColumn());
                        financialTemplate.financialStartDate = new Date(listItem.get_item(AppSettings.getFinancialStartDateColumn()));
                        financialTemplate.financialEndDate = new Date(listItem.get_item(AppSettings.getFinancialEndDateColumn()));
                        financialTemplate.granularity = listItem.get_item(AppSettings.getGranularityColumn());
                        var startMonthAsNumber = listItem.get_item(AppSettings.getGranularityStartMonthColumn());

                        if (startMonthAsNumber) {
                            financialTemplate.granularityStartMonthAsNumber = parseInt(startMonthAsNumber);
                        } else {
                            financialTemplate.granularityStartMonthAsNumber = Utils.getDefaultTimescaleStartMonthAsNumber();
                        }

                        financialTemplate.granularityStartMonth = Utils.getMomentReference().months()[financialTemplate.granularityStartMonthAsNumber];

                        allTemplates.push(financialTemplate);
                    }

                    resolve({ "allTemplates": allTemplates, "allListItems": allListItems });
                },
                function (sender, args) {
                    reject('Failed: ' + args.get_message());
                });
        });

        return Observable.fromPromise(promise);
    }

    public getAllFinancialValuesByListUID(listUID: SP.Guid): Observable<any> {
        var vm = this;
        var promise = new Promise<any>(function (resolve, reject) {
            var financialValueList = vm.web.get_lists().getById(listUID);
            var query = new SP.CamlQuery();
            query.set_viewXml(`<View><Query></Query></View>`);

            var includeColumns = "Include(Id, EntityUID, EntityName, ListItemId, FinancialStartDate, FinancialEndDate, FinancialValuesStructure, Granularity, UpdateStatus, UpdateStartDate, UpdateEndDate)";
            var queryResults = financialValueList.getItems(query);
            vm.clientContext.load(financialValueList, 'Id');
            vm.clientContext.load(queryResults, includeColumns);
            vm.clientContext.executeQueryAsync(
                function (sender, args) {
                    var listItemEnumerator = queryResults.getEnumerator();
                    var allFinancialValues = new Array<FinancialValue>();
                    var allFinancialValuesListItems = new Array<SP.ListItem>();

                    while (listItemEnumerator.moveNext()) {
                        var listItem = listItemEnumerator.get_current();
                        allFinancialValuesListItems.push(listItem);

                        var financialValue = new FinancialValue();

                        financialValue.id = listItem.get_id();
                        financialValue.entityUid = listItem.get_item(AppSettings.getFinancialValueEntityUIDColumn());
                        financialValue.entityName = listItem.get_item(AppSettings.getFinancialValueEntityNameColumn());
                        financialValue.listUID = financialValueList.get_id();
                        financialValue.listItemId = listItem.get_item(AppSettings.getFinancialValueListItemIdColumn());
                        financialValue.financialValuesJson = listItem.get_item(AppSettings.getFinancialValueStructureColumn());
                        financialValue.financialStartDate = new Date(listItem.get_item(AppSettings.getFinancialStartDateColumn()));
                        financialValue.financialEndDate = new Date(listItem.get_item(AppSettings.getFinancialEndDateColumn()));
                        financialValue.granularity = listItem.get_item(AppSettings.getGranularityColumn());
                        financialValue.updateStatus = listItem.get_item(AppSettings.getFinancialValueUpdateStatusColumn());

                        allFinancialValues.push(financialValue);
                    }

                    resolve({ "allFinancialValues": allFinancialValues, "allFinancialValuesListItems": allFinancialValuesListItems });
                },
                function (sender, args) {
                    reject('Failed: ' + args.get_message());
                });
        });

        return Observable.fromPromise(promise);
    }

    public getAllFinancialValuesByListName(listTitle: string): Observable<any> {
        var vm = this;
        var promise = new Promise<any>(function (resolve, reject) {
            var financialValueList = vm.web.get_lists().getByTitle(listTitle);
            var query = new SP.CamlQuery();
            query.set_viewXml(`<View><Query></Query></View>`);

            var includeColumns = "Include(Id, EntityUID, EntityName, ListItemId, FinancialStartDate, FinancialEndDate, FinancialValuesStructure, Granularity, UpdateStatus, UpdateStartDate, UpdateEndDate)";
            var queryResults = financialValueList.getItems(query);
            vm.clientContext.load(financialValueList, 'Id');
            vm.clientContext.load(queryResults, includeColumns);
            vm.clientContext.executeQueryAsync(
                function (sender, args) {
                    var listItemEnumerator = queryResults.getEnumerator();
                    var allFinancialValues = new Array<FinancialValue>();
                    var allFinancialValuesListItems = new Array<SP.ListItem>();

                    while (listItemEnumerator.moveNext()) {
                        var listItem = listItemEnumerator.get_current();
                        allFinancialValuesListItems.push(listItem);

                        var financialValue = new FinancialValue();

                        financialValue.id = listItem.get_id();
                        financialValue.entityUid = listItem.get_item(AppSettings.getFinancialValueEntityUIDColumn());
                        financialValue.entityName = listItem.get_item(AppSettings.getFinancialValueEntityNameColumn());
                        financialValue.listUID = financialValueList.get_id();
                        financialValue.listItemId = listItem.get_item(AppSettings.getFinancialValueListItemIdColumn());
                        financialValue.financialValuesJson = listItem.get_item(AppSettings.getFinancialValueStructureColumn());
                        financialValue.financialStartDate = new Date(listItem.get_item(AppSettings.getFinancialStartDateColumn()));
                        financialValue.financialEndDate = new Date(listItem.get_item(AppSettings.getFinancialEndDateColumn()));
                        financialValue.granularity = listItem.get_item(AppSettings.getGranularityColumn());
                        financialValue.updateStatus = listItem.get_item(AppSettings.getFinancialValueUpdateStatusColumn());

                        allFinancialValues.push(financialValue);
                    }

                    resolve({ "allFinancialValues": allFinancialValues, "allFinancialValuesListItems": allFinancialValuesListItems });
                },
                function (sender, args) {
                    reject('Failed: ' + args.get_message());
                });
        });

        return Observable.fromPromise(promise);
    }

    public getAllNotSuccessfullUpdateTrackerData(): Observable<any> {
        var vm = this;
        var promise = new Promise<any>(function (resolve, reject) {
            var financialUpdateTrackerList = vm.web.get_lists().getByTitle(AppSettings.getPPMFinancialUpdateTrackerListName());
            var query = new SP.CamlQuery();
            query.set_viewXml(`<View><Query>
                                    <Where>
                                        <Or>
                                            <Eq>
                                                <FieldRef Name='UpdateStatus' />
                                                <Value Type='Text'>${AppSettings.getUpdateFailed()}</Value>
                                            </Eq>
                                            <Eq>
                                                <FieldRef Name='UpdateStatus' />
                                                <Value Type='Text'>${AppSettings.getUpdateInProgress()}</Value>
                                            </Eq>
                                        </Or>
                                   </Where></Query></View>`);
            var includeColumns = "Include(Id, EntityUID, EntityName, FinancialValueListUID, ListItemId, UpdateStatus, FinancialTemplateName, EntityName)";
            var queryResults = financialUpdateTrackerList.getItems(query);
            vm.clientContext.load(queryResults, includeColumns);
            vm.clientContext.executeQueryAsync(
                function (sender, args) {
                    var listItemEnumerator = queryResults.getEnumerator();
                    var allFailedUpdateData = new Array<FinancialUpdateTrackerModel>();
                    var allFailedUpdateListItems = new Array<any>();

                    while (listItemEnumerator.moveNext()) {
                        var listItem = listItemEnumerator.get_current();
                        var financialUpdateTracker = new FinancialUpdateTrackerModel();
                        financialUpdateTracker.entityUID = listItem.get_item(AppSettings.getFinancialValueEntityUIDColumn());
                        financialUpdateTracker.entityName = listItem.get_item(AppSettings.getPPMFinancialUpdateTrackerEntityNameColumn());

                        financialUpdateTracker.financialValueListUID = listItem.get_item(AppSettings.getPPMFinancialUpdateTrackerFinancialValueListUIDColumn());
                        financialUpdateTracker.listItemId = listItem.get_item(AppSettings.getFinancialValueListItemIdColumn());
                        financialUpdateTracker.updateStatus = listItem.get_item(AppSettings.getFinancialValueUpdateStatusColumn());
                        financialUpdateTracker.financialTemplateName = listItem.get_item(AppSettings.getPPMFinancialUpdateTrackerTemplateNameColumn());

                        allFailedUpdateData.push(financialUpdateTracker);
                        allFailedUpdateListItems.push(listItem);
                    }
                    resolve({ "allUpdateTrackerData": allFailedUpdateData, "allUpdateTrackerListItems": allFailedUpdateListItems });
                },
                function (sender, args) {
                    reject('Failed: ' + args.get_message());
                });
        });

        return Observable.fromPromise(promise);
    }

    public updateFinancialValue(financialValue: FinancialValue, financialValueListItem: SP.ListItem, shouldUpdateStructure: boolean): Observable<FinancialValue> {
        var vm = this;
        var promise = new Promise<FinancialValue>(function (resolve, reject) {

            if (shouldUpdateStructure) {
                financialValueListItem.set_item(AppSettings.getFinancialValueStructureColumn(), financialValue.financialValuesJson);
            }
            financialValueListItem.set_item(AppSettings.getFinancialValueUpdateStatusColumn(), financialValue.updateStatus);
            financialValueListItem.set_item(AppSettings.getFinancialValueUpdateStartDateColumn(), financialValue.updateStartDate);
            financialValueListItem.set_item(AppSettings.getFinancialValueUpdateEndDateColumn(), financialValue.updateEndDate);

            financialValueListItem.update();
            vm.clientContext.load(financialValueListItem);

            vm.clientContext.executeQueryAsync(
                function (sender, args) {
                    resolve(financialValue);
                },
                function (sender, args) {
                    reject('Failed: ' + args.get_message());
                });

        });

        return Observable.fromPromise(promise);
    }

    public createUpdateTrackerEntry(financialTemplateName: string, financialValue: FinancialValue): Observable<any> {
        var vm = this;

        var promise = new Promise(function (resolve, reject) {
            var financialUpdateTrackerList = vm.web.get_lists().getByTitle(AppSettings.getPPMFinancialUpdateTrackerListName());
            var itemCreateInfo = new SP.ListItemCreationInformation();
            var listItem = financialUpdateTrackerList.addItem(itemCreateInfo);

            listItem.set_item(AppSettings.getFinancialValueEntityUIDColumn(), financialValue.entityUid);
            listItem.set_item(AppSettings.getPPMFinancialUpdateTrackerEntityNameColumn(), financialValue.entityName);
            listItem.set_item(AppSettings.getPPMFinancialUpdateTrackerFinancialValueListUIDColumn(), financialValue.listUID);
            listItem.set_item(AppSettings.getFinancialValueListItemIdColumn(), financialValue.listItemId);
            listItem.set_item(AppSettings.getFinancialValueUpdateStatusColumn(), financialValue.updateStatus);
            listItem.set_item(AppSettings.getPPMFinancialUpdateTrackerTemplateNameColumn(), financialTemplateName);

            listItem.update();
            vm.clientContext.load(listItem);

            vm.clientContext.executeQueryAsync(
                function (sender, args) {
                    resolve("Finished successfully.");
                },
                function (sender, args) {
                    reject('Failed: ' + args.get_message());
                });
        });

        return Observable.fromPromise(promise);
    }

    public updateTrackerEnryStatus(updateItem: SP.ListItem, status: string): Observable<any> {
        var vm = this;

        var promise = new Promise(function (resolve, reject) {
            updateItem.set_item(AppSettings.getFinancialValueUpdateStatusColumn(), status);
            updateItem.update();
            vm.clientContext.load(updateItem);

            vm.clientContext.executeQueryAsync(
                function (sender, args) {
                    resolve("Finished successfully.");
                },
                function (sender, args) {
                    reject('Failed: ' + args.get_message());
                });
        });

        return Observable.fromPromise(promise);
    }

    public getFinancialTemplateByName(financialTemplateName: string): Observable<FinancialTemplate> {
        var vm = this;

        var promise = new Promise<FinancialTemplate>(function (resolve, reject) {
            var financialTemplateList = vm.web.get_lists().getByTitle(AppSettings.getPPMFinancialTemplateListName());
            var query = new SP.CamlQuery();
            query.set_viewXml(`<View><Query>
                                    <Where>
                                        <Eq>
                                            <FieldRef Name='Name' />
                                            <Value Type='Text'>${financialTemplateName}</Value>
                                        </Eq>
                                   </Where></Query></View>`);

            var includeColumns = "Include(Id, Name, Structure, FinancialStartDate, FinancialEndDate, Granularity, StartMonth, FinancialTemplateListUID)";
            var queryResults = financialTemplateList.getItems(query);
            vm.clientContext.load(queryResults, includeColumns);

            vm.clientContext.executeQueryAsync(
                function (sender, args) {
                    var listItemEnumerator = queryResults.getEnumerator();

                    if (listItemEnumerator.moveNext()) {
                        var listItem = listItemEnumerator.get_current();
                        var isUIDValid = true;

                        var financialTemplateListUID = listItem.get_item(AppSettings.getPPMFinancialTemplateListUIDColumn());

                        if (!financialTemplateListUID) {
                            financialTemplate.financialTemplateListUID = SP.Guid.get_empty()
                        } else {
                            if (!SP.Guid.isValid(financialTemplateListUID)) {
                                isUIDValid = false;
                            }
                        }

                        if (isUIDValid) {

                            var financialTemplate = new FinancialTemplate();

                            financialTemplate.financialTemplateListUID = new SP.Guid(financialTemplateListUID);
                            financialTemplate.name = listItem.get_item(AppSettings.getPPMFinancialTemplateNameColumn());
                            financialTemplate.structure = listItem.get_item(AppSettings.getFinancialStructureColumn());
                            financialTemplate.financialStartDate = new Date(listItem.get_item(AppSettings.getFinancialStartDateColumn()));
                            financialTemplate.financialEndDate = new Date(listItem.get_item(AppSettings.getFinancialEndDateColumn()));
                            financialTemplate.granularity = listItem.get_item(AppSettings.getGranularityColumn());
                            var startMonthAsNumber = listItem.get_item(AppSettings.getGranularityStartMonthColumn());

                            if (startMonthAsNumber) {
                                financialTemplate.granularityStartMonthAsNumber = parseInt(startMonthAsNumber);
                            } else {
                                financialTemplate.granularityStartMonthAsNumber = Utils.getDefaultTimescaleStartMonthAsNumber();
                            }

                            financialTemplate.granularityStartMonth = Utils.getMomentReference().months()[financialTemplate.granularityStartMonthAsNumber];

                            resolve(financialTemplate);
                        } else {
                            reject(`The Financial Template List UID, saved in the ${AppSettings.getPPMFinancialTemplateListName()} list for the ${financialTemplateName} Template, is invalid.`);
                        }
                    } else {
                        resolve(null);
                    }
                },
                function (sender, args) {
                    reject('Failed: ' + args.get_message());
                });
        });

        return Observable.fromPromise(promise);
    }

    public getFinancialValueByEntityUid(listUID: SP.Guid, entityUid: SP.Guid): Observable<FinancialValue> {
        var vm = this;
  
        var promise = new Promise<any>(function (resolve, reject) {
            var financialValueList = vm.web.get_lists().getById(listUID);
            var query = new SP.CamlQuery();
            query.set_viewXml(`<View><Query>
                                    <Where>
                                            <Eq>
                                                <FieldRef Name='EntityUID' />
                                                <Value Type='Text'>${entityUid}</Value>
                                            </Eq>
                                   </Where></Query></View>`);

            var includeColumns = "Include(Id, EntityUID, EntityName, ListItemId, FinancialStartDate, FinancialEndDate, FiscalMonthStartDate, FiscalMonthEndDate, FinancialValuesStructure, Granularity, UpdateStatus, UpdateStartDate, UpdateEndDate)";

            var queryResults = financialValueList.getItems(query);
            vm.clientContext.load(queryResults, includeColumns);
            vm.clientContext.executeQueryAsync(
                function (sender, args) {
                    var listItemEnumerator = queryResults.getEnumerator();

                    if (listItemEnumerator.moveNext()) {
                        var listItem = listItemEnumerator.get_current();
                        var financialValue = new FinancialValue();

                        financialValue.id = listItem.get_id();
                        financialValue.entityUid = listItem.get_item(AppSettings.getFinancialValueEntityUIDColumn());
                        financialValue.entityName = listItem.get_item(AppSettings.getFinancialValueEntityNameColumn());
                        financialValue.listUID = listUID;
                        financialValue.listItemId = listItem.get_item(AppSettings.getFinancialValueListItemIdColumn());
                        financialValue.financialValuesJson = listItem.get_item(AppSettings.getFinancialValueStructureColumn());
                        //financialValue.financialStartDate = vm.transformFromUTC(new Date(listItem.get_item(AppSettings.getFinancialStartDateColumn())));
                        //financialValue.financialEndDate = vm.transformFromUTC(new Date(listItem.get_item(AppSettings.getFinancialEndDateColumn())));
                        //console.log("SD,ED: " + listItem.get_item(AppSettings.getFiscalMonthStartDateColumn()) + listItem.get_item(AppSettings.getFiscalMonthEndDateColumn()));
                        if (listItem.get_item(AppSettings.getFiscalMonthStartDateColumn()) != null && listItem.get_item(AppSettings.getFiscalMonthEndDateColumn()) != null) {
                            console.log("financial grid fisical month dates not null ");
                            financialValue.financialStartDate = vm.transformFromUTC(new Date(listItem.get_item(AppSettings.getFiscalMonthStartDateColumn())));
                            financialValue.financialEndDate = vm.transformFromUTC(new Date(listItem.get_item(AppSettings.getFiscalMonthEndDateColumn())));
                        }
                        else {
                            console.log("financial grid fisical month dates are null ");
                            financialValue.financialStartDate = vm.transformFromUTC(new Date(listItem.get_item(AppSettings.getFinancialStartDateColumn())));
                            financialValue.financialEndDate = vm.transformFromUTC(new Date(listItem.get_item(AppSettings.getFinancialEndDateColumn())));
                        }
                        financialValue.granularity = listItem.get_item(AppSettings.getGranularityColumn());
                        financialValue.updateStatus = listItem.get_item(AppSettings.getFinancialValueUpdateStatusColumn());
                        resolve(financialValue);
                        
                    } else {
                        resolve(null);
                    }
                },
                function (sender, args) {
                    reject('Failed: ' + args.get_message());
                });


        });

        return Observable.fromPromise(promise);
    }

    public saveFinancialTemplate(financialTemplate: FinancialTemplate): Observable<any> {
        var vm = this;

        var promise = new Promise(function (resolve, reject) {
            var financialTemplateList = vm.web.get_lists().getByTitle(AppSettings.getPPMFinancialTemplateListName());
            vm.clientContext.load(financialTemplateList);

            var itemCreateInfo = new SP.ListItemCreationInformation();
            var listItem = financialTemplateList.addItem(itemCreateInfo);

            listItem.set_item(AppSettings.getPPMFinancialTemplateListUIDColumn(), financialTemplate.financialTemplateListUID);
            listItem.set_item(AppSettings.getPPMFinancialTemplateNameColumn(), financialTemplate.name);
            listItem.set_item(AppSettings.getFinancialStructureColumn(), financialTemplate.structure);
            listItem.set_item(AppSettings.getFinancialStartDateColumn(), financialTemplate.financialStartDate);
            listItem.set_item(AppSettings.getFinancialEndDateColumn(), financialTemplate.financialEndDate);
            listItem.set_item(AppSettings.getGranularityColumn(), financialTemplate.granularity);
            listItem.set_item(AppSettings.getGranularityStartMonthColumn(), financialTemplate.granularityStartMonthAsNumber);

            listItem.update();
            vm.clientContext.load(listItem);

            vm.clientContext.executeQueryAsync(
                function (sender, args) {
                    resolve("Finished successfully.");
                },
                function (sender, args) {
                    reject('Failed: ' + args.get_message());
                });
        });

        return Observable.fromPromise(promise);
    }

    public updateFinancialTemplate(financialTemplate: FinancialTemplate, listItem: any): Observable<any> {
        var vm = this;

        var promise = new Promise(function (resolve, reject) {
            if (!listItem) {
                reject('Failed: Item cannot be null.');
            } else {
                listItem.set_item(AppSettings.getPPMFinancialTemplateNameColumn(), financialTemplate.name);
                listItem.set_item(AppSettings.getFinancialStructureColumn(), financialTemplate.structure);
                listItem.set_item(AppSettings.getFinancialStartDateColumn(), financialTemplate.financialStartDate);
                listItem.set_item(AppSettings.getFinancialEndDateColumn(), financialTemplate.financialEndDate);
                listItem.set_item(AppSettings.getGranularityColumn(), financialTemplate.granularity);
                listItem.set_item(AppSettings.getGranularityStartMonthColumn(), financialTemplate.granularityStartMonthAsNumber);

                listItem.update();
                vm.clientContext.load(listItem);

                vm.clientContext.executeQueryAsync(
                    function (sender, args) {
                        resolve("Finished successfully.");
                    },
                    function (sender, args) {
                        reject('Failed: ' + args.get_message());
                    });
            }
        });

        return Observable.fromPromise(promise);
    }

    public saveFinancialValues(financialValue: FinancialValue): Observable<any> {
        var vm = this;
        vm.clientContext = SP.ClientContext.get_current();
        vm.hostContext = new SP.AppContextSite(vm.clientContext, vm.hostWebUrl);
        vm.web = vm.hostContext.get_web();

        var promise = new Promise(function (resolve, reject) {
            var financialValueList = vm.web.get_lists().getById(financialValue.listUID);
            var query = new SP.CamlQuery();
            query.set_viewXml(`<View><Query>
                                    <Where> 
                                        <And>
                                            <Eq>
                                                <FieldRef Name='EntityUID' />
                                                <Value Type='Text'>${financialValue.entityUid}</Value>
                                            </Eq>
                                            <Eq>
                                                <FieldRef Name='ListItemId' />
                                                <Value Type='Text'>${financialValue.listItemId}</Value>
                                            </Eq>
                                        </And>
                                   </Where></Query></View>`);

            var includeColumns = "Include(Id, EntityUID, ListItemId, FinancialStartDate, FinancialEndDate, FinancialValuesStructure, Granularity)";

            var queryResults = financialValueList.getItems(query);
            vm.clientContext.load(financialValueList);
            vm.clientContext.load(queryResults, includeColumns);
            vm.clientContext.executeQueryAsync(
                function (sender, args) {

                    var listItemEnumerator = queryResults.getEnumerator();
                    var listItem = null;

                    if (listItemEnumerator.moveNext()) {
                        listItem = listItemEnumerator.get_current();
                    } else {
                        var itemCreateInfo = new SP.ListItemCreationInformation();
                        listItem = financialValueList.addItem(itemCreateInfo);
                    }

                    if (!listItem) {
                        reject('List item initialization failed.');
                    } else {

                        listItem.set_item(AppSettings.getFinancialValueEntityNameColumn(), financialValue.entityName);
                        listItem.set_item(AppSettings.getFinancialValueEntityUIDColumn(), financialValue.entityUid);
                        listItem.set_item(AppSettings.getFinancialValueListItemIdColumn(), financialValue.listItemId);
                        listItem.set_item(AppSettings.getFinancialValueStructureColumn(), financialValue.financialValuesJson);
                        //listItem.set_item(AppSettings.getFinancialStartDateColumn(), vm.transformToUTC(financialValue.financialStartDate));
                        //listItem.set_item(AppSettings.getFinancialEndDateColumn(), vm.transformToUTC(financialValue.financialEndDate));
                        listItem.set_item(AppSettings.getFiscalMonthStartDateColumn(), vm.transformToUTC(financialValue.financialStartDate));
                        listItem.set_item(AppSettings.getFiscalMonthEndDateColumn(), vm.transformToUTC(financialValue.financialEndDate));
                        listItem.set_item(AppSettings.getFinancialStartDateColumn(), vm.transformToUTC(financialValue.originalStartDate));
                        listItem.set_item(AppSettings.getFinancialEndDateColumn(), vm.transformToUTC(financialValue.originalEndDate));

                        listItem.set_item(AppSettings.getGranularityColumn(), financialValue.granularity);

                        //Add the PlanForecastLastModified date for project
                        if (financialValueList.get_title() == AppSettings.getProjectFinancialListName()) {
                            listItem.set_item(AppSettings.getPlanForecastModifiedColumn(), new Date(new Date().getTime() + _spPageContextInfo.clientServerTimeDelta));
                        }


                        listItem.update();
                        vm.clientContext.load(listItem);

                        vm.clientContext.executeQueryAsync(
                            function (sender, args) {
                                resolve("Finished successfully.");
                            },
                            function (sender, args) {
                                reject('Failed: ' + args.get_message());
                            });
                    }
                },
                function (sender, args) {
                    reject('Failed: ' + args.get_message());
                });


        });

        return Observable.fromPromise(promise);
    }

    //Plan & forecast fields Modified & Modifiedby values updation...
    public updateFinancialGridDetails(financialValue: FinancialValue, planTotal: Number, forecastTotal: Number, currentUserId: number): Observable<any> {
        var vm = this;
        vm.clientContext = SP.ClientContext.get_current();
        vm.hostContext = new SP.AppContextSite(vm.clientContext, vm.hostWebUrl);
        vm.web = vm.hostContext.get_web();

        var promise = new Promise(function (resolve, reject) {
            var financialValueList = vm.web.get_lists().getById(financialValue.listUID);
            var query = new SP.CamlQuery();
            query.set_viewXml(`<View><Query>
                                    <Where> 
                                        <And>
                                            <Eq>
                                                <FieldRef Name='EntityUID' />
                                                <Value Type='Text'>${financialValue.entityUid}</Value>
                                            </Eq>
                                            <Eq>
                                                <FieldRef Name='ListItemId' />
                                                <Value Type='Text'>${financialValue.listItemId}</Value>
                                            </Eq>
                                        </And>
                                   </Where></Query></View>`);

            var includeColumns = "Include(Id, EntityUID, ListItemId, PlanTotal,ForecastTotal)";

            var queryResults = financialValueList.getItems(query);
            vm.clientContext.load(financialValueList);
            vm.clientContext.load(queryResults, includeColumns);
            vm.clientContext.executeQueryAsync(
                function (sender, args) {

                    var listItemEnumerator = queryResults.getEnumerator();
                    var listItem = null;

                    if (listItemEnumerator.moveNext()) {
                        listItem = listItemEnumerator.get_current();
                    }

                    if (!listItem) {
                        reject('List item initialization failed.');
                    } else {

                        //Update the Plan,Forecast Modified date and modified by for project
                        if (financialValueList.get_title() == AppSettings.getProjectFinancialListName()) {

                            var prevPlanTotal = 0;
                            var prevForecastTotal = 0;
                            if (listItem.get_item(AppSettings.getPlanTotalColumn()) != null) {
                                prevPlanTotal = listItem.get_item(AppSettings.getPlanTotalColumn());                               
                            }
                            if (listItem.get_item(AppSettings.getForecastTotalColumn()) != null) {
                                prevForecastTotal = listItem.get_item(AppSettings.getForecastTotalColumn());
                            }

                            prevPlanTotal = Math.round(prevPlanTotal);
                            prevForecastTotal = Math.round(prevForecastTotal);

                            console.log("PlanTotal : " + prevPlanTotal + ": " + planTotal);
                            console.log("ForecastTotal : " + prevForecastTotal + ": " + forecastTotal);

                            //var users = new Array();
                            //users.push(SP.FieldUserValue.fromUser(currentUserLoginName));
                            var assignedToVal = new SP.FieldUserValue();
                            assignedToVal.set_lookupId(currentUserId)

                            if (planTotal != prevPlanTotal) {
                                listItem.set_item(AppSettings.getPlanTotalColumn(), planTotal);
                                listItem.set_item(AppSettings.getPlanLastModifiedColumn(), new Date(new Date().getTime() + _spPageContextInfo.clientServerTimeDelta));
                                listItem.set_item(AppSettings.getPlanModifiedbyColumn(), assignedToVal);
                                
                            }
                            if (forecastTotal != prevForecastTotal) {
                                listItem.set_item(AppSettings.getForecastTotalColumn(), forecastTotal);
                                listItem.set_item(AppSettings.getForecastLastModifiedColumn(), new Date(new Date().getTime() + _spPageContextInfo.clientServerTimeDelta));
                                listItem.set_item(AppSettings.getForecastModifiedbyColumn(), assignedToVal);
                            }
                        }

                        listItem.update();
                        vm.clientContext.load(listItem);

                        vm.clientContext.executeQueryAsync(
                            function (sender, args) {
                                resolve("Finished successfully.");
                            },
                            function (sender, args) {
                                reject('Failed: ' + args.get_message());
                            });
                    }
                },
                function (sender, args) {
                    reject('Failed: ' + args.get_message());
                });


        });

        return Observable.fromPromise(promise);
    }



    public saveFinancialSnapshot(financialValue: FinancialValue, structure: string, startMonth: number): Observable<any> {
        var vm = this;

        var promise = new Promise(function (resolve, reject) {
            var financialSnapshotsList = vm.web.get_lists().getByTitle(AppSettings.getPPMFinancialSnapshotsListName());
            var includeColumns = "Include(Id, Name, EntityUID, ListItemId, FinancialStartDate, FinancialEndDate, Structure, Granularity)";
            vm.clientContext.load(financialSnapshotsList);
            vm.clientContext.executeQueryAsync(
                function (sender, args) {
                    var itemCreateInfo = new SP.ListItemCreationInformation();
                    var listItem = financialSnapshotsList.addItem(itemCreateInfo);

                    listItem.set_item(AppSettings.getFinancialNameColumn(), financialValue.entityUid);
                    listItem.set_item(AppSettings.getFinancialStructureColumn(), structure);
                    listItem.set_item(AppSettings.getGranularityColumn(), financialValue.granularity);
                    listItem.set_item(AppSettings.getFinancialStartDateColumn(), financialValue.financialStartDate);
                    listItem.set_item(AppSettings.getFinancialEndDateColumn(), financialValue.financialEndDate);
                    listItem.set_item(AppSettings.getFinancialValueEntityUIDColumn(), financialValue.entityUid);
                    listItem.set_item(AppSettings.getFinancialValueListItemIdColumn(), financialValue.listItemId);
                    listItem.set_item(AppSettings.getFinancialValueStartMonthColumn(), startMonth);

                    listItem.update();
                    vm.clientContext.load(listItem);

                    vm.clientContext.executeQueryAsync(
                        function (sender, args) {
                            resolve("Finished successfully.");
                        },
                        function (sender, args) {
                            reject('Failed: ' + args.get_message());
                        });

                },
                function (sender, args) {
                    reject('Failed: ' + args.get_message());
                });


        });
        return Observable.fromPromise(promise);

    }

    public createFinancialValuesList(financialTemplateName: string): Observable<any> {
        var vm = this;

        var promise = new Promise(function (resolve, reject) {

            var listCreationInfo = new SP.ListCreationInformation();
            listCreationInfo.set_title(financialTemplateName);
            listCreationInfo.set_templateType(SP.ListTemplateType.genericList);
            var newFinancialTemplateList = vm.web.get_lists().add(listCreationInfo);
            vm.clientContext.load(newFinancialTemplateList);
            vm.clientContext.load(newFinancialTemplateList.get_fields());

            vm.clientContext.executeQueryAsync(
                function (sender, args) {
                    vm.addFields(newFinancialTemplateList);
                    vm.clientContext.executeQueryAsync(
                        function (sender, args) {
                            resolve(newFinancialTemplateList.get_id());
                        },
                        function (sender, args) {
                            reject('Failed: ' + args.get_message());
                        });
                },
                function (sender, args) {
                    reject('Failed: ' + args.get_message());
                });
        });

        return Observable.fromPromise(promise);
    }

    private addFields(list: SP.List): void {

        if (list == null) {
            return;
        }

        var fields = list.get_fields();

        for (var listField of this.templateListFields) {

            if (!listField.ShouldAddField) {
                continue;
            }

            var fieldAsXml = "<Field DisplayName='" + listField.FieldTitle + "' Type='" + listField.FieldType + "' />";
            var addField = fields.addFieldAsXml(fieldAsXml, true, SP.AddFieldOptions.defaultValue);
            addField.set_required(listField.Required);
            addField.set_indexed(listField.isIndexed);
            //addField.update();
        }
    }

    public deleteFinancialTemplate(listUID: SP.Guid, listItem: SP.ListItem): Observable<any> {

        var vm = this;

        var promise = new Promise(function (resolve, reject) {
            var financialSnapshotsList = vm.web.get_lists().getById(listUID);
            vm.clientContext.load(financialSnapshotsList);

            vm.clientContext.executeQueryAsync(
                function (sender, args) {
                    financialSnapshotsList.deleteObject();
                    listItem.deleteObject();
                    vm.clientContext.executeQueryAsync(
                        function (sender, args) {
                            resolve("Finished successfully.");
                        },
                        function (sender, args) {
                            reject('Failed: ' + args.get_message());
                        });
                },
                function (sender, args) {
                    reject('Failed: ' + args.get_message());
                });
        });

        return Observable.fromPromise(promise);
    }

    public getAllListItemsByListUid(listUID: SP.Guid): Observable<any> {
        var vm = this;

        var promise = new Promise(function (resolve, reject) {
            var financialValueList = vm.web.get_lists().getById(listUID);
            var query = new SP.CamlQuery();
            query.set_viewXml(`<View><Query></Query></View>`);

            var includeColumns = "Include(Id, Title)";
            var queryResults = financialValueList.getItems(query);
            vm.clientContext.load(financialValueList, 'Id');
            vm.clientContext.load(queryResults, includeColumns);
            vm.clientContext.executeQueryAsync(
                function (sender, args) {

                    var listItemEnumerator = queryResults.getEnumerator();
                    var allListItems = [];

                    while (listItemEnumerator.moveNext()) {
                        var listItem = listItemEnumerator.get_current();

                        var id = listItem.get_id();
                        var title = listItem.get_item(AppSettings.getTitleColumn());;
                        allListItems.push({ "listUID": listUID, "id": id, "title": title });
                    }

                    resolve({ "allListItems": allListItems });

                },
                function (sender, args) {
                    reject('Failed: ' + args.get_message());
                });
        });

        return Observable.fromPromise(promise);
    }

    public isListAlreadyCreated(listTitle: string): Observable<boolean> {
        var vm = this;

        var promise = new Promise<boolean>(
            function (resolve, reject) {

                var allAvailableLists = vm.web.get_lists();
                vm.clientContext.load(allAvailableLists, 'Include(Title)');

                vm.clientContext.executeQueryAsync(
                    function (sender, args) {
                        var listEnumerator = allAvailableLists.getEnumerator();
                        var listExists = false;
                        while (listEnumerator.moveNext()) {
                            var list = listEnumerator.get_current();
                            if (list.get_title() == listTitle) {
                                listExists = true;
                                break;
                            }
                        }

                        resolve(listExists);
                    },
                    function (sender, args) {
                        reject('Failed: ' + args.get_message());
                    });
            });

        return Observable.fromPromise(promise);
    }

    private transformFromUTC(utcDate: Date): Date {
        var result: Date = new Date();

        result.setFullYear(utcDate.getUTCFullYear(), utcDate.getUTCMonth(), utcDate.getUTCDate());
        result.setHours(12, 0, 0, 0);

        return result;
    }

    private transformToUTC(cd: Date): Date {
        var result: Date = new Date();

        result.setTime(cd.getTime());

        result.setUTCFullYear(cd.getFullYear(), cd.getMonth(), cd.getDate());
        result.setUTCHours(12, 0, 0, 0);


        return result;
    }

    public getGridStartEndDataByGuid(projectUID: SP.Guid, startDateGuid: SP.Guid, endDateGuid: SP.Guid): Observable<any> {
        var vm = this;
        var promise = new Promise(
            function (resolve, reject) {
                var executor = new SP.RequestExecutor(vm.appWebUrl);
                var startDateGuidAsString = startDateGuid.toString().split("-").join("");
                var endDateGuidAsString = endDateGuid.toString().split("-").join("");

                var startDateCustomName = `Custom_${startDateGuidAsString}`;
                var endDateCustomName = `Custom_${endDateGuidAsString}`;

                var odataUrl = `${vm.appWebUrl}/_api/ProjectServer/Projects(guid'${projectUID}')/IncludeCustomFields?$select=${startDateCustomName},${endDateCustomName}`;
                executor.executeAsync({
                    url: odataUrl,
                    headers: { "Accept": "application/json; odata=verbose" },
                    method: "GET",
                    success: function (data: any) {
                        if (!data) {
                            resolve(null);
                        } else {

                            var queryResult = JSON.parse(data.body);
                            if (!queryResult) {
                                resolve(null);
                            } else {

                                var result = { "startDateCustomFieldGuid": startDateGuid, "startDateValue": "", "endDateCustomFieldGuid": endDateGuid, "endDateValue": "" };

                                var startDateVal = "";
                                var endDateVal = "";


                                for (var key in queryResult.d) {
                                    if (key.indexOf(startDateGuidAsString) != -1) {
                                        startDateVal = queryResult.d[key];
                                        result = { "startDateCustomFieldGuid": startDateGuid, "startDateValue": startDateVal, "endDateCustomFieldGuid": endDateGuid, "endDateValue": endDateVal };
                                        //break;
                                    }
                                    if (key.indexOf(endDateGuidAsString) != -1) {
                                        endDateVal = queryResult.d[key];
                                        result = { "startDateCustomFieldGuid": startDateGuid, "startDateValue": startDateVal, "endDateCustomFieldGuid": endDateGuid, "endDateValue": endDateVal };
                                        //break;
                                    }
                                }
                                resolve(result);
                            }
                        }
                    },
                    error: function (data, errorCode, errorMessage) {
                        reject(errorMessage)
                    }
                });
            });
        return Observable.fromPromise(promise);
    }


    //get the fiscal month from PPMFiscalMonth list
    public getCurrentFiscalMonth(): Observable<number> {
        var vm = this;
        var todayDate = new Date();
        var promise = new Promise<number>(function (resolve, reject) {
            var fiscalMonthList = vm.web.get_lists().getByTitle("PPMFiscalMonth");
            var query = new SP.CamlQuery();
            query.set_viewXml(`<View><Query>
                                    <Where>
                                        <Eq>
                                            <FieldRef Name='CalendarDate' />
                                            <Value Type='DateTime'><Today /></Value>
                                        </Eq>
                                   </Where></Query></View>`);

            var includeColumns = "Include(Id, FiscalYearMonthNumber)";
            var queryResults = fiscalMonthList.getItems(query);
            vm.clientContext.load(queryResults, includeColumns);

            vm.clientContext.executeQueryAsync(
                function (sender, args) {
                    var listItemEnumerator = queryResults.getEnumerator();

                    if (listItemEnumerator.moveNext()) {
                        var listItem = listItemEnumerator.get_current();
                        var isUIDValid = true;

                        var fiscalMonthNumber = listItem.get_item("FiscalYearMonthNumber");

                        if (fiscalMonthNumber !=0) {
                            resolve(fiscalMonthNumber);
                            //alert(fiscalMonthNumber);
                        } else {
                            reject("No fiscal month number found ");
                        }
                    } else {
                        resolve(null);
                    }
                },
                function (sender, args) {
                    reject('Failed: ' + args.get_message());
                });
        });

        return Observable.fromPromise(promise);
    }

    public getFinGridFiscalMonth(gridDate: Date): Observable<number> {

        var vm = this;

        var fgDate = gridDate.toISOString();
        var promise = new Promise<number>(function (resolve, reject) {
            var fiscalMonthList = vm.web.get_lists().getByTitle("PPMFiscalMonth");
            var query = new SP.CamlQuery();
            query.set_viewXml(`<View><Query>
                                    <Where>
                                        <Eq>
                                            <FieldRef Name='CalendarDate' />
                                            <Value Type='DateTime'>${fgDate}</Value>
                                        </Eq>
                                   </Where></Query></View>`);

            var includeColumns = "Include(Id, FiscalYearMonthNumber)";
            var queryResults = fiscalMonthList.getItems(query);
            vm.clientContext.load(queryResults, includeColumns);

            vm.clientContext.executeQueryAsync(
                function (sender, args) {
                    var listItemEnumerator = queryResults.getEnumerator();

                    if (listItemEnumerator.moveNext()) {
                        var listItem = listItemEnumerator.get_current();
                        var isUIDValid = true;

                        var fiscalMonthNumber = listItem.get_item("FiscalYearMonthNumber");

                        if (fiscalMonthNumber != 0) {
                            resolve(fiscalMonthNumber);
                        } else {
                            reject("No fiscal month number found ");
                        }
                    } else {
                        resolve(null);
                    }
                },
                function (sender, args) {
                    reject('Failed: ' + args.get_message());
                });
        });

        return Observable.fromPromise(promise);
    }

}