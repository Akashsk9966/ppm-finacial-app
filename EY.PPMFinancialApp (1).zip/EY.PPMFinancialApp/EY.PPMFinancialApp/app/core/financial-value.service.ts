﻿/// <reference path="../../typings/microsoft-ajax/microsoft.ajax.d.ts" />
/// <reference path="../../typings/sharepoint/sharepoint.d.ts" />
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/observable/fromPromise';
import { Http, Headers } from '@angular/http';
import { AppSettings } from '../shared/app-settings';
import { Utils } from '../shared/utils';
import { FinancialTemplate } from '../shared/model/financial-template.model';
import { FinancialValue } from '../shared/model/financial-value.model';
import { SharePointService } from './sharepoint.service';
import { FinancialUpdateTrackerModel } from '../shared/model/financial-update-tracker.model';
import { FinancialNode } from '../shared/model/financial-node.model';
import { FinancialValuesStructureModel } from '../shared/model/financial-values-structure.model';
import { GranularityValueModel } from '../shared/model/granularity-value.model';

// This service is mainly used to update the financial values and the structures for them when the user decdes to go in the update page.

@Injectable()
export class FinancialValueService {

    projectContext: any;
    clientContext: SP.ClientContext;
    hostContext: SP.AppContextSite;
    hostWebUrl: string;
    appWebUrl: string;
    web: SP.Web;

    constructor(private sharePointService: SharePointService) {
        var vm = this;
        vm.clientContext = SP.ClientContext.get_current();
        this.hostWebUrl = decodeURIComponent(Utils.getQueryStringParameter("SPHostUrl"));
        this.appWebUrl = decodeURIComponent(Utils.getQueryStringParameter("SPAppWebUrl"));
        vm.hostContext = new SP.AppContextSite(vm.clientContext, this.hostWebUrl);
        vm.web = vm.hostContext.get_web();
    }

    public updateFinancialValueStructures(newFinancialTemplate: FinancialTemplate, allFinancialValues: Array<FinancialValue>, allFinancialValuesListItems: Array<SP.ListItem>, financialNodesStructure: Array<any>): Observable<any> {
        var vm = this;

        var promise = new Promise(function (resolve, reject) {
            var nodeReferenceDict: any = [];
            var updateFinishedSuccesfully = true;
            var updateInProgress = true;
            var updateQueue = [];
            for (var financialValue of allFinancialValues) {
                var updateItem: any = undefined;

                for (var item of allFinancialValuesListItems) {

                    if (financialValue.entityUid == item.get_item(AppSettings.getFinancialValueEntityUIDColumn())) {

                        updateItem = item;
                        financialValue.updateStartDate = new Date();
                        financialValue.updateStatus = AppSettings.getUpdateInProgress();
                        break;
                    }
                }

                if (!updateItem) {
                    continue;
                }

                updateQueue.push(vm.updateFinancialValueStructure(newFinancialTemplate, financialValue, updateItem, financialNodesStructure));
            }

            Observable.forkJoin(updateQueue).subscribe(
                (data) => {
                    var errorMessages = [];
                    var finishedWithErrors = false;
                    for (var d of data) {
                        if (d.isUpdateSuccessful == false) {
                            errorMessages.push(d.errorMesasge);
                            finishedWithErrors = true;
                        }
                    }

                    if (finishedWithErrors) {
                        reject(errorMessages);
                    } else {
                        resolve();
                    }
                },
                (err) => {
                    reject(err);
                });
        });
        return Observable.fromPromise(promise);
    }

    public updateFinancialValueStructuresIterative(newFinancialTemplate: FinancialTemplate, allFinancialValues: Array<FinancialValue>, allFinancialValuesListItems: Array<SP.ListItem>, financialNodesStructure: Array<any>): Observable<any> {
        var vm = this;

        var promise = new Promise(function (resolve, reject) {
            var nodeReferenceDict: any = [];
            var updateFinishedSuccesfully = true;
            var updateInProgress = true;

            vm.updateFinancialValueStructuresIteration(newFinancialTemplate, allFinancialValues, allFinancialValuesListItems, financialNodesStructure, resolve, 0);
            
        });
        return Observable.fromPromise(promise);
    }

    public updateFinancialValueStructuresIteration(newFinancialTemplate: FinancialTemplate, allFinancialValues: Array<FinancialValue>, allFinancialValuesListItems: Array<SP.ListItem>, financialNodesStructure: Array<any>, finPromCB: Function, index: number) {


        let vm = this;
        var financialValue = allFinancialValues[index];

        var updateItem: any = undefined;

        for (var item of allFinancialValuesListItems) {

            if (financialValue.entityUid == item.get_item(AppSettings.getFinancialValueEntityUIDColumn())) {

                updateItem = item;
                financialValue.updateStartDate = new Date();
                financialValue.updateStatus = AppSettings.getUpdateInProgress();
                break;
            }
        }

        if (index < (allFinancialValues.length - 1)) {


            if (!updateItem) {
                vm.updateFinancialValueStructuresIteration(newFinancialTemplate, allFinancialValues, allFinancialValuesListItems, financialNodesStructure, finPromCB, index + 1)
            } else {
                vm.updateFinancialValueStructure(newFinancialTemplate, financialValue, updateItem, financialNodesStructure).subscribe(res => {
                    console.log("Processed item " + index + " of " + allFinancialValues.length);

                    vm.updateFinancialValueStructuresIteration(newFinancialTemplate, allFinancialValues, allFinancialValuesListItems, financialNodesStructure, finPromCB, index + 1)
                }, err => {
                    console.error("Item update failed.")
                });
            }
            
        } else {
            finPromCB();
        }
    }

    //  take care of the update process for each struc
    private updateFinancialValueStructure(newFinancialTemplate: FinancialTemplate, financialValue: FinancialValue, updateItem: SP.ListItem, financialNodesStructure: Array<any>): Observable<any> {
        var vm = this;
        var nodeReferenceDict: any = [];
        var oldFinancialStructure = "";

        var promise = new Promise(function (resolve, reject) {
            vm.sharePointService.updateFinancialValue(financialValue, updateItem, false).subscribe(
                (data) => {

                    nodeReferenceDict = [];
                    // In case of errors we try to rollback to the old structure.
                    oldFinancialStructure = Object.assign({}, financialValue.financialValuesJson);
                    var financialValueStructure = JSON.parse(financialValue.financialValuesJson);

                    // When updating the financial value structure we first reset the parent values setting them to 0.
                    vm.resetFinancialValues(financialNodesStructure, financialValueStructure, nodeReferenceDict);
                    // We recalculate the parent values based on the children and their values.
                    var newFinancialValueStructure = vm.updateFinancialValues(nodeReferenceDict);

                    financialValue.financialValuesJson = JSON.stringify(newFinancialValueStructure);
                    financialValue.updateEndDate = new Date();
                    financialValue.updateStatus = AppSettings.getUpdateFinishedSuccessfully();

                    vm.sharePointService.updateFinancialValue(financialValue, updateItem, true).subscribe(
                        (data) => {
                            vm.sharePointService.createUpdateTrackerEntry(newFinancialTemplate.name, financialValue).subscribe(
                                (data) => {
                                    resolve({ "isUpdateSuccessful": true });
                                }, (err) => {
                                    resolve({ "isUpdateSuccessful": false, "errorMesasge": err });
                                });

                        }, (err) => {
                            resolve({ "isUpdateSuccessful": false, "errorMesasge": err });
                        });

                }, (err) => {
                    financialValue.updateStatus = AppSettings.getUpdateFailed();
                    financialValue.financialValuesJson = oldFinancialStructure;

                    vm.sharePointService.updateFinancialValue(financialValue, updateItem, true).subscribe(
                        (data) => {
                            vm.sharePointService.createUpdateTrackerEntry(newFinancialTemplate.name, financialValue).subscribe(
                                (data) => {
                                    resolve({ "isUpdateSuccessful": false, "errorMesasge": err });
                                }, (err) => {
                                    resolve({ "isUpdateSuccessful": false, "errorMesasge": err });
                                });
                        }, (err) => {
                            resolve({ "isUpdateSuccessful": false, "errorMesasge": err });
                        });
                });
        });
        return Observable.fromPromise(promise);
    }

    // When reseting the financial values we make sure that only the child nodes keep their values and afterwards we recalculate the parent values.
    private resetFinancialValues(financialNodesStructure: Array<FinancialNode>, financialValueStructure: FinancialValuesStructureModel[], nodeReferenceDict: { [key: string]: { financialNode: FinancialNode, financialValueStructure: FinancialValuesStructureModel, hasChildren: boolean } }) {


        if (financialValueStructure) {

            for (var financialNode of financialNodesStructure) {
                var hasChildren = financialNode.children.length > 0;

                for (var structure of financialValueStructure) {

                    if (structure.id != financialNode.id) {
                        continue;
                    }

                    if (hasChildren) {
                        for (var key in structure.vals) {
                            structure.vals[key].val = 0;
                        }
                    }

                    nodeReferenceDict[financialNode.id] = { "financialNode": financialNode, "financialValueStructure": structure, "hasChildren": hasChildren };
                }

                if (!nodeReferenceDict[financialNode.id]) {
                    var newStructure: FinancialValuesStructureModel = { id: Utils.getNoneRootID(), pid: Utils.getNoneRootID(), vals: [] };
                    var newNode = Object.assign({}, financialNode);

                    newStructure.id = newNode.id;
                    newStructure.pid = newNode.parentId;

                    nodeReferenceDict[newNode.id] = { financialNode: newNode, financialValueStructure: newStructure, hasChildren: hasChildren };
                }

                if (financialNode.children && financialNode.children.length > 0) {
                    this.resetFinancialValues(financialNode.children, financialValueStructure, nodeReferenceDict);
                }
            }
        }
    }

    //  recalculate the parent values based on the child values.
    private updateFinancialValues(nodeReferenceDict: { [key: string]: { financialNode: FinancialNode, financialValueStructure: FinancialValuesStructureModel, hasChildren: boolean } }) {
        var vm = this;
        var updateInProgress = true;
        var newFinancialValueStructure = [];
        for (var key in nodeReferenceDict) {
            var node = nodeReferenceDict[key];
            newFinancialValueStructure.push(node.financialValueStructure);
            if (node.hasChildren) {
                continue;
            }

            var parentId = node.financialNode.parentId;
            updateInProgress = true;
            while (updateInProgress) {
                var parentNode = nodeReferenceDict[parentId];

                if (!parentNode) {
                    updateInProgress = false;
                    break;
                }
                
                for (var key in node.financialValueStructure.vals) {

                    var parentNodeValue = 0;
                    var parentVal = null;

                    for (var j = 0; j < parentNode.financialValueStructure.vals.length; j++) {
                        if (parentNode.financialValueStructure.vals[j].mth == node.financialValueStructure.vals[key].mth &&
                            parentNode.financialValueStructure.vals[j].yr == node.financialValueStructure.vals[key].yr) {

                            parentVal = parentNode.financialValueStructure.vals[j];
                        }
                    }


                    if (parentVal == null) {

                        parentVal = {
                            mth: node.financialValueStructure.vals[key].mth,
                            yr:node.financialValueStructure.vals[key].yr,
                            val: 0
                        }

                        parentNode.financialValueStructure.vals.push(parentVal);
                    }


                    parentNodeValue = parentVal.val;
                    

                    var nodeValue = 0;

                    if (node.financialValueStructure.vals[key]) {
                        nodeValue = node.financialValueStructure.vals[key].val;
                    } 

                    parentVal.val = parentNodeValue + nodeValue;
                }

                if (parentNode.financialNode.id == Utils.getDefaultRootID()) {
                    updateInProgress = false;
                } else {
                    parentId = parentNode.financialNode.parentId;
                }
            }
        }

        return newFinancialValueStructure;
    }

}