<script src="http://derusvmdulws017/DevPWA/SiteCollectionDocuments/jquery-3.1.0.js"></script>
<script type="text/javascript">

    window.addEventListener('message', function (event) {
        if(event.data == "getListInfo"){
            var pageListId =  SP.PageContextInfo.get_pageListId(); 
            var pageListItemId =  getQueryStringParameter("ID") 
            var allFrames = $("iframe");
            if(!allFrames ){
                return;
            }
            var framesLength = allFrames.length;

            for(var i=0;i<framesLength;i++){
                var frame  = allFrames[i];
                frame.contentWindow.postMessage("ListInfo:ListId-"+pageListId+"ListItemId-{"+pageListItemId+"}", '*');
            }
        }
    });

    window.addEventListener('message', function (event) {
                   
        if(event.data.indexOf("onSaveMappedFieldValues")==-1){
            return;
        }
                   
        var dataArr = event.data.split('#');

        if (dataArr.length != 3) {
            return;
        }

        var postMesId = dataArr[1];
        var fieldValuesStrArr = dataArr[2].split("|");
        var fieldValues = [];
        var i=0;
				   
				   
        for(i=0;i<fieldValuesStrArr.length;i++){
            var spVal = fieldValuesStrArr[i].split(":");
					   
            var cfId = spVal[0];
            var cfValue = spVal[1];
            var cfInput = $(String.format("input[guid='{0}']", cfId));
            if (cfInput.length >0) {
                cfInput.val(cfValue);
            }
        }
				   
        var allFrames = $("iframe");
        var frameLength = allFrames.length;
        for(i=0;i<frameLength;i++){
            var frame  = allFrames[i];
            var url = decodeURIComponent(frame.src);
            if(!url){
                continue;
            }

            if(url.indexOf("financialValues")==-1){
                continue;
            }

            frame.contentWindow.postMessage("CFMappingsSaved#"+postMesId, '*');
                       
        }
    });


function getQueryStringParameter(paramToRetrieve) {
    var params = document.URL.split("?")[1].split("&");
    var strParams = "";
    for (var i = 0; i < params.length; i = i + 1) {
        var singleParam = params[i].split("=");
        if (singleParam[0] === paramToRetrieve)
            return singleParam[1];
    }
}

function PreSaveAction(){
    var allFrames = $("iframe");
    var saveId = 1;
    var oldSaveId = 1;
    var areAllPostMessagesFinished = false;

    window.addEventListener('message', function (event) {
        if(event.data.indexOf("onProjectSaveFinishedEvent")!=-1){
            var dataArr = event.data.split('#');

            if (dataArr.length != 2) {
                return;
            }

            oldSaveId = oldSaveId + 1;
                
            if(saveId == oldSaveId && areAllPostMessagesFinished){
                oldSaveId = 1;
                triggerPostback();
            }
        }
    });
    var framesLength = allFrames.length;

    for(var i=0;i<framesLength;i++){
        var frame  = allFrames[i];
        var url = decodeURIComponent(frame.src);
                       
        if(!url){
            continue;
        }

        if(url.indexOf("financialValues")==-1){
            continue;
        }

        frame.contentWindow.postMessage("onProjectSaveEvent#"+saveId, '*');
        saveId ++;
    }
    areAllPostMessagesFinished = true;
    return false;
}

function triggerPostback(){
    var saveButtonName = $('input[name$="SaveItem"]').attr('name');
    WebForm_DoPostBackWithOptions(new WebForm_PostBackOptions(saveButtonName, "", true, "", "", false, true));  
}

//UTILITY

if (typeof String.concat !== "function") {
    String.concat = function () {
        var result = [];
        for (var i = 0; i < arguments.length; i++) {
            result.push(arguments[i]);
        }

        return result.join("");
    }
}

if (typeof String.format !== "function") {
    String.format = function (format) {
        var args = Array.prototype.slice.call(arguments, 1);
        return format.replace(/{(\d+)}/g, function (match, number) {
            return typeof args[number] != 'undefined'
              ? args[number]
              : match
            ;
        });
    };
}

</script>
