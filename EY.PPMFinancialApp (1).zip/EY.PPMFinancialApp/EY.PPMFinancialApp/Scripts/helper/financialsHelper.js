<script src="http://derusvmdulws016/PWA/SiteCollectionDocuments/jquery-3.1.1.min.js"></script>
<script type="text/javascript">

   $(window).on("load", function () { 
       var financialsHelper = (function () {
           
           var basicInfoWebPart;
           var originalSave;
           var originalSaveContext;
           var originalSaveScope;
           var saveId;
           var postMessageSaveId;
           var areAllPostMessagesFinished;

           var init = function () {
               var vm = this;
               if(!window.WPDPParts){
                   return;					 
               }
				 
               if(!window.WPDPParts[0]){
                   return;
               }
				 
               basicInfoWebPart = window.WPDPParts[0];
               vm.originalSave = basicInfoWebPart.Save;
           };

           var registerEvents = function(){
               var vm = this;
               if(!basicInfoWebPart){
                   return;
               }

               window.addEventListener('message', function (event) {
			
                   if(event.data == "FinancialValuesChangeEvent"){
				
                       if(basicInfoWebPart.IsDirty){
                           return;					
                       }
				
                       basicInfoWebPart.IsDirty = true
                   }
               });

               window.addEventListener('message', function (event) {
			
                   if(event.data == "FinancialValuesChangeEvent"){
				
                       if(basicInfoWebPart.IsDirty){
                           return;					
                       }
				
                       basicInfoWebPart.IsDirty = true
                   }
               });
			   
			   
               window.addEventListener('message', function (event) {
                   
                   if(event.data.indexOf("onProjectSaveFinishedEvent")==-1){
                       return;
                   }
                   
                   var dataArr = event.data.split('#');

                   if (dataArr.length != 2) {
                       return;
                   }

                   postMessageSaveId++
                   if(postMessageSaveId == saveId && areAllPostMessagesFinished ){
                       postMessageSaveId = 1;
                       vm.originalSave.apply(vm.originalSaveScope, [vm.originalSaveContext])
                   }
               });

               window.addEventListener('message', function (event) {
                   
                   if(event.data.indexOf("onSaveMappedFieldValues")==-1){
                       return;
                   }
                   
                   var dataArr = event.data.split('#');

                   if (dataArr.length != 3) {
                       return;
                   }

                   var postMesId = dataArr[1];
                   var fieldValuesStrArr = dataArr[2].split("|");
                   var fieldValues = [];
                   var i=0;
				   
				   
                   for(i=0;i<fieldValuesStrArr.length;i++){
                       var spVal = fieldValuesStrArr[i].split(":");
					   
                       var cfId = spVal[0];
                       var cfValue = spVal[1];
                       var cfInput = $(String.format("input[guid='{0}']", cfId));
                       if (cfInput.length >0) {
                           cfInput.val(cfValue);
                       }
                   }
				   
                   var allFrames = $("iframe");
                   var frameLength = allFrames.length;
                   for(i=0;i<frameLength;i++){
                       var frame  = allFrames[i];
                       var url = decodeURIComponent(frame.src);
                       if(!url){
                           continue;
                       }

                       if(url.indexOf("financialValues")==-1){
                           continue;
                       }

                       frame.contentWindow.postMessage("CFMappingsSaved#"+postMesId, '*');
                       
                   }
               });
			   
			   
			   
               basicInfoWebPart.Save = function(saveContext){
                   var allFrames = $("iframe");				   
                   vm.originalSaveContext = saveContext;
                   vm.originalSaveScope = this;
                   basicInfoWebPart = window.WPDPParts[0];				   
                   postMessageSaveId = 1;
                   areAllPostMessagesFinished = false;
                   saveId = 1;
                   var frameLength = allFrames.length;
                   
                   for(var i=0;i<frameLength;i++){
                       var frame  = allFrames[i];
                       var url = decodeURIComponent(frame.src);
                       if(!url){
                           continue;
                       }

                       if(url.indexOf("financialValues")==-1){
                           continue;
                       }

                       frame.contentWindow.postMessage("onProjectSaveEvent#"+saveId, '*');
                       saveId++;
                   }
                   areAllPostMessagesFinished = true;
               }
           };	
		
           return {
               init: init,
               registerEvents: registerEvents
           };
       })();

       financialsHelper.init();      
       financialsHelper.registerEvents();
   });
//UTILITY

if (typeof String.concat !== "function") {
    String.concat = function () {
        var result = [];
        for (var i = 0; i < arguments.length; i++) {
            result.push(arguments[i]);
        }

        return result.join("");
    }
}

if (typeof String.format !== "function") {
    String.format = function (format) {
        var args = Array.prototype.slice.call(arguments, 1);
        return format.replace(/{(\d+)}/g, function (match, number) {
            return typeof args[number] != 'undefined'
              ? args[number]
              : match
            ;
        });
    };
}
</script>
