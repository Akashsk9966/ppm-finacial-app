﻿var PPMFinancialApp = (function () {

    var errorMessage = "Danger";
    var informationMessage = "Info";
    var addTemplateCustomActionTitle = 'Create Financial Template';
    var updateTemplateCustomActionTitle = 'Update Financial Template';
    var forceUpdateFinancialValues = 'Force Update Financial Values';
    var importExportFinancialValues = 'Import/Export Financial Values';
    var clientContext;
    var appWebURL;
    var hostURL;
    var hostContext;
    var web;
    var site;
    var templateListName = "PPMFinancialTemplate"
    var templateListFields = [
     {
         FieldTitle: "Name",
         FieldType: "Text",
         Required: false,
         ShouldAddField: true,
         isIndexed: false
     },
     {
         FieldTitle: "Structure",
         FieldType: "Note",
         Required: false,
         ShouldAddField: true,
         isIndexed: true
     },
     {
         FieldTitle: "FinancialStartDate",
         FieldType: "DateTime",
         Required: false,
         ShouldAddField: true,
         isIndexed: false
     },
     {
         FieldTitle: "FinancialEndDate",
         FieldType: "DateTime",
         Required: false,
         ShouldAddField: true,
         isIndexed: false
     },
     {
         FieldTitle: "Granularity",
         FieldType: "Text",
         Required: false,
         ShouldAddField: true,
         isIndexed: false
     },
     {
         FieldTitle: "FinancialTemplateListUID",
         FieldType: "Text",
         Required: false,
         ShouldAddField: true,
         isIndexed: true
     },
     {
         FieldTitle: "StartMonth",
         FieldType: "Number",
         Required: false,
         ShouldAddField: true,
         isIndexed: false
     }
    ]
    var updateTrackerListName = "PPMFinancialUpdateTracker";
    var updateTrackerListFields = [
     {
         FieldTitle: "EntityUID",
         FieldType: "Text",
         Required: false,
         ShouldAddField: true,
         isIndexed: true
     },
     {
         FieldTitle: "FinancialValueListUID",
         FieldType: "Text",
         Required: false,
         ShouldAddField: true,
         isIndexed: true
     },
     {
         FieldTitle: "ListItemId",
         FieldType: "Text",
         Required: false,
         ShouldAddField: true,
         isIndexed: true
     },
     {
         FieldTitle: "UpdateStatus",
         FieldType: "Text",
         Required: false,
         ShouldAddField: true,
         isIndexed: false
     },
     {
         FieldTitle: "FinancialTemplateName",
         FieldType: "Text",
         Required: false,
         ShouldAddField: true,
         isIndexed: false
     },
     {
         FieldTitle: "EntityName",
         FieldType: "Text",
         Required: false,
         ShouldAddField: true,
         isIndexed: false
     }
    ];
    var ppmSnapshotsListName = "PPMFinancialSnapshots";
    var ppmSnapshotsListFields = [
        {
            FieldTitle: "Name",
            FieldType: "Text",
            Required: false,
            ShouldAddField: true,
            isIndexed: false
        },
        {
            FieldTitle: "Structure",
            FieldType: "Note",
            Required: false,
            ShouldAddField: true,
            isIndexed: true
        },
        {
            FieldTitle: "Granularity",
            FieldType: "Text",
            Required: false,
            ShouldAddField: true,
            isIndexed: false
        },
        {
            FieldTitle: "FinancialStartDate",
            FieldType: "DateTime",
            Required: false,
            ShouldAddField: true,
            isIndexed: false
        },
        {
            FieldTitle: "FinancialEndDate",
            FieldType: "DateTime",
            Required: false,
            ShouldAddField: true,
            isIndexed: false
        },

        {
            FieldTitle: "EntityUID",
            FieldType: "Text",
            Required: false,
            ShouldAddField: true,
            isIndexed: true
        },
        {
            FieldTitle: "ListItemId",
            FieldType: "Number",
            Required: false,
            ShouldAddField: true,
            isIndexed: true
        },
        {
            FieldTitle: "StartMonth",
            FieldType: "Number",
            Required: false,
            ShouldAddField: true,
            isIndexed: false
        }
    ];

    var init = function () {
        clientContext = SP.ClientContext.get_current();
        appWebURL = decodeURIComponent(getQueryStringParameter("SPAppWebUrl"));
        hostURL = getQueryStringParameter('SPHostUrl');
        hostContext = new SP.AppContextSite(clientContext, decodeURIComponent(hostURL));
        web = hostContext.get_web();
        site = hostContext.get_site();
        console.log("Start")
        $('#btnAddSiteSettingsLink').on('click',
            function () {
                var waitDialog = SP.UI.ModalDialog.showWaitScreenWithNoClose("Loading", "Working on it.", 200, 300);
                $.when(addSiteSettingsLinks()).then(
                    function (message) {
                        displayMessage(informationMessage, message);
                        waitDialog.close(SP.UI.DialogResult.OK);
                    },
                    function (err) {
                        displayMessage(errorMessage, err);
                        waitDialog.close(SP.UI.DialogResult.OK);
                    });
            });

        $('#btnRemoveSiteSettingsLink').on('click',
            function () {
                var waitDialog = SP.UI.ModalDialog.showWaitScreenWithNoClose("Loading", "Working on it.", 200, 300);
                $.when(removeSiteSettingsLinks()).then(
                    function (message) {
                        displayMessage(informationMessage, message);
                        waitDialog.close(SP.UI.DialogResult.OK);
                    },
                    function (err) {
                        displayMessage(errorMessage, err);
                        waitDialog.close(SP.UI.DialogResult.OK);
                    });
            });
        $('#btnCreateAllLists').on('click',
            function () {
                var messages = [];
                var waitDialog = SP.UI.ModalDialog.showWaitScreenWithNoClose("Loading", "Working on it.", 200, 300);

                $.when(addList(templateListName, templateListFields))
                    .then(
                    function (message) {
                        messages.push(message);
                        return addList(updateTrackerListName, updateTrackerListFields)
                    },
                    function (err) {
                        displayMessage(errorMessage, err);
                        waitDialog.close(SP.UI.DialogResult.OK);
                    })
                    .then(
                    function (message) {
                        messages.push(message);
                        return addList(ppmSnapshotsListName, ppmSnapshotsListFields);
                    },
                    function (err) {
                        displayMessage(errorMessage, err);
                        waitDialog.close(SP.UI.DialogResult.OK);
                    }).then(
                    function (message) {
                        messages.push(message);
                        displayMessage(informationMessage, messages.join(" "));
                        waitDialog.close(SP.UI.DialogResult.OK);

                    }, function (err) {
                        displayMessage(errorMessage, err);
                        waitDialog.close(SP.UI.DialogResult.OK);
                    });
            });

        $('#btnAddPPMFinancialTemplateList').on('click',
            function () {
                var waitDialog = SP.UI.ModalDialog.showWaitScreenWithNoClose("Loading", "Working on it.", 200, 300);

                $.when(addList(templateListName, templateListFields)).then(
                    function (message) {
                        displayMessage(informationMessage, message);
                        waitDialog.close(SP.UI.DialogResult.OK);
                    },
                    function (err) {
                        displayMessage(errorMessage, err);
                        waitDialog.close(SP.UI.DialogResult.OK);
                    });
            });

        $('#btnAddPPMFinancialUpdateTrackerList').on('click',
            function () {
                var waitDialog = SP.UI.ModalDialog.showWaitScreenWithNoClose("Loading", "Working on it.", 200, 300);

                $.when(addList(updateTrackerListName, updateTrackerListFields)).then(
                    function (message) {
                        displayMessage(informationMessage, message);
                        waitDialog.close(SP.UI.DialogResult.OK);
                    },
                    function (err) {
                        displayMessage(errorMessage, err);
                        waitDialog.close(SP.UI.DialogResult.OK);
                    });
            });

        $('#btnAddPPMFinancialSnapshotsList').on('click',
            function () {
                var waitDialog = SP.UI.ModalDialog.showWaitScreenWithNoClose("Loading", "Working on it.", 200, 300);

                $.when(addList(ppmSnapshotsListName, ppmSnapshotsListFields)).then(
                    function (message) {
                        displayMessage(informationMessage, message);
                        waitDialog.close(SP.UI.DialogResult.OK);
                    },
                    function (err) {
                        displayMessage(errorMessage, err);
                        waitDialog.close(SP.UI.DialogResult.OK);
                    });
            });
    };

    var addSiteSettingsLinks = function () {
        var dfd = jQuery.Deferred();

        addLink(addTemplateCustomActionTitle, getCreateTemplatePageURL());
        addLink(updateTemplateCustomActionTitle, getUpdateTemplatePageURL());
        addLink(forceUpdateFinancialValues, getForceUpdateFinancialValuesPageURL());
        addLink(importExportFinancialValues, getImportExportFinancialValuesPageURL());

        clientContext.executeQueryAsync(function () {
            dfd.resolve('Site settings links added successfully.');
        }, function (sender, args) {
            dfd.reject(getErrorMessage("Something went wrong.", args));
        });
        return dfd.promise();
    }

    var addLink = function (custoActionTitle, siteSettingsURL) {
        var userCA = web.get_userCustomActions().add();
        userCA.set_location('Microsoft.SharePoint.SiteSettings');
        userCA.set_group("SiteAdministration");
        userCA.set_sequence(100);
        userCA.set_title(custoActionTitle);
        userCA.set_url(siteSettingsURL);
        userCA.update();
    }

    var getCreateTemplatePageURL = function () {
        var createNewChallengeLink = `${appWebURL}/Pages/FinancialTemplatePage.aspx?SPHostUrl=${hostURL}&SPAppWebUrl=${appWebURL}&component=createFinancialTemplate`;
        return createNewChallengeLink;
    }

    var getUpdateTemplatePageURL = function () {
        var createNewChallengeLink = `${appWebURL}/Pages/FinancialTemplatePage.aspx?SPHostUrl=${hostURL}&SPAppWebUrl=${appWebURL}&component=updateFinancialTemplate`;
        return createNewChallengeLink;
    }

    var getForceUpdateFinancialValuesPageURL = function () {
        var createNewChallengeLink = appWebURL + "/Pages/FinancialTemplatePage.aspx?SPHostUrl=" + hostURL + "&component=forceUpdateFinancialValues";
        return createNewChallengeLink;
    }

    var getImportExportFinancialValuesPageURL = function () {
        var createNewChallengeLink = appWebURL + "/Pages/FinancialTemplatePage.aspx?SPHostUrl=" + hostURL + "&component=importExportFinancialValues";
        return createNewChallengeLink;
    }

    var removeSiteSettingsLinks = function () {
        var dfd = jQuery.Deferred();
        var collUserCustomAction = web.get_userCustomActions();

        clientContext.load(collUserCustomAction);
        clientContext.executeQueryAsync(function () {
            var item = collUserCustomAction.getEnumerator();
            var customActionToDelete = [];
            while (item.moveNext()) {
                var currAction = item.get_current();
                if (currAction.get_title() === addTemplateCustomActionTitle ||
                    currAction.get_title() === updateTemplateCustomActionTitle ||
                    currAction.get_title() === forceUpdateFinancialValues ||
                    currAction.get_title() === importExportFinancialValues) {
                    customActionToDelete.push(currAction);
                }
            }

            if (!customActionToDelete) {
                dfd.resolve('There are no custom actions that require deletion.');
                return;
            }

            var customActionLength = customActionToDelete.length;

            for (var i = 0; i < customActionLength; i++) {
                customAction = customActionToDelete[i];
                customAction.deleteObject();
                clientContext.load(customAction);
            }

            clientContext.executeQueryAsync(function () {
                dfd.resolve('Site settings removed successfully.');
            }, function (sender, args) {
                dfd.reject(getErrorMessage("Something went wrong.", args));
            });

        }, function (sender, args) {
            dfd.reject(getErrorMessage("Something went wrong.", args));
        });

        return dfd.promise();
    }

    var addList = function (listTitle, listFields) {
        var dfd = jQuery.Deferred();
        allAvailableLists = web.get_lists();
        clientContext.load(allAvailableLists, 'Include(Title)');

        clientContext.executeQueryAsync(function () {
            var listEnumerator = allAvailableLists.getEnumerator();
            var listExists = false;
            while (listEnumerator.moveNext()) {
                var list = listEnumerator.get_current();
                if (list.get_title() == listTitle) {
                    listExists = true;
                    break;
                }
            }

            if (listExists) {
                dfd.resolve(`${listTitle} List already exists.`);
            } else {
                $.when(createList(listTitle, listFields))
                    .then(
                    function (message) {
                        dfd.resolve(message);
                    },
                    function (err) {
                        dfd.reject(err);
                    });
            }
        }, function (sender, args) {
            dfd.reject(getErrorMessage("Something went wrong. ", args));
        });

        return dfd.promise();
    }

    var createList = function (listTitle, listFields) {
        var dfd = jQuery.Deferred();
        var listCreationInfo = new SP.ListCreationInformation();
        listCreationInfo.set_title(listTitle);
        listCreationInfo.set_templateType(SP.ListTemplateType.genericList);
        var newFinancialTemplateList = web.get_lists().add(listCreationInfo);
        clientContext.load(newFinancialTemplateList);
        clientContext.load(newFinancialTemplateList.get_fields());

        clientContext.executeQueryAsync(
            function (sender, args) {
                addFields(newFinancialTemplateList, listFields);
                clientContext.executeQueryAsync(
                    function (sender, args) {
                        dfd.resolve(`${listTitle} was created successfully.`);
                    },
                    function (sender, args) {
                        dfd.reject(getErrorMessage("Something went wrong.", args));
                    });
            },
            function (sender, args) {
                dfd.reject(getErrorMessage("Something went wrong.", args));
            });

        return dfd.promise();
    }

    var addFields = function (list, listFields) {

        if (list == null) {
            return;
        }

        var fields = list.get_fields();

        for (var listField of listFields) {

            if (!listField.ShouldAddField) {
                continue;
            }
            console.log(listField.FieldTitle)
            var fieldAsXml = "<Field DisplayName='" + listField.FieldTitle + "' Type='" + listField.FieldType + "' />";
            var addField = fields.addFieldAsXml(fieldAsXml, true, SP.AddFieldOptions.defaultValue);
            addField.set_required(listField.Required);
            addField.set_indexed(listField.isIndexed);
        }
    }

    var addPPMFinancialUpdateTrackerList = function () { }

    var addPPMFinancialSnapshotsList = function () { }

    var displayMessage = function (messageType, infoMessage) {
        var informationMessage = $('#informationMessage');

        if (!informationMessage.is(":visible")) {
            informationMessage.show();
        }

        if (messageType === "Info") {
            informationMessage.removeClass('alert-danger');
            informationMessage.addClass('alert-info');
            informationMessage.text(infoMessage);
        }

        if (messageType === "Danger") {
            informationMessage.removeClass('alert-info');
            informationMessage.addClass('alert-danger');

            if (!args) {
                informationMessage.text(infoMessage);
                return;
            }

            informationMessage.text(infoMessage);
        }
    }

    var getErrorMessage = function (infoMessage, args) {
        return `${infoMessage} ${args.get_message()} '[' ${args.get_errorCode()} ']`;
    }

    var getQueryStringParameter = function (paramToRetrieve) {
        var params =
        document.URL.split("?")[1].split("&");
        var strParams = "";
        for (var i = 0; i < params.length; i = i + 1) {
            var singleParam = params[i].split("=");
            if (singleParam[0] === paramToRetrieve)
                return singleParam[1];
        }
    };

    return {
        init: init
    };

})();

$(document).ready(function () {
    PPMFinancialApp.init();
});