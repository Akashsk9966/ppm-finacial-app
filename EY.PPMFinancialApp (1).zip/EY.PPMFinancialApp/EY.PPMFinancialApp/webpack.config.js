/// <binding ProjectOpened='Watch - Development' />
var path = require('path');
var nodeResolve = require('rollup-plugin-node-resolve');
var commonjs = require('rollup-plugin-commonjs');
var uglify = require('rollup-plugin-uglify');
var webpack = require('webpack');
module.exports = {
    // Target the output of the typescript compiler
    context: path.join(__dirname, ""),

    // File(s) to target in the 'build' directory
    entry: {
        appbundle: "./appScripts/main.js",
    },

    // Output
    output: {
        filename: '[name].js',
        path: path.resolve(__dirname, './Scripts/')
    },

    // Resolve the file extensions
    resolve: {
        extensions: [".js", ".jsx", ".ts", ".tsx"]
    },

    // Module to define what libraries with the compiler
    module: {
    },

    //devtool: 'inline-source-maps'
};